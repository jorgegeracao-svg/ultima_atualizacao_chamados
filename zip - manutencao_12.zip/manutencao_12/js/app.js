// ==================== INICIALIZAÇÃO DO APLICATIVO ====================

// Atualizar SLA a cada minuto
setInterval(function() {
    const currentScreen = document.querySelector('.screen.active');
    if (currentScreen && ['entradaScreen', 'logScreen'].includes(currentScreen.id)) {
        loadChamados();
    }
}, 60000); // 60 segundos

// Inicializar quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
    initUsuarios();
    checkAuth();
    if (typeof restoreSidebarState === 'function') restoreSidebarState();
    if (Storage.getCurrentUserLogin()) {
        loadChamados();
    }
});

// Exportar funções globais para console (útil para debug)
window.DEBUG = {
    resetarSistema,
    limparChamados,
    getUsuarios: () => Storage.getUsuarios(),
    getChamados: () => Storage.getChamados(),
    getCurrentUser
};

console.log('🔧 Sistema de Chamados carregado!');
console.log('💡 Use window.DEBUG para acessar funções de debug');