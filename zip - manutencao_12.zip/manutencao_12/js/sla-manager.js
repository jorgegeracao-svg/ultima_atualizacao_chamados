// ==================== GERENCIAMENTO DE SLA ====================

/**
 * Calcula o tempo decorrido entre duas datas em formato legível
 * @param {string} dataInicio - Data inicial em ISO string
 * @param {string} dataFim - Data final em ISO string (ou null para usar agora)
 * @returns {string} Tempo formatado (ex: "2 horas", "30 minutos", "3 dias")
 */
function calcularTempoDecorrido(dataInicio, dataFim = null) {
    const inicio = new Date(dataInicio);
    const fim = dataFim ? new Date(dataFim) : new Date();
    
    const diffMs = fim - inicio;
    const diffMinutos = Math.floor(diffMs / 60000);
    const diffHoras = Math.floor(diffMinutos / 60);
    const diffDias = Math.floor(diffHoras / 24);
    
    if (diffDias > 0) {
        const horasRestantes = diffHoras % 24;
        return diffDias === 1 
            ? `1 dia${horasRestantes > 0 ? ` e ${horasRestantes}h` : ''}` 
            : `${diffDias} dias${horasRestantes > 0 ? ` e ${horasRestantes}h` : ''}`;
    }
    
    if (diffHoras > 0) {
        const minutosRestantes = diffMinutos % 60;
        return diffHoras === 1 
            ? `1 hora${minutosRestantes > 0 ? ` e ${minutosRestantes}min` : ''}` 
            : `${diffHoras} horas${minutosRestantes > 0 ? ` e ${minutosRestantes}min` : ''}`;
    }
    
    return diffMinutos === 1 ? '1 minuto' : `${diffMinutos} minutos`;
}

/**
 * Formata o SLA com tempo real de atendimento
 * @param {number} slaMinutos - SLA em minutos
 * @param {string} dataInicio - Data de início da etapa
 * @param {string} dataConclusao - Data de conclusão da etapa (opcional)
 * @returns {string} String formatada com SLA e tempo real
 */
function formatarSLAComTempoReal(slaMinutos, dataInicio, dataConclusao = null) {
    const slaHoras = Math.floor(slaMinutos / 60);
    const slaMinutosRestantes = slaMinutos % 60;
    
    let slaTexto = '';
    if (slaHoras > 0) {
        slaTexto = slaMinutosRestantes > 0 
            ? `${slaHoras}h ${slaMinutosRestantes}min` 
            : `${slaHoras} ${slaHoras === 1 ? 'hora' : 'horas'}`;
    } else {
        slaTexto = `${slaMinutos} minutos`;
    }
    
    const tempoReal = calcularTempoDecorrido(dataInicio, dataConclusao);
    
    return `⏱️ SLA: ${slaTexto} / atendido em ${tempoReal}`;
}

/**
 * Calcula status do SLA (ok, warning, danger)
 * @param {string} prazoISO - Prazo em formato ISO
 * @returns {object} Objeto com classe CSS e ícone
 */
function calcularStatusSLA(prazoISO) {
    const prazo = new Date(prazoISO);
    const agora = new Date();
    const diff = prazo - agora;
    const totalMinutos = Math.floor(diff / 60000);
    
    if (diff < 0) {
        return { classe: 'sla-danger', icone: '🔴', texto: 'ATRASADO' };
    } else if (totalMinutos < 10) {
        return { classe: 'sla-danger', icone: '⚠️', texto: 'CRÍTICO' };
    } else if (totalMinutos < 60) {
        return { classe: 'sla-warning', icone: '⚠️', texto: 'ATENÇÃO' };
    }
    
    return { classe: 'sla-ok', icone: '⏰', texto: 'NO PRAZO' };
}

/**
 * Renderiza o badge de SLA para uma etapa
 * @param {object} etapa - Objeto da etapa
 * @returns {string} HTML do badge de SLA
 */
function renderSLABadge(etapa) {
    if (!etapa.sla) {
        return '<span class="sla-badge sla-sem">Sem SLA</span>';
    }
    
    if (etapa.status === 'CONCLUIDA') {
        const tempoReal = calcularTempoDecorrido(etapa.dataInicio, etapa.dataConclusao);
        const slaMinutos = etapa.sla;
        const tempoRealMinutos = Math.floor((new Date(etapa.dataConclusao) - new Date(etapa.dataInicio)) / 60000);
        
        const dentroDoSLA = tempoRealMinutos <= slaMinutos;
        
        return `
            <span class="sla-badge ${dentroDoSLA ? 'sla-ok' : 'sla-danger'}">
                ${dentroDoSLA ? '✅' : '⚠️'} Atendido em ${tempoReal}
            </span>
        `;
    }
    
    if (etapa.prazo) {
        const status = calcularStatusSLA(etapa.prazo);
        const prazo = new Date(etapa.prazo);
        const agora = new Date();
        const diff = prazo - agora;
        const totalMinutos = Math.floor(diff / 60000);
        const horas = Math.floor(Math.abs(totalMinutos) / 60);
        const minutos = Math.abs(totalMinutos) % 60;
        
        let tempoTexto = '';
        if (diff < 0) {
            tempoTexto = `Atrasado ${horas}h ${minutos}min`;
        } else if (totalMinutos < 60) {
            tempoTexto = `${minutos} min restantes`;
        } else {
            tempoTexto = `${horas}h ${minutos}min restantes`;
        }
        
        return `
            <span class="sla-badge ${status.classe}">
                ${status.icone} ${tempoTexto}
            </span>
        `;
    }
    
    return `<span class="sla-badge sla-aguardando">⏳ Aguardando início</span>`;
}