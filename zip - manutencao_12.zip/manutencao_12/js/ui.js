// ==================== INTERFACE DO USUÁRIO ====================

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('open');
    overlay.classList.toggle('active');
}

function toggleSidebarCollapse() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    const btn = sidebar ? sidebar.querySelector('.sidebar-collapse-btn') : null;
    if (!sidebar || !mainContent) return;

    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('sidebar-collapsed');

    const isCollapsed = sidebar.classList.contains('collapsed');
    if (btn) {
        btn.title = isCollapsed ? 'Expandir menu' : 'Recolher menu';
        btn.setAttribute('aria-label', isCollapsed ? 'Expandir menu' : 'Recolher menu');
    }
    try {
        localStorage.setItem('sidebarCollapsed', isCollapsed ? '1' : '0');
    } catch (e) {}
}

function restoreSidebarState() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    const btn = sidebar ? sidebar.querySelector('.sidebar-collapse-btn') : null;
    if (!sidebar || !mainContent) return;
    try {
        const collapsed = localStorage.getItem('sidebarCollapsed') === '1';
        if (collapsed) {
            sidebar.classList.add('collapsed');
            mainContent.classList.add('sidebar-collapsed');
            if (btn) {
                btn.title = 'Expandir menu';
                btn.setAttribute('aria-label', 'Expandir menu');
            }
        }
    } catch (e) {}
}

async function showScreen(screen) {
    // 🔒 FECHAR SIDEBAR IMEDIATAMENTE (SEMPRE, NÃO SÓ EM MOBILE)
    // Isso garante que a sidebar feche assim que o usuário clicar em qualquer opção
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    if (sidebar && overlay) {
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
    }
    
    // Verificações de permissão
    if (screen === 'usuarios') {
        const currentUser = getCurrentUser();
        
        if (!currentUser || currentUser.perfil !== 'PROGRAMADOR') {
            showAlert('Acesso negado! Apenas programadores podem acessar esta área.', 'error');
            return;
        }
    }
    
    if (screen === 'editar') {
        const currentUser = getCurrentUser();
        
        if (!currentUser || currentUser.perfil !== 'PROGRAMADOR') {
            showAlert('Acesso negado! Apenas programadores podem editar e excluir chamados.', 'error');
            return;
        }
    }
    
    if (screen === 'slaconfig') {
        const currentUser = getCurrentUser();
        
        if (!currentUser || currentUser.perfil !== 'PROGRAMADOR') {
            showAlert('Acesso negado! Apenas programadores podem configurar SLA.', 'error');
            return;
        }
    }
    
    if (screen === 'admin') {
        const currentUser = getCurrentUser();
        
        if (!currentUser || currentUser.perfil !== 'PROGRAMADOR') {
            showAlert('Acesso negado! Apenas programadores podem acessar o painel administrativo.', 'error');
            return;
        }
    }
    
    // Mostrar loading ao trocar de tela (apenas para telas que carregam dados)
    if (['entrada', 'log', 'saida', 'usuarios', 'editar', 'slaconfig', 'admin'].includes(screen)) {
        showLoading('Carregando dados');
    }
    
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    
    const screenMap = {
        'entrada': 'entradaScreen',
        'log': 'logScreen',
        'saida': 'saidaScreen',
        'novo': 'novoScreen',
        'detalhes': 'detalhesScreen',
        'editar': 'editarScreen',
        'usuarios': 'usuariosScreen',
        'slaconfig': 'slaconfigScreen',
        'admin': 'adminScreen'
    };
    
    document.getElementById(screenMap[screen]).classList.add('active');
    
    if (screen !== 'detalhes') {
        const menuItems = document.querySelectorAll('.menu-item');
        const index = ['entrada', 'log', 'saida', null, 'novo', null, 'editar', 'usuarios', 'slaconfig', 'admin'].indexOf(screen);
        if (index >= 0 && menuItems[index]) {
            menuItems[index].classList.add('active');
        }
    }
    
    // Carregar dados com loading
    if (['entrada', 'log', 'saida'].includes(screen)) {
        await new Promise(resolve => setTimeout(resolve, 400));
        loadChamados();
        hideLoading(200);
    } else if (screen === 'usuarios') {
        await new Promise(resolve => setTimeout(resolve, 400));
        loadUsuarios();
        hideLoading(200);
    } else if (screen === 'editar') {
        await new Promise(resolve => setTimeout(resolve, 400));
        loadChamadosEditar();
        hideLoading(200);
    } else if (screen === 'slaconfig') {
        await new Promise(resolve => setTimeout(resolve, 400));
        loadSLAConfigScreen();
        hideLoading(200);
    } else if (screen === 'admin') {
        await new Promise(resolve => setTimeout(resolve, 400));
        loadAdminScreen();
        hideLoading(200);
    }
}

function showAlert(message, type, containerId = 'alertContainer') {
    const container = document.getElementById(containerId);
    const alertClass = type === 'success' ? 'alert-success' : 'alert-error';
    
    container.innerHTML = `
        <div class="alert ${alertClass}">
            ${type === 'success' ? '✓' : '✕'} ${message}
        </div>
    `;
    
    setTimeout(() => {
        container.innerHTML = '';
    }, 3000);
}

// Funções auxiliares para administração do sistema
function resetarSistema() {
    if (confirm('⚠️ ATENÇÃO: Isso vai apagar TODOS os dados (usuários e chamados).\n\nTem certeza?')) {
        Storage.limparTudo();
        alert('✓ Sistema resetado! Recarregando...');
        location.reload();
    }
}

function limparChamados() {
    if (confirm('⚠️ Isso vai apagar APENAS os chamados (usuários mantidos).\n\nTem certeza?')) {
        Storage.limparChamados();
        alert('✓ Chamados apagados! Recarregando...');
        location.reload();
    }
}

// Funções para modal de anexos
function visualizarAnexos(chamadoId) {
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const anexosContent = document.getElementById('anexosContent');
    
    if (!chamado.anexos || chamado.anexos.length === 0) {
        anexosContent.innerHTML = `
            <div style="text-align: center; padding: 40px; color: #94a3b8;">
                📎 Nenhum anexo encontrado neste chamado.
            </div>
        `;
    } else {
        anexosContent.innerHTML = chamado.anexos.map((anexo, index) => `
            <div style="margin-bottom: 20px; border: 2px solid #e2e8f0; border-radius: 8px; padding: 16px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                    <div style="font-weight: 600; color: #1e293b;">
                        📎 ${anexo.nome}
                    </div>
                    <button onclick="baixarAnexo('${anexo.data}', '${anexo.nome}')" 
                            style="background: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; display: flex; align-items: center; gap: 6px;">
                        ⬇️ Baixar
                    </button>
                </div>
                <img src="${anexo.data}" alt="${anexo.nome}" 
                     style="max-width: 100%; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); cursor: pointer;"
                     onclick="window.open('${anexo.data}', '_blank')">
                <div style="margin-top: 8px; font-size: 0.85rem; color: #64748b;">
                    Tamanho: ${(anexo.tamanho / 1024).toFixed(2)} KB
                </div>
            </div>
        `).join('');
    }
    
    document.getElementById('modalAnexos').classList.add('active');
}

function baixarAnexo(dataUrl, nomeArquivo) {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = nomeArquivo;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function fecharModalAnexos() {
    document.getElementById('modalAnexos').classList.remove('active');
}