// ==================== GERENCIAMENTO DE UPLOAD DE ARQUIVOS ====================

/**
 * Processa upload de imagem e retorna base64
 * @param {File} file - Arquivo de imagem
 * @param {number} maxSize - Tamanho máximo em bytes (padrão: 5MB)
 * @returns {Promise<object>} Objeto com dados da imagem
 */
function processarImagemUpload(file, maxSize = 5 * 1024 * 1024) {
    return new Promise((resolve, reject) => {
        if (!file) {
            reject(new Error('Nenhum arquivo selecionado'));
            return;
        }
        
        if (!file.type.startsWith('image/')) {
            reject(new Error('O arquivo deve ser uma imagem'));
            return;
        }
        
        if (file.size > maxSize) {
            reject(new Error(`Arquivo muito grande! Tamanho máximo: ${(maxSize / (1024 * 1024)).toFixed(0)}MB`));
            return;
        }
        
        const reader = new FileReader();
        
        reader.onload = function(event) {
            resolve({
                nome: file.name,
                tipo: file.type,
                tamanho: file.size,
                data: event.target.result // Base64
            });
        };
        
        reader.onerror = function() {
            reject(new Error('Erro ao ler o arquivo'));
        };
        
        reader.readAsDataURL(file);
    });
}

/**
 * Cria preview de imagem
 * @param {string} dataUrl - URL em base64 da imagem
 * @param {string} nome - Nome do arquivo
 * @param {HTMLElement} container - Container onde será inserido o preview
 */
function criarPreviewImagem(dataUrl, nome, container) {
    container.innerHTML = `
        <div style="border: 2px solid #e2e8f0; border-radius: 8px; padding: 12px; display: inline-block;">
            <img src="${dataUrl}" alt="${nome}" 
                 style="max-width: 200px; max-height: 200px; border-radius: 6px;">
            <div style="text-align: center; margin-top: 8px; font-size: 0.85rem; color: #64748b;">
                ${nome}
            </div>
        </div>
    `;
}

/**
 * Setup de input de foto de usuário
 * @param {string} inputId - ID do input de arquivo
 * @param {string} previewId - ID do container de preview
 */
function setupFotoUsuarioInput(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    
    if (!input || !preview) return;
    
    input.addEventListener('change', async function(e) {
        const file = e.target.files[0];
        
        if (!file) {
            preview.innerHTML = `
                <div class="foto-preview-placeholder">
                    <span style="font-size: 3rem;">👤</span>
                    <p>Nenhuma foto selecionada</p>
                </div>
            `;
            return;
        }
        
        try {
            const imagemData = await processarImagemUpload(file, 2 * 1024 * 1024); // 2MB para foto de perfil
            
            preview.innerHTML = `
                <div class="foto-preview-container">
                    <img src="${imagemData.data}" alt="Preview" class="foto-preview-img">
                    <p class="foto-preview-nome">${imagemData.nome}</p>
                    <p class="foto-preview-tamanho">${(imagemData.tamanho / 1024).toFixed(2)} KB</p>
                </div>
            `;
        } catch (error) {
            showAlert(error.message, 'error');
            input.value = '';
            preview.innerHTML = `
                <div class="foto-preview-placeholder">
                    <span style="font-size: 3rem;">👤</span>
                    <p>Nenhuma foto selecionada</p>
                </div>
            `;
        }
    });
}

/**
 * Processa múltiplas imagens
 * @param {FileList} files - Lista de arquivos
 * @param {number} maxFiles - Número máximo de arquivos
 * @returns {Promise<Array>} Array de objetos com dados das imagens
 */
async function processarMultiplasImagens(files, maxFiles = 5) {
    if (files.length > maxFiles) {
        throw new Error(`Você pode enviar no máximo ${maxFiles} imagens`);
    }
    
    const promises = Array.from(files).map(file => processarImagemUpload(file));
    return Promise.all(promises);
}

/**
 * Renderiza galeria de imagens
 * @param {Array} imagens - Array de objetos de imagem
 * @param {HTMLElement} container - Container onde será inserida a galeria
 */
function renderizarGaleriaImagens(imagens, container) {
    if (!imagens || imagens.length === 0) {
        container.innerHTML = '<p style="color: #94a3b8;">Nenhuma imagem anexada.</p>';
        return;
    }
    
    container.innerHTML = `
        <div class="galeria-imagens">
            ${imagens.map((img, index) => `
                <div class="galeria-item">
                    <img src="${img.data}" alt="${img.nome}" 
                         onclick="abrirImagemModal('${img.data}', '${img.nome}')">
                    <p class="galeria-item-nome">${img.nome}</p>
                </div>
            `).join('')}
        </div>
    `;
}

/**
 * Abre imagem em modal (fullscreen)
 * @param {string} dataUrl - URL da imagem
 * @param {string} nome - Nome da imagem
 */
function abrirImagemModal(dataUrl, nome) {
    const modal = document.createElement('div');
    modal.className = 'modal-imagem-fullscreen active';
    modal.innerHTML = `
        <div class="modal-imagem-overlay" onclick="fecharImagemModal()"></div>
        <div class="modal-imagem-content">
            <button class="modal-imagem-close" onclick="fecharImagemModal()">✕</button>
            <img src="${dataUrl}" alt="${nome}">
            <p class="modal-imagem-nome">${nome}</p>
            <button class="modal-imagem-download" onclick="baixarImagem('${dataUrl}', '${nome}')">
                ⬇️ Baixar Imagem
            </button>
        </div>
    `;
    
    document.body.appendChild(modal);
}

/**
 * Fecha modal de imagem
 */
function fecharImagemModal() {
    const modal = document.querySelector('.modal-imagem-fullscreen');
    if (modal) {
        modal.remove();
    }
}

/**
 * Baixa imagem
 * @param {string} dataUrl - URL da imagem
 * @param {string} nome - Nome do arquivo
 */
function baixarImagem(dataUrl, nome) {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = nome;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}