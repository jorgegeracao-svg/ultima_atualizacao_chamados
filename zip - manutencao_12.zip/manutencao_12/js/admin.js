// ==================== PAINEL DO ADMINISTRADOR ====================

/**
 * Carrega a tela de Admin e atualiza estatísticas
 */
function loadAdminScreen() {
    const currentUser = getCurrentUser();

    // Verificar permissão
    if (!currentUser || currentUser.perfil !== 'PROGRAMADOR') {
        showAlert('Acesso negado! Apenas programadores podem acessar esta área.', 'error');
        showScreen('entrada');
        return;
    }

    // Atualizar estatísticas automaticamente
    atualizarEstatisticas();
    atualizarInfoSistema();
}

/**
 * Atualiza estatísticas do sistema
 */
function atualizarEstatisticas() {
    const chamados = Storage.getChamados();
    const usuarios = Storage.getUsuarios();

    const totalChamados = chamados.length;
    const totalUsuarios = usuarios.length;
    const chamadosAndamento = chamados.filter(c => c.status === 'EM_ANDAMENTO').length;
    const chamadosConcluidos = chamados.filter(c => c.status === 'CONCLUIDO').length;
    const chamadosCancelados = chamados.filter(c => c.status === 'CANCELADO').length;

    document.getElementById('statTotalChamados').textContent = totalChamados;
    document.getElementById('statTotalUsuarios').textContent = totalUsuarios;
    document.getElementById('statChamadosAndamento').textContent = chamadosAndamento;
    document.getElementById('statChamadosConcluidos').textContent = chamadosConcluidos;

    console.log('📊 Estatísticas atualizadas:', {
        totalChamados,
        totalUsuarios,
        chamadosAndamento,
        chamadosConcluidos,
        chamadosCancelados
    });
}

/**
 * Atualiza informações do sistema
 */
function atualizarInfoSistema() {
    // Detectar navegador
    const userAgent = navigator.userAgent;
    let browser = 'Desconhecido';
    
    if (userAgent.indexOf('Chrome') > -1) {
        browser = 'Chrome';
    } else if (userAgent.indexOf('Firefox') > -1) {
        browser = 'Firefox';
    } else if (userAgent.indexOf('Safari') > -1) {
        browser = 'Safari';
    } else if (userAgent.indexOf('Edge') > -1) {
        browser = 'Edge';
    }

    document.getElementById('statBrowser').textContent = browser;

    // Calcular uso do LocalStorage
    let totalSize = 0;
    for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
            totalSize += localStorage[key].length + key.length;
        }
    }
    
    const sizeInKB = (totalSize / 1024).toFixed(2);
    const sizeInMB = (totalSize / (1024 * 1024)).toFixed(2);
    
    document.getElementById('statStorage').textContent = sizeInKB < 1024 
        ? `${sizeInKB} KB` 
        : `${sizeInMB} MB`;
}

/**
 * Limpar todos os chamados (mantém usuários)
 */
function limparChamadosAdmin() {
    const confirmacao1 = confirm(
        '⚠️ ATENÇÃO: Você está prestes a EXCLUIR TODOS OS CHAMADOS do sistema!\n\n' +
        'Os usuários serão mantidos, mas TODOS os chamados serão perdidos.\n\n' +
        'Tem certeza que deseja continuar?'
    );

    if (!confirmacao1) return;

    const confirmacao2 = confirm(
        '🚨 ÚLTIMA CONFIRMAÇÃO!\n\n' +
        'Esta ação é IRREVERSÍVEL. Todos os chamados serão PERMANENTEMENTE excluídos.\n\n' +
        'Digite OK para confirmar.'
    );

    if (!confirmacao2) return;

    const chamadosAntes = Storage.getChamados().length;
    
    Storage.limparChamados();
    
    showAlert(
        `✅ ${chamadosAntes} chamados foram excluídos com sucesso!`, 
        'success', 
        'alertAdminContainer'
    );

    atualizarEstatisticas();
    
    console.log('🗑️ Chamados limpos. Total excluído:', chamadosAntes);
}

/**
 * Resetar sistema completo (usuários + chamados)
 */
function resetarSistemaAdmin() {
    const confirmacao1 = confirm(
        '🚨 PERIGO: RESET TOTAL DO SISTEMA!\n\n' +
        'Você está prestes a APAGAR TUDO:\n' +
        '• Todos os chamados\n' +
        '• Todos os usuários (exceto os padrão)\n' +
        '• Todas as configurações\n\n' +
        'Esta ação é IRREVERSÍVEL!\n\n' +
        'Tem certeza que deseja continuar?'
    );

    if (!confirmacao1) return;

    const confirmacao2 = confirm(
        '⚠️ ÚLTIMA CHANCE DE VOLTAR ATRÁS!\n\n' +
        'O sistema será COMPLETAMENTE resetado e você será desconectado.\n\n' +
        'Clique em OK para CONFIRMAR o reset total.'
    );

    if (!confirmacao2) return;

    const senha = prompt(
        '🔐 Digite a senha do administrador para confirmar:\n\n' +
        '(Senha: admin)'
    );

    if (senha !== 'admin') {
        showAlert('❌ Senha incorreta! Reset cancelado.', 'error', 'alertAdminContainer');
        return;
    }

    // Executar reset
    Storage.limparTudo();
    
    alert('✅ Sistema resetado com sucesso!\n\nVocê será redirecionado para a tela de login.');
    
    location.reload();
}

/**
 * Exportar dados do sistema em JSON
 */
function exportarDadosAdmin() {
    try {
        const backup = {
            versao: '1.0.0',
            dataExportacao: new Date().toISOString(),
            dados: {
                usuarios: Storage.getUsuarios(),
                chamados: Storage.getChamados(),
                slaConfig: localStorage.getItem('slaConfig') ? JSON.parse(localStorage.getItem('slaConfig')) : null
            }
        };

        const dataStr = JSON.stringify(backup, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `backup-sistema-${new Date().toISOString().split('T')[0]}.json`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        showAlert('✅ Backup exportado com sucesso!', 'success', 'alertAdminContainer');
        
        console.log('📤 Backup exportado:', backup);
    } catch (error) {
        showAlert('❌ Erro ao exportar backup: ' + error.message, 'error', 'alertAdminContainer');
        console.error('Erro ao exportar:', error);
    }
}

/**
 * Importar dados do sistema de um arquivo JSON
 */
function importarDadosAdmin(event) {
    const file = event.target.files[0];
    
    if (!file) return;

    const confirmacao = confirm(
        '⚠️ ATENÇÃO: Importar backup substituirá TODOS os dados atuais!\n\n' +
        'Usuários e chamados atuais serão PERDIDOS.\n\n' +
        'Tem certeza que deseja continuar?'
    );

    if (!confirmacao) {
        event.target.value = ''; // Limpar input
        return;
    }

    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            const backup = JSON.parse(e.target.result);
            
            // Validar estrutura do backup
            if (!backup.dados || !backup.dados.usuarios || !backup.dados.chamados) {
                throw new Error('Arquivo de backup inválido ou corrompido!');
            }

            // Restaurar dados
            Storage.saveUsuarios(backup.dados.usuarios);
            Storage.saveChamados(backup.dados.chamados);
            
            if (backup.dados.slaConfig) {
                localStorage.setItem('slaConfig', JSON.stringify(backup.dados.slaConfig));
            }

            showAlert('✅ Backup importado com sucesso!', 'success', 'alertAdminContainer');
            
            setTimeout(() => {
                alert('Sistema restaurado! A página será recarregada.');
                location.reload();
            }, 1500);

            console.log('📥 Backup importado:', backup);
        } catch (error) {
            showAlert('❌ Erro ao importar backup: ' + error.message, 'error', 'alertAdminContainer');
            console.error('Erro ao importar:', error);
        }
        
        event.target.value = ''; // Limpar input
    };
    
    reader.onerror = function() {
        showAlert('❌ Erro ao ler o arquivo!', 'error', 'alertAdminContainer');
        event.target.value = '';
    };
    
    reader.readAsText(file);
}

/**
 * Limpar cache e recarregar página
 */
function limparCacheAdmin() {
    const confirmacao = confirm(
        '🧹 Limpar cache do navegador?\n\n' +
        'Isso irá recarregar a página e pode limpar dados temporários.\n\n' +
        'Os dados do sistema (localStorage) serão mantidos.'
    );

    if (!confirmacao) return;

    // Limpar Service Workers (se houver)
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then(function(registrations) {
            for (let registration of registrations) {
                registration.unregister();
            }
        });
    }

    // Recarregar forçando limpeza de cache
    location.reload(true);
}

/**
 * Abrir console de debug do navegador
 */
function abrirConsoleDebug() {
    alert(
        '🖥️ Console de Debug\n\n' +
        'Para abrir o console do navegador:\n\n' +
        '• Chrome/Edge: F12 ou Ctrl+Shift+I\n' +
        '• Firefox: F12 ou Ctrl+Shift+K\n' +
        '• Safari: Cmd+Option+C\n\n' +
        'No console, você pode usar:\n' +
        '• window.DEBUG.getChamados()\n' +
        '• window.DEBUG.getUsuarios()\n' +
        '• window.DEBUG.getCurrentUser()'
    );
    
    // Exibir informações úteis no console
    console.log('%c🔧 CONSOLE DE DEBUG - SISTEMA DE CHAMADOS', 'background: #052659; color: #fff; padding: 10px; font-size: 16px; font-weight: bold;');
    console.log('%cFunções disponíveis:', 'color: #3b82f6; font-weight: bold;');
    console.log('• window.DEBUG.getChamados() - Listar todos os chamados');
    console.log('• window.DEBUG.getUsuarios() - Listar todos os usuários');
    console.log('• window.DEBUG.getCurrentUser() - Ver usuário atual');
    console.log('• window.DEBUG.resetarSistema() - Resetar sistema');
    console.log('• window.DEBUG.limparChamados() - Limpar chamados');
    console.log('%c---', 'color: #64748b;');
    console.log('Estatísticas atuais:');
    console.log('• Chamados:', Storage.getChamados().length);
    console.log('• Usuários:', Storage.getUsuarios().length);
}

/**
 * Testar funcionalidades do sistema
 */
function testarSistemaAdmin() {
    console.log('🧪 Iniciando testes do sistema...');
    
    let resultados = {
        storage: false,
        usuarios: false,
        chamados: false,
        navegador: false
    };

    // Teste 1: LocalStorage
    try {
        localStorage.setItem('teste', 'ok');
        localStorage.removeItem('teste');
        resultados.storage = true;
        console.log('✅ LocalStorage funcionando');
    } catch (e) {
        console.error('❌ Erro no LocalStorage:', e);
    }

    // Teste 2: Usuários
    try {
        const usuarios = Storage.getUsuarios();
        resultados.usuarios = Array.isArray(usuarios);
        console.log(`✅ Sistema de usuários: ${usuarios.length} usuários carregados`);
    } catch (e) {
        console.error('❌ Erro ao carregar usuários:', e);
    }

    // Teste 3: Chamados
    try {
        const chamados = Storage.getChamados();
        resultados.chamados = Array.isArray(chamados);
        console.log(`✅ Sistema de chamados: ${chamados.length} chamados carregados`);
    } catch (e) {
        console.error('❌ Erro ao carregar chamados:', e);
    }

    // Teste 4: Navegador
    try {
        resultados.navegador = typeof document !== 'undefined' && typeof window !== 'undefined';
        console.log('✅ Ambiente do navegador OK');
    } catch (e) {
        console.error('❌ Erro no ambiente:', e);
    }

    // Resultado final
    const totalTestes = Object.keys(resultados).length;
    const testesOK = Object.values(resultados).filter(r => r).length;

    const mensagem = `🧪 Testes Concluídos\n\n` +
        `✅ Aprovados: ${testesOK}/${totalTestes}\n` +
        `\nDetalhes:\n` +
        `• LocalStorage: ${resultados.storage ? '✅' : '❌'}\n` +
        `• Usuários: ${resultados.usuarios ? '✅' : '❌'}\n` +
        `• Chamados: ${resultados.chamados ? '✅' : '❌'}\n` +
        `• Navegador: ${resultados.navegador ? '✅' : '❌'}`;

    alert(mensagem);
    
    showAlert(
        `Testes concluídos: ${testesOK}/${totalTestes} aprovados`, 
        testesOK === totalTestes ? 'success' : 'error', 
        'alertAdminContainer'
    );

    console.log('🧪 Resultados dos testes:', resultados);
}

// ==================== INICIALIZAÇÃO ====================

console.log('✅ Admin Panel System carregado!');