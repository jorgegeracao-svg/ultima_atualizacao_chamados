// ==================== SISTEMA DE VOLTAR ETAPA ====================

// Motivos pré-definidos para voltar etapa
const MOTIVOS_VOLTAR_ETAPA = [
    "Informações incompletas",
    "Dados incorretos",
    "Necessita correção",
    "Documentação faltando",
    "Aguardando aprovação",
    "Requer mais detalhes",
    "Erro no preenchimento",
    "Mudança de escopo",
    "Solicitação do gestor",
    "Revisão necessária",
    "Outros"
];

let chamadoParaVoltar = null;
let etapaDestinoVoltar = null;

/**
 * Abre modal para voltar etapa
 * @param {number} chamadoId - ID do chamado
 * @param {number} etapaDestino - Número da etapa para onde voltar
 */
function abrirModalVoltarEtapa(chamadoId, etapaDestino) {
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);

    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }

    const currentUser = getCurrentUser();
    const etapaAtual = chamado.etapas.find(e => e.numero === chamado.etapaAtual);
    const etapaConfig = ETAPAS_CONFIG[etapaDestino - 1];

    if (!etapaConfig) {
        showAlert('Etapa não encontrada!', 'error');
        return;
    }

    chamadoParaVoltar = chamadoId;
    etapaDestinoVoltar = etapaDestino;

    // Renderizar opções de motivo
    const selectMotivo = document.getElementById('motivoVoltarEtapa');
    selectMotivo.innerHTML = MOTIVOS_VOLTAR_ETAPA.map(motivo =>
        `<option value="${motivo}">${motivo}</option>`
    ).join('');

    // Limpar campo de observações
    document.getElementById('observacoesVoltarEtapa').value = '';

    // Atualizar informações do modal
    document.getElementById('infoChamadoVoltar').innerHTML = `
        <div style="background: #f1f5f9; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
            <div style="display: grid; gap: 8px; font-size: 0.9rem;">
                <div><strong style="color: #052659;">Chamado:</strong> #${chamado.id} - ${chamado.titulo}</div>
                <div><strong style="color: #052659;">Etapa Atual:</strong> ${etapaAtual.numero}. ${etapaAtual.nome}</div>
                <div><strong style="color: #dc2626;">Voltar para:</strong> ${etapaDestino}. ${etapaConfig.nome}</div>
            </div>
        </div>
        <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 6px; color: #991b1b; font-size: 0.85rem;">
            ⚠️ <strong>Atenção:</strong> Ao voltar a etapa, o chamado retornará para a etapa selecionada e o responsável será notificado do motivo.
        </div>
    `;

    document.getElementById('modalVoltarEtapa').classList.add('active');
}

/**
 * Fecha modal de voltar etapa
 */
function fecharModalVoltarEtapa() {
    chamadoParaVoltar = null;
    etapaDestinoVoltar = null;
    document.getElementById('modalVoltarEtapa').classList.remove('active');
    document.getElementById('formVoltarEtapa').reset();
}

/**
 * Confirma e processa o retorno de etapa
 */
function confirmarVoltarEtapa() {
    console.log('🔍 DEBUG: confirmarVoltarEtapa chamada');
    console.log('🔍 chamadoParaVoltar:', chamadoParaVoltar);
    console.log('🔍 etapaDestinoVoltar:', etapaDestinoVoltar);
    
    if (!chamadoParaVoltar || !etapaDestinoVoltar) {
        showAlert('Dados inválidos para voltar etapa!', 'error');
        return;
    }

    const motivo = document.getElementById('motivoVoltarEtapa').value;
    const observacoes = document.getElementById('observacoesVoltarEtapa').value.trim();

    console.log('🔍 motivo:', motivo);
    console.log('🔍 observacoes:', observacoes);

    if (!motivo) {
        showAlert('Selecione um motivo para voltar a etapa!', 'error');
        return;
    }

    const sucesso = processarVoltarEtapa(
        chamadoParaVoltar,
        etapaDestinoVoltar,
        motivo,
        observacoes
    );

    console.log('🔍 sucesso do processamento:', sucesso);

    if (sucesso) {
        showAlert(
            `Chamado #${chamadoParaVoltar} retornou para a etapa ${etapaDestinoVoltar}!`,
            'success'
        );

        fecharModalVoltarEtapa();

        // Atualiza tela de detalhes
        showDetalhes(chamadoParaVoltar);
    } else {
        showAlert('Erro ao processar retorno de etapa!', 'error');
    }
}


/**
 * Processa o retorno de etapa
 * @param {number} chamadoId - ID do chamado
 * @param {number} etapaDestino - Número da etapa destino
 * @param {string} motivo - Motivo do retorno
 * @param {string} observacoes - Observações adicionais
 * @returns {boolean} Sucesso ou falha
 */
function processarVoltarEtapa(chamadoId, etapaDestino, motivo, observacoes) {
    console.log('🔍 DEBUG: processarVoltarEtapa iniciada');
    console.log('🔍 chamadoId:', chamadoId);
    console.log('🔍 etapaDestino:', etapaDestino);
    console.log('🔍 motivo:', motivo);
    console.log('🔍 observacoes:', observacoes);
    
    const chamados = Storage.getChamados();
    const currentUser = getCurrentUser();

    const chamado = chamados.find(c => c.id === chamadoId);
    if (!chamado) {
        console.error('❌ Chamado não encontrado!');
        return false;
    }

    console.log('✅ Chamado encontrado:', chamado);

    const etapaAtualObj = chamado.etapas.find(e => e.numero === chamado.etapaAtual);
    const etapaAtualNumero = chamado.etapaAtual;
    const etapaAtualNome = etapaAtualObj?.nome || '';
    
    console.log('🔍 Etapa atual:', etapaAtualNumero, etapaAtualNome);
    
    if (etapaAtualObj) {
        etapaAtualObj.status = 'DEVOLVIDA';
        etapaAtualObj.dataConclusao = new Date().toISOString();
    }

    // 👉 ATUALIZA ETAPA ATUAL
    chamado.etapaAtual = etapaDestino;
    console.log('✅ Etapa atual atualizada para:', etapaDestino);

    // Buscar ou criar etapa destino
    let etapaDestinoObj = chamado.etapas.find(e => e.numero === etapaDestino);

    if (!etapaDestinoObj) {
        console.log('📝 Criando nova etapa destino');
        etapaDestinoObj = {
            numero: etapaDestino,
            nome: ETAPAS_CONFIG[etapaDestino - 1]?.nome || `Etapa ${etapaDestino}`,
            dataInicio: new Date().toISOString(),
            dataConclusao: null,
            status: 'EM_ANDAMENTO',
            dados: {},
            retornos: []
        };
        chamado.etapas.push(etapaDestinoObj);
    } else {
        console.log('✅ Etapa destino já existe');
    }

    // 🔥 CORREÇÃO CRÍTICA: Definir responsável correto baseado na configuração da etapa
    const etapaDestinoConfig = ETAPAS_CONFIG[etapaDestino - 1];
    
    if (etapaDestinoConfig) {
        // Se a etapa tem responsável SOLICITANTE, definir o usuário solicitante
        if (etapaDestinoConfig.responsavel === 'SOLICITANTE') {
            etapaDestinoObj.responsavel = null; // Deixa null para routing pegar pelo perfil
            console.log('✅ Responsável definido: SOLICITANTE (null = verificar por perfil)');
        } 
        // Para outros perfis (TECNICO, ADMINISTRATIVO, etc), também deixa null
        else {
            etapaDestinoObj.responsavel = null; // Sistema vai rotear pelo perfil
            console.log(`✅ Responsável definido: ${etapaDestinoConfig.responsavel} (null = verificar por perfil)`);
        }
    }
    
    etapaDestinoObj.status = 'EM_ANDAMENTO';
    etapaDestinoObj.dataInicio = new Date().toISOString();
    etapaDestinoObj.dataConclusao = null; // 🔥 IMPORTANTE: Limpar data de conclusão ao reabrir

    // 🔥 ADICIONAR INFORMAÇÃO DO RETORNO NA ETAPA DESTINO
    if (!etapaDestinoObj.retornos) {
        etapaDestinoObj.retornos = [];
        console.log('📝 Array de retornos criado');
    }
    
    const retornoObj = {
        dataRetorno: new Date().toISOString(),
        usuarioRetorno: currentUser.usuario,
        nomeUsuarioRetorno: currentUser.nomeCompleto,
        etapaOrigem: etapaAtualNumero,
        nomeEtapaOrigem: etapaAtualNome,
        motivo: motivo,
        observacoes: observacoes
    };
    
    console.log('📦 Objeto de retorno:', retornoObj);
    etapaDestinoObj.retornos.push(retornoObj);
    console.log('✅ Retorno adicionado. Total de retornos:', etapaDestinoObj.retornos.length);

    // Histórico
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Retornou o chamado para a etapa ${etapaDestino}`,
        motivo,
        observacoes
    });

    console.log('💾 Salvando chamados...');
    Storage.saveChamados(chamados);
    console.log('✅ Chamados salvos com sucesso!');
    
    return true;
}


/**
 * Verifica se o usuário pode voltar a etapa
 * @param {object} chamado - Objeto do chamado
 * @param {number} etapaDestino - Número da etapa destino
 * @param {object} currentUser - Usuário atual
 * @returns {boolean}
 */
function podeVoltarEtapa(chamado, etapaDestino, currentUser) {
    // Chamado deve estar em andamento
    if (chamado.status !== 'EM_ANDAMENTO') {
        return false;
    }

    // Etapa destino deve ser menor que a atual
    if (etapaDestino >= chamado.etapaAtual) {
        return false;
    }

    // Usuário deve ser programador OU responsável pela etapa atual
    if (currentUser.perfil === 'PROGRAMADOR') {
        return true;
    }

    const etapaAtual = chamado.etapas.find(e => e.numero === chamado.etapaAtual);

    if (etapaAtual && etapaAtual.responsavel === currentUser.usuario) {
        return true;
    }

    // Verificar se é responsável por perfil
    const etapaConfig = ETAPAS_CONFIG[chamado.etapaAtual - 1];
    if (etapaConfig) {
        if (etapaConfig.responsavel === 'SOLICITANTE' && chamado.solicitante === currentUser.usuario) {
            return true;
        }

        if (etapaConfig.responsavel === currentUser.perfil) {
            return true;
        }
    }

    return false;
}

/**
 * Renderiza botões de voltar etapa para cada etapa anterior
 * @param {object} chamado - Objeto do chamado
 * @param {object} currentUser - Usuário atual
 * @returns {string} HTML dos botões
 */
function renderBotoesVoltarEtapa(chamado, currentUser) {
    // Chamado precisa estar em andamento
    if (chamado.status !== 'EM_ANDAMENTO') {
        return '';
    }

    // Se estiver na primeira etapa, não há para onde voltar
    if (chamado.etapaAtual <= 1) {
        return '';
    }

    // Verificar permissão do usuário
    const temPermissaoGeral = verificarPermissaoVoltarEtapa(chamado, currentUser);
    if (!temPermissaoGeral) {
        return '';
    }

    // Etapa imediatamente anterior
    const etapaAnterior = chamado.etapaAtual - 1;

    // Buscar configuração da etapa anterior
    const etapaConfig = ETAPAS_CONFIG[etapaAnterior - 1];
    if (!etapaConfig) {
        return '';
    }

    // HTML do botão único
    let html = `
        <div style="margin-top: 20px; padding: 16px; background: #fef3c7; border: 1px solid #fbbf24; border-radius: 8px;">
            <h4 style="color: #92400e; margin: 0 0 12px 0; font-size: 0.9rem;">
                ⚠️ Voltar Etapa
            </h4>

            <button 
                class="btn-voltar-etapa"
                onclick="abrirModalVoltarEtapa(${chamado.id}, ${etapaAnterior})"
                title="Voltar para: ${etapaConfig.nome}">
                ⬅️ Voltar para etapa ${etapaAnterior} — ${etapaConfig.nome}
            </button>

            <p style="margin: 12px 0 0 0; font-size: 0.8rem; color: #78350f;">
                O chamado retornará apenas para a etapa anterior.
            </p>
        </div>
    `;

    return html;
}


/**
 * Verifica se o usuário tem permissão geral para voltar etapas
 * @param {object} chamado - Objeto do chamado
 * @param {object} currentUser - Usuário atual
 * @returns {boolean}
 */
function verificarPermissaoVoltarEtapa(chamado, currentUser) {
    // Programador sempre pode
    if (currentUser.perfil === 'PROGRAMADOR') {
        return true;
    }

    // Verificar se é responsável pela etapa atual
    const etapaAtual = chamado.etapas.find(e => e.numero === chamado.etapaAtual);

    if (etapaAtual) {
        // Responsável específico
        if (etapaAtual.responsavel === currentUser.usuario) {
            return true;
        }

        // Verificar se é responsável por perfil
        const etapaConfig = ETAPAS_CONFIG[chamado.etapaAtual - 1];
        if (etapaConfig) {
            if (etapaConfig.responsavel === 'SOLICITANTE' && chamado.solicitante === currentUser.usuario) {
                return true;
            }

            if (etapaConfig.responsavel === currentUser.perfil) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Renderiza histórico de retornos de uma etapa
 * @param {object} etapa - Objeto da etapa
 * @returns {string} HTML do histórico
 */
function renderHistoricoRetornos(etapa) {
    if (!etapa.retornos || etapa.retornos.length === 0) {
        return '';
    }

    let html = '<div style="margin-top: 16px; padding: 12px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px;">';
    html += '<h5 style="color: #991b1b; margin: 0 0 12px 0; font-size: 0.85rem;">🔄 Histórico de Retornos</h5>';

    etapa.retornos.forEach((retorno, index) => {
        const dataFormatada = new Date(retorno.dataRetorno).toLocaleString('pt-BR');

        html += `
            <div style="background: white; padding: 10px; border-radius: 4px; margin-bottom: 8px; font-size: 0.85rem;">
                <div style="color: #dc2626; font-weight: 600; margin-bottom: 4px;">
                    📅 ${dataFormatada}
                </div>
                <div style="color: #475569; margin-bottom: 4px;">
                    👤 <strong>Retornado por:</strong> ${retorno.nomeUsuarioRetorno}
                </div>
                <div style="color: #475569; margin-bottom: 4px;">
                    🔄 <strong>Da etapa:</strong> ${retorno.etapaOrigem}. ${retorno.nomeEtapaOrigem}
                </div>
                <div style="color: #dc2626; margin-bottom: 4px;">
                    ⚠️ <strong>Motivo:</strong> ${retorno.motivo}
                </div>
                ${retorno.observacoes ? `
                    <div style="color: #64748b; margin-top: 6px; padding: 8px; background: #f8fafc; border-radius: 4px;">
                        💬 ${retorno.observacoes}
                    </div>
                ` : ''}
            </div>
        `;
    });

    html += '</div>';

    return html;
}