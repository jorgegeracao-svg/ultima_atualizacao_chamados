// ==================== DETALHES DO CHAMADO ====================

function showDetalhes(id) {
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === id);

    if (!chamado) return;

    const currentUser = getCurrentUser();
    const tipos = (Array.isArray(chamado.tipoManutencao) ? chamado.tipoManutencao : []).join(', ');

    // Renderizar timeline
    let timelineHTML = '<div class="timeline">';

    chamado.etapas.forEach((etapa, index) => {
        const config = ETAPAS_CONFIG[etapa.numero - 1];
        let markerClass = 'pending';
        let markerIcon = etapa.numero;

        if (etapa.status === 'CONCLUIDA') {
            markerClass = 'completed';
            markerIcon = '✓';
        } else if (etapa.numero === chamado.etapaAtual) {
            markerClass = 'active';
            if (etapa.prazo && new Date(etapa.prazo) < new Date()) {
                markerClass = 'delayed';
            }
        }

        let slaHTML = '';
        if (etapa.sla && etapa.prazo && etapa.status !== 'CONCLUIDA') {
            const prazo = new Date(etapa.prazo);
            const agora = new Date();
            const diff = prazo - agora;
            const totalMinutos = Math.floor(diff / 60000);
            const horas = Math.floor(Math.abs(totalMinutos) / 60);
            const minutos = Math.abs(totalMinutos) % 60;

            let slaClass = 'sla-ok';
            let slaText = '';

            if (diff < 0) {
                slaClass = 'sla-danger';
                slaText = `⏰ Atrasado ${horas}h ${minutos}min`;
            } else if (totalMinutos < 10) {
                slaClass = 'sla-danger';
                slaText = `⏱️ ${minutos} min restantes`;
            } else if (totalMinutos < 60) {
                slaClass = 'sla-warning';
                slaText = `⏱️ ${minutos} min restantes`;
            } else {
                slaText = `⏱️ ${horas}h ${minutos}min restantes`;
            }

            slaHTML = `<div class="timeline-sla ${slaClass}">${slaText}</div>`;
        }

        const responsavelNome = etapa.responsavel ?
            Storage.getUsuarios().find(u => u.usuario === etapa.responsavel)?.nomeCompleto || etapa.responsavel :
            config?.responsavel || 'Aguardando';

        // Tornar o nome clicável se houver um responsável específico
        const responsavelHTML = etapa.responsavel
            ? `<div class="timeline-subtitle timeline-subtitle-clickable" onclick="abrirPerfilColaborador('${etapa.responsavel}')" title="Clique para ver o perfil">👤 ${responsavelNome}</div>`
            : `<div class="timeline-subtitle">${responsavelNome}</div>`;

        timelineHTML += `
            <div class="timeline-item">
                ${index < chamado.etapas.length - 1 ? '<div class="timeline-line"></div>' : ''}
                <div class="timeline-marker ${markerClass}">${markerIcon}</div>
                <div class="timeline-content">
                    <div class="timeline-header">
                        <div>
                            <div class="timeline-title">${etapa.numero}. ${etapa.nome}</div>
                            ${responsavelHTML}
                        </div>
                        ${slaHTML}
                    </div>
                    <div class="timeline-body">
                        ${renderEtapaConteudo(chamado, etapa, currentUser)}
                    </div>
                </div>
            </div>
        `;
    });

    timelineHTML += '</div>';

    document.getElementById('detalhesContent').innerHTML = `
        <div class="details-card">
            <div class="card-header">
                <h2><span class="ticket-id">#${chamado.id}</span> - ${chamado.titulo}</h2>
                <p style="color: #64748b; margin-top: 8px;">
                    🏢 ${chamado.unidade || 'Unidade não informada'}<br>
                    📍 ${chamado.local} | 📞 ${chamado.telefone}<br>
                    🔧 ${tipos}
                </p>
                
                <!-- Botões de Navegação -->
                <div class="detalhes-tabs" style="display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap;">
                    <button class="tab-button active" onclick="trocarAbaDetalhes(${chamado.id}, 'etapas')" id="tabEtapas">
                        🎯 Etapas
                    </button>

                    <button class="tab-button" onclick="trocarAbaDetalhes(${chamado.id}, 'formularios')" id="tabFormularios">
                        📝 Formulários
                    </button>
                    <button class="tab-button" onclick="trocarAbaDetalhes(${chamado.id}, 'anexos')" id="tabAnexos">
                        📎 Anexos
                    </button>
                    <button class="tab-button" onclick="trocarAbaDetalhes(${chamado.id}, 'fluxo')" id="tabFluxo">
                        📊 Fluxo Completo
                    </button>
                </div>
            </div>
            
            <div class="card-body">
                <!-- Conteúdo da Aba Etapas -->
                <div id="abaEtapas" class="aba-conteudo active">
                    ${timelineHTML}

                    <!-- 🔥 BOTÕES DE VOLTAR ETAPA -->
                     ${renderBotoesVoltarEtapa(chamado, currentUser)}
                </div>


                <!-- Conteúdo da Aba Formulários -->
                <div id="abaFormularios" class="aba-conteudo" style="display: none;">
                    ${renderFormulariosDados(chamado)}
                </div>
                
                <!-- Conteúdo da Aba Anexos -->
                <div id="abaAnexos" class="aba-conteudo" style="display: none;">
                    ${renderAnexosDados(chamado)}
                </div>
                
                <!-- Conteúdo da Aba Fluxo -->
                <div id="abaFluxo" class="aba-conteudo" style="display: none;">
                    ${renderFluxoCompleto(chamado)}
                </div>
            </div>
            
            <div class="action-buttons">
                <button class="btn-action btn-secondary" onclick="voltarLista()">← Voltar</button>
            </div>
        </div>
    `;

    showScreen('detalhes');
}

function voltarLista() {
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.perfil === 'PROGRAMADOR') {
        showScreen('editar');
    } else {
        showScreen('entrada');
    }
}

// ==================== RENDERIZAÇÃO DO CONTEÚDO DAS ETAPAS ====================

function renderEtapaConteudo(chamado, etapa, currentUser) {
    console.log('🎨 Renderizando etapa:', etapa.numero, etapa.nome);
    console.log('🔍 Etapa tem retornos?', etapa.retornos ? `Sim (${etapa.retornos.length})` : 'Não');
    
    let html = '';

    // 🔥 EXIBIR HISTÓRICO DE RETORNOS NO TOPO SE EXISTIR
    if (etapa.retornos && etapa.retornos.length > 0) {
        console.log('✅ Chamando renderHistoricoRetornos para etapa', etapa.numero);
        const historicoHTML = renderHistoricoRetornos(etapa);
        console.log('📦 HTML do histórico gerado:', historicoHTML.substring(0, 100) + '...');
        html += historicoHTML;
    } else {
        console.log('⏭️ Nenhum retorno para exibir na etapa', etapa.numero);
    }

    if (etapa.dados && Object.keys(etapa.dados).length > 0) {
        html += '<div class="info-box">';

        // ETAPA 1: Descrição
        if (etapa.numero === 1) {
            html += `<strong>Descrição:</strong><p>${etapa.dados.descricao || '-'}</p>`;
        }

        // ETAPA 8: Avaliação e Comentários
        if (etapa.numero === 8 && etapa.status === 'CONCLUIDA') {
            const legendasAvaliacao = {
                1: 'Péssimo',
                2: 'Ruim',
                3: 'Regular',
                4: 'Bom',
                5: 'Perfeito'
            };

            const avaliacao = etapa.dados.avaliacao || 0;
            const estrelas = '⭐'.repeat(avaliacao);
            const avaliacaoTexto = legendasAvaliacao[avaliacao] || 'Não avaliado';
            
            html += `
                <div style="margin-bottom: 12px;">
                    <strong>⭐ Avaliação do Atendimento:</strong>
                    <div style="font-size: 1.3rem; margin: 8px 0;">${estrelas}</div>
                    <div style="color: #052659; font-weight: 600;">${avaliacaoTexto}</div>
                </div>
            `;
            
            if (etapa.dados.comentariosAvaliacao) {
                html += `
                    <div style="margin-top: 12px;">
                        <strong>💬 Comentários:</strong>
                        <p style="background: #f8fafc; padding: 12px; border-radius: 6px; margin-top: 6px; line-height: 1.6;">
                            ${etapa.dados.comentariosAvaliacao}
                        </p>
                    </div>
                `;
            }
        }

        // ETAPA 3: Não mostrar detalhes aqui pois já aparecem na aba Formulários
        // (removido para evitar duplicação)

        // Observações gerais
        if (etapa.dados.observacoes) {
            html += `<strong>Observações:</strong><p>${etapa.dados.observacoes}</p>`;
        }

        html += '</div>'; // Fecha a info-box

        // Informações fora da caixa - Data de Agendamento
        if (etapa.dados.dataAgendamento) {
            html += `
                <div class="info-box-externa">
                    <strong>📅 Data Agendada:</strong><br>
                    <span>${new Date(etapa.dados.dataAgendamento).toLocaleString('pt-BR')}</span>
                </div>
            `;
        }
    }

    // Verificar se é a etapa atual e se o usuário é responsável
    if (etapa.numero === chamado.etapaAtual) {
        const config = ETAPAS_CONFIG[etapa.numero - 1];

        // 🔥 ETAPA 1: Solicitante pode reeditar quando volta
        if (etapa.numero === 1 && chamado.solicitante === currentUser.usuario && etapa.status === 'EM_ANDAMENTO') {
            html += renderFormularioEtapa(chamado, etapa);
        }
        // Outras etapas: verificar por perfil
        else if (config && config.responsavel === currentUser.perfil) {
            html += renderFormularioEtapa(chamado, etapa);
        } else if (config && config.responsavel === 'SOLICITANTE' && chamado.solicitante === currentUser.usuario) {
            html += renderFormularioEtapa(chamado, etapa);
        } else {
            html += '<p style="color: #94a3b8; font-size: 0.9rem;">⏳ Aguardando ação do responsável</p>';
        }
    }

    // Mostrar data de conclusão se a etapa foi concluída
    if (etapa.dataConclusao) {
        html += `<p style="color: #10b981; font-size: 0.85rem; margin-top: 8px;">✓ Concluído em ${new Date(etapa.dataConclusao).toLocaleString('pt-BR')}</p>`;
    }

    return html;
}

// ==================== RENDERIZAÇÃO DOS FORMULÁRIOS POR ETAPA ====================

function renderFormularioEtapa(chamado, etapa) {
    let html = '<div class="etapa-form">';

    // 🔥 ETAPA 1: Reedição da Abertura do Chamado
    if (etapa.numero === 1) {
        const tiposManutencao = TIPOS_PROCESSOS.MANUTENCAO.opcoes;
        const dadosEtapa = etapa.dados || {};
        
        html += `
            <div style="background: #fef3c7; border: 1px solid #fbbf24; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
                <strong style="color: #92400e;">⚠️ Atenção</strong>
                <p style="color: #78350f; margin: 8px 0 0 0; font-size: 0.9rem;">
                    O chamado foi devolvido. Revise as informações e faça as correções necessárias.
                </p>
            </div>
            
            <div class="form-group">
                <label class="form-label">Título do Chamado *</label>
                <input type="text" id="tituloEdicao" class="form-control" value="${dadosEtapa.titulo || chamado.titulo}" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Telefone de Contato *</label>
                <input type="tel" id="telefoneEdicao" class="form-control" value="${dadosEtapa.telefone || chamado.telefone}" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Unidade *</label>
                <select id="unidadeEdicao" class="form-control" required>
                    ${UNIDADES.map(u => `<option value="${u}" ${(dadosEtapa.unidade || chamado.unidade) === u ? 'selected' : ''}>${u}</option>`).join('')}
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Local Específico *</label>
                <input type="text" id="localEdicao" class="form-control" value="${dadosEtapa.local || chamado.local}" 
                       placeholder="Ex: Prédio A, Sala 203" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Tipo de Manutenção * (selecione um ou mais)</label>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 12px; margin-top: 8px;">
                    ${tiposManutencao.map(tipo => {
                        const checked = (dadosEtapa.tipoManutencao || chamado.tipoManutencao || []).includes(tipo.valor) ? 'checked' : '';
                        return `
                            <label class="checkbox-label" style="display: flex; align-items: center; gap: 8px; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                                <input type="checkbox" name="tipoManutencaoEdicao" value="${tipo.valor}" ${checked}>
                                <span style="font-size: 1.2rem;">${tipo.icone}</span>
                                <span>${tipo.valor}</span>
                            </label>
                        `;
                    }).join('')}
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Descrição do Problema *</label>
                <textarea id="descricaoEdicao" class="form-control" rows="5" 
                          placeholder="Descreva detalhadamente o problema..." required>${dadosEtapa.descricao || chamado.descricao}</textarea>
            </div>
            
            <div class="form-group">
                <label class="form-label">Anexos (Opcional)</label>
                <input type="file" id="anexoEdicao" class="form-control" accept="image/*" multiple>
                <small style="color: #64748b; font-size: 0.85rem; display: block; margin-top: 4px;">
                    Você pode adicionar mais anexos (máximo 5 imagens de 5MB cada)
                </small>
                <div id="previewAnexoEdicao" style="margin-top: 12px;"></div>
            </div>
            
            <button class="btn-action btn-primary" onclick="concluirEtapa1Edicao(${chamado.id})">
                ✓ Confirmar Alterações
            </button>
        `;
    }

    // ETAPA 2: Agendamento da Avaliação
    else if (etapa.numero === 2) {
        html += `
            <div class="form-group">
                <label class="form-label">Data e Hora da Avaliação *</label>
                <input type="datetime-local" id="dataAgendamento" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Responsável pela Visita *</label>
                <input type="text" id="responsavelVisita" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Observações *</label>
                <textarea id="observacoes" class="form-control" rows="3" required></textarea>
                <small style="color: #64748b; font-size: 0.85rem; display: block; margin-top: 4px;">
                    Campo obrigatório
                </small>
            </div>
            <button class="btn-action btn-primary" onclick="concluirEtapa2(${chamado.id})">
                Agendar Avaliação →
            </button>
        `;
    }

    // ETAPA 3: Descrição do Serviço - REMOVIDO campo dataProximaEtapa
    else if (etapa.numero === 3) {
        html += `
            <div class="form-group">
                <label class="form-label">Tipo de Serviço *</label>
                <div style="display: flex; gap: 16px; margin-top: 8px;">
                    <label class="radio-label">
                        <input type="radio" name="tipoServico" value="PROTOCOLO" checked>
                        Protocolo (Manutenção Normal)
                    </label>
                    <label class="radio-label">
                        <input type="radio" name="tipoServico" value="PROJETO">
                        Projeto (Obra/Estrutural)
                    </label>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Descrição dos Serviços a Realizar *</label>
                <textarea id="servicosRealizados" class="form-control" rows="4" 
                          placeholder="Descreva detalhadamente os serviços que serão realizados..." required></textarea>
            </div>
            
            <div class="form-group">
                <label class="form-label">Produtos e Materiais Necessários</label>
                <div id="produtosContainer">
                    <div class="produto-item" style="display: grid; grid-template-columns: 2fr 1fr 80px; gap: 8px; margin-bottom: 8px;">
                        <input type="text" class="form-control" placeholder="Nome do produto" id="produto_0">
                        <input type="number" class="form-control" placeholder="Qtd" id="qtd_0" min="1">
                        <button type="button" onclick="removerProduto(0)" class="btn-action btn-secondary" style="padding: 8px;">🗑️</button>
                    </div>
                </div>
                <button type="button" onclick="adicionarProduto()" class="btn-action btn-secondary" style="margin-top: 8px; padding: 8px 16px;">
                    ➕ Adicionar Produto
                </button>
            </div>
            
            <div class="form-group">
                <label class="form-label">Observações Gerais</label>
                <textarea id="observacoesEtapa3" class="form-control" rows="3"></textarea>
            </div>
            
            <button class="btn-action btn-primary" onclick="concluirEtapa3(${chamado.id})">
                Confirmar Descrição do Serviço →
            </button>
        `;
    }

    // ETAPA 4: Verificação de Estoque
    else if (etapa.numero === 4) {
        // Buscar produtos da etapa 3
        const etapa3 = chamado.etapas.find(e => e.numero === 3);
        const produtos = etapa3?.dados?.produtos || [];

        html += `
            <div class="info-box" style="background: #eff6ff; border-left: 4px solid #3b82f6; margin-bottom: 20px;">
                <strong>📦 Produtos a Verificar:</strong>
        `;

        if (produtos.length > 0) {
            html += `
                <table style="width: 100%; margin-top: 12px; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #dbeafe; text-align: left;">
                            <th style="padding: 8px; border: 1px solid #bfdbfe;">Produto</th>
                            <th style="padding: 8px; border: 1px solid #bfdbfe; text-align: center; width: 100px;">Quantidade</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            produtos.forEach(produto => {
                html += `
                    <tr>
                        <td style="padding: 8px; border: 1px solid #bfdbfe;">${produto.nome}</td>
                        <td style="padding: 8px; border: 1px solid #bfdbfe; text-align: center;"><strong>${produto.quantidade}</strong></td>
                    </tr>
                `;
            });

            html += `
                    </tbody>
                </table>
            `;
        } else {
            html += `<p style="margin-top: 8px; color: #64748b; font-style: italic;">Nenhum produto cadastrado na etapa anterior</p>`;
        }

        html += `</div>`; // Fecha info-box dos produtos

        html += `
            <div class="form-group">
                <label class="form-label">Verificação de Estoque *</label>
                <div style="display: flex; gap: 16px; margin-top: 8px;">
                    <label class="radio-label">
                        <input type="radio" name="temEstoque" value="SIM" checked>
                        ✅ TEM em estoque (ir para Etapa 6)
                    </label>
                    <label class="radio-label">
                        <input type="radio" name="temEstoque" value="NAO">
                        ❌ NÃO TEM (ir para Compras - Etapa 5)
                    </label>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Observações</label>
                <textarea id="observacoesEtapa4" class="form-control" rows="3" 
                          placeholder="Informe detalhes sobre os produtos em estoque..."></textarea>
            </div>
            
            <button class="btn-action btn-primary" onclick="concluirEtapa4(${chamado.id})">
                Confirmar Verificação →
            </button>
        `;
    }

    // ETAPA 5: Compras (com subetapas)
    else if (etapa.numero === 5) {
        const subetapa = etapa.subetapa || 5.1;

        // SUBETAPA 5.1: Cotação
        if (subetapa === 5.1) {
            html += `
                <h4 style="color: #0ea5e9; margin-bottom: 12px;">5.1 - Cotação de Produtos</h4>
                <div class="form-group">
                    <label class="form-label">Data de Envio do Orçamento para Fornecedor *</label>
                    <input type="date" id="dataEnvioOrcamento" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Fornecedores Consultados</label>
                    <textarea id="fornecedores" class="form-control" rows="3" 
                              placeholder="Liste os fornecedores consultados..."></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Observações da Cotação</label>
                    <textarea id="observacoesCotacao" class="form-control" rows="3"></textarea>
                </div>
                
                <button class="btn-action btn-primary" onclick="concluirEtapa5_1(${chamado.id})">
                    Programar Envio do Orçamento →
                </button>
            `;
        }

        // SUBETAPA 5.2: Envio do Orçamento
        else if (subetapa === 5.2) {
            html += `
                <h4 style="color: #0ea5e9; margin-bottom: 12px;">5.2 - Envio do Orçamento para Aprovação</h4>
                <div class="form-group">
                    <label class="form-label">Valor Total do Orçamento *</label>
                    <input type="number" id="valorOrcamento" class="form-control" step="0.01" placeholder="0.00" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Fornecedor Selecionado *</label>
                    <input type="text" id="fornecedorSelecionado" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Detalhes do Orçamento</label>
                    <textarea id="detalhesOrcamento" class="form-control" rows="4" 
                              placeholder="Descreva os itens e valores..."></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Anexar Orçamento (PDF/Imagem)</label>
                    <input type="file" id="anexoOrcamento" class="form-control" accept=".pdf,image/*">
                </div>
                
                <button class="btn-action btn-primary" onclick="concluirEtapa5_2(${chamado.id})">
                    Enviar para Aprovação do Gestor →
                </button>
            `;
        }

        // SUBETAPA 5.3: Aprovação do Gestor
        else if (subetapa === 5.3) {
            const valorOrcamento = etapa.dados?.valorOrcamento || '0.00';
            const fornecedor = etapa.dados?.fornecedorSelecionado || '';

            html += `
                <h4 style="color: #0ea5e9; margin-bottom: 12px;">5.3 - Aprovação do Orçamento</h4>
                
                <div class="info-box" style="background: #e0f2fe; border-left: 4px solid #0ea5e9;">
                    <strong>Orçamento Recebido:</strong>
                    <p style="font-size: 1.2rem; color: #0ea5e9; margin: 8px 0;">R$ ${valorOrcamento}</p>
                    <p><strong>Fornecedor:</strong> ${fornecedor}</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Decisão *</label>
                    <div style="display: flex; gap: 16px; margin-top: 8px;">
                        <label class="radio-label">
                            <input type="radio" name="decisaoGestor" value="APROVADO" checked>
                            ✅ APROVAR Orçamento
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="decisaoGestor" value="REPROVADO">
                            ❌ REPROVAR Orçamento
                        </label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Justificativa/Observações</label>
                    <textarea id="justificativaGestor" class="form-control" rows="3"></textarea>
                </div>
                
                <button class="btn-action btn-primary" onclick="concluirEtapa5_3(${chamado.id})">
                    Confirmar Decisão →
                </button>
            `;
        }

        // SUBETAPA 5.4: Recebimento
        else if (subetapa === 5.4) {
            html += `
                <h4 style="color: #0ea5e9; margin-bottom: 12px;">5.4 - Recebimento das Mercadorias</h4>
                
                <div class="form-group">
                    <label class="form-label">Data de Recebimento *</label>
                    <input type="date" id="dataRecebimento" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Número da Nota Fiscal</label>
                    <input type="text" id="numeroNF" class="form-control" placeholder="Ex: 12345">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Anexar Nota Fiscal</label>
                    <input type="file" id="anexoNF" class="form-control" accept=".pdf,image/*">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Fotos dos Produtos Recebidos</label>
                    <input type="file" id="fotosProdutos" class="form-control" accept="image/*" multiple>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Conferência dos Produtos</label>
                    <textarea id="conferenciaRecebimento" class="form-control" rows="3" 
                              placeholder="Confirme se todos os produtos foram recebidos corretamente..."></textarea>
                </div>
                
                <button class="btn-action btn-primary" onclick="concluirEtapa5_4(${chamado.id})">
                    Confirmar Recebimento →
                </button>
            `;
        }
    }

    // ETAPA 6: Programação da Manutenção
    else if (etapa.numero === 6) {
        html += `
            <div class="form-group">
                <label class="form-label">Data da Manutenção *</label>
                <input type="datetime-local" id="dataManutencao" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Observações</label>
                <textarea id="observacoesEtapa6" class="form-control" rows="3"></textarea>
            </div>
            
            <button class="btn-action btn-primary" onclick="concluirEtapa6(${chamado.id})">
                Programar Manutenção →
            </button>
        `;
    }

    // ETAPA 7: Execução da Manutenção
    else if (etapa.numero === 7) {
        html += `
            <div class="form-group">
                <label class="form-label">Upload de Fotos do Serviço Realizado</label>
                <input type="file" id="fotosServico" class="form-control" accept="image/*" multiple>
                <small style="color: #64748b; font-size: 0.85rem; display: block; margin-top: 4px;">
                    Você pode anexar múltiplas fotos do serviço realizado
                </small>
            </div>
            
            <div class="form-group">
                <label class="form-label">Observações Finais</label>
                <textarea id="observacoesEtapa7" class="form-control" rows="3"></textarea>
            </div>
            
            <button class="btn-action btn-primary" onclick="concluirEtapa7(${chamado.id})">
                Finalizar Manutenção →
            </button>
        `;
    }

    // ETAPA 8: Avaliação Final
    else if (etapa.numero === 8) {
        html += `
            <div class="info-box" style="background: #dcfce7; border-left: 4px solid #10b981;">
                <strong>🎉 Manutenção Concluída!</strong>
                <p style="margin-top: 8px;">O serviço foi finalizado pelo técnico. Por favor, avalie o atendimento.</p>
            </div>
            
            <div class="form-group">
                <label class="form-label">Como você avalia o atendimento? *</label>
                
                <!-- Container de Avaliação -->
                <div style="background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 12px; padding: 24px; margin-top: 12px;">
                    
                    <!-- Estrelas -->
                    <div id="avaliacaoContainer" style="display: flex; justify-content: center; gap: 8px; margin-bottom: 16px;">
                        ${[1, 2, 3, 4, 5].map(i => `
                            <button type="button"
                                    id="estrela${i}" 
                                    class="btn-estrela" 
                                    data-rating="${i}"
                                    style="background: none; border: none; padding: 8px; cursor: pointer; transition: all 0.3s ease; transform: scale(1);"
                                    onclick="selecionarEstrela(${i})"
                                    onmouseenter="hoverEstrela(${i})"
                                    onmouseleave="unhoverEstrela()">
                                <svg width="48" height="48" viewBox="0 0 24 24" fill="#cbd5e1" stroke="#94a3b8" stroke-width="1.5">
                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                </svg>
                            </button>
                        `).join('')}
                    </div>
                    
                    <!-- Texto da Avaliação -->
                    <div id="avaliacaoTexto" style="text-align: center; font-size: 1.1rem; font-weight: 600; color: #052659; min-height: 30px; margin-bottom: 12px;"></div>
                    
                    <!-- Descrições das Avaliações -->
                    <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-top: 20px; font-size: 0.75rem; color: #64748b; text-align: center;">
                        <div>Péssimo</div>
                        <div>Ruim</div>
                        <div>Regular</div>
                        <div>Bom</div>
                        <div>Excelente</div>
                    </div>
                </div>
                
                <input type="hidden" id="avaliacaoHidden" name="avaliacao" value="">
            </div>
            
            <div class="form-group">
                <label class="form-label">Comentários sobre o Atendimento (Opcional)</label>
                <textarea id="comentariosAvaliacao" class="form-control" rows="4" 
                          placeholder="Conte-nos sobre sua experiência com o atendimento recebido..."></textarea>
            </div>
            
            <button class="btn-action btn-primary" onclick="concluirEtapa8(${chamado.id})">
                ✓ Finalizar Chamado
            </button>
        `;
    }

    html += '</div>';
    return html;
}

// ==================== FUNÇÕES AUXILIARES ====================

// Adicionar novo produto à lista
function adicionarProduto() {
    const container = document.getElementById('produtosContainer');
    if (!container) return;

    const index = container.children.length;
    const novoProduto = document.createElement('div');
    novoProduto.className = 'produto-item';
    novoProduto.style.cssText = 'display: grid; grid-template-columns: 2fr 1fr 80px; gap: 8px; margin-bottom: 8px;';
    novoProduto.innerHTML = `
        <input type="text" class="form-control" placeholder="Nome do produto" id="produto_${index}">
        <input type="number" class="form-control" placeholder="Qtd" id="qtd_${index}" min="1">
        <button type="button" onclick="removerProduto(${index})" class="btn-action btn-secondary" style="padding: 8px;">🗑️</button>
    `;
    container.appendChild(novoProduto);
}

// Remover produto da lista
function removerProduto(index) {
    const container = document.getElementById('produtosContainer');
    if (!container) return;

    const items = container.querySelectorAll('.produto-item');
    if (items.length > 1 && items[index]) {
        items[index].remove();
    } else {
        alert('Deve haver pelo menos um produto na lista.');
    }
}

// Selecionar estrelas para avaliação
function selecionarEstrela(rating) {
    console.log('Avaliação selecionada:', rating);
    
    // Atualizar todas as estrelas
    for (let i = 1; i <= 5; i++) {
        const estrela = document.getElementById(`estrela${i}`);
        if (estrela) {
            const svg = estrela.querySelector('svg');
            if (svg) {
                if (i <= rating) {
                    // Estrela preenchida
                    svg.setAttribute('fill', '#fbbf24');
                    svg.setAttribute('stroke', '#f59e0b');
                    estrela.style.transform = 'scale(1.1)';
                } else {
                    // Estrela vazia
                    svg.setAttribute('fill', '#cbd5e1');
                    svg.setAttribute('stroke', '#94a3b8');
                    estrela.style.transform = 'scale(1)';
                }
            }
        }
    }
    
    // Salvar valor no campo hidden
    const hiddenInput = document.getElementById('avaliacaoHidden');
    if (hiddenInput) {
        hiddenInput.value = rating;
    }
    
    // Atualizar texto descritivo com emojis
    const textos = {
        1: '😞 Péssimo - Muito insatisfeito',
        2: '😕 Ruim - Insatisfeito',
        3: '😐 Regular - Neutro',
        4: '😊 Bom - Satisfeito',
        5: '🤩 Excelente - Muito satisfeito'
    };
    
    const avaliacaoTexto = document.getElementById('avaliacaoTexto');
    if (avaliacaoTexto) {
        avaliacaoTexto.textContent = textos[rating] || '';
        avaliacaoTexto.style.opacity = '0';
        setTimeout(() => {
            avaliacaoTexto.style.transition = 'opacity 0.3s ease';
            avaliacaoTexto.style.opacity = '1';
        }, 50);
    }
}

// Hover nas estrelas (preview)
function hoverEstrela(rating) {
    const hiddenInput = document.getElementById('avaliacaoHidden');
    const avaliacaoAtual = hiddenInput ? parseInt(hiddenInput.value) : 0;
    
    // Só faz preview se ainda não tiver avaliação selecionada
    if (!avaliacaoAtual) {
        for (let i = 1; i <= 5; i++) {
            const estrela = document.getElementById(`estrela${i}`);
            if (estrela) {
                const svg = estrela.querySelector('svg');
                if (svg) {
                    if (i <= rating) {
                        svg.setAttribute('fill', '#fde047');
                        svg.setAttribute('stroke', '#facc15');
                        estrela.style.transform = 'scale(1.15)';
                    } else {
                        svg.setAttribute('fill', '#cbd5e1');
                        svg.setAttribute('stroke', '#94a3b8');
                        estrela.style.transform = 'scale(1)';
                    }
                }
            }
        }
    }
}

// Remove hover das estrelas
function unhoverEstrela() {
    const hiddenInput = document.getElementById('avaliacaoHidden');
    const avaliacaoAtual = hiddenInput ? parseInt(hiddenInput.value) : 0;
    
    // Só remove preview se ainda não tiver avaliação selecionada
    if (!avaliacaoAtual) {
        for (let i = 1; i <= 5; i++) {
            const estrela = document.getElementById(`estrela${i}`);
            if (estrela) {
                const svg = estrela.querySelector('svg');
                if (svg) {
                    svg.setAttribute('fill', '#cbd5e1');
                    svg.setAttribute('stroke', '#94a3b8');
                    estrela.style.transform = 'scale(1)';
                }
            }
        }
    } else {
        // Se já tem avaliação, restaura a seleção
        selecionarEstrela(avaliacaoAtual);
    }
}

// Validar campos obrigatórios do formulário
function validarFormularioEtapa() {
    const requiredFields = document.querySelectorAll('.etapa-form [required]');

    for (const field of requiredFields) {
        if (!field.value || !field.value.trim()) {
            const label = field.previousElementSibling;
            const fieldName = label ? label.textContent.replace(' *', '') : 'campo obrigatório';
            alert(`Por favor, preencha o campo: ${fieldName}`);
            field.focus();
            return false;
        }
    }

    return true;
}

// ==================== VISUALIZAÇÃO DO FLUXO COMPLETO ====================

function mostrarFluxoCompleto(chamadoId) {
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);

    if (!chamado) return;

    let html = `
        <div style="padding: 24px; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h3 style="color: #1e293b; margin-bottom: 20px; border-bottom: 2px solid #0ea5e9; padding-bottom: 12px;">
                📋 Fluxo Completo - Chamado #${chamado.id}
            </h3>
    `;

    ETAPAS_CONFIG.forEach((config, index) => {
        const etapaRealizada = chamado.etapas.find(e => e.numero === config.numero);
        const isConcluida = etapaRealizada && etapaRealizada.status === 'CONCLUIDA';
        const isAtual = chamado.etapaAtual === config.numero;

        html += `
            <div style="margin-bottom: 16px; padding: 12px; background: ${isConcluida ? '#f0fdf4' : isAtual ? '#eff6ff' : '#f8fafc'}; border-left: 4px solid ${isConcluida ? '#10b981' : isAtual ? '#0ea5e9' : '#cbd5e1'}; border-radius: 4px;">
                <div style="font-weight: 600; color: ${isConcluida ? '#10b981' : isAtual ? '#0ea5e9' : '#64748b'};">
                    ${isConcluida ? '✅' : isAtual ? '⏳' : '⭕'} ${config.numero}. ${config.nome}
                </div>
                <div style="font-size: 0.85rem; color: #64748b; margin-top: 4px;">
                    Responsável: ${config.responsavel}
                </div>
                ${config.sla ? `<div style="font-size: 0.85rem; color: #64748b;">SLA: ${config.sla} minutos</div>` : ''}
            </div>
        `;
    });

    html += `
            <button onclick="showDetalhes(${chamado.id})" class="btn-action btn-secondary" style="margin-top: 16px;">
                ← Voltar aos Detalhes
            </button>
        </div>
    `;

    document.getElementById('detalhesContent').innerHTML = html;
}

// ==================== SISTEMA DE ABAS DOS DETALHES ====================


function trocarAbaDetalhes(chamadoId, aba) {
    // Remover classe active de todos os botões
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));

    // Adicionar classe active no botão clicado
    const tabId = 'tab' + aba.charAt(0).toUpperCase() + aba.slice(1);
    const tabButton = document.getElementById(tabId);
    if (tabButton) {
        tabButton.classList.add('active');
    }

    // Esconder todas as abas
    document.querySelectorAll('.aba-conteudo').forEach(div => {
        div.style.display = 'none';
    });

    // Mostrar aba selecionada
    const abaId = 'aba' + aba.charAt(0).toUpperCase() + aba.slice(1);
    const abaConteudo = document.getElementById(abaId);
    if (abaConteudo) {
        abaConteudo.style.display = 'block';
    }
}

// ==================== RENDERIZAÇÃO DA ABA FORMULÁRIOS ====================

function renderFormulariosDados(chamado) {
    let html = '<div style="padding: 16px;">';
    html += '<h3 style="color: #052659; margin-bottom: 16px; border-bottom: 2px solid #5483B3; padding-bottom: 8px; font-size: 1.1rem;">📝 Dados Preenchidos nas Etapas</h3>';

    chamado.etapas.forEach(etapa => {
        // Só mostrar etapas que têm dados preenchidos
        if (etapa.dados && Object.keys(etapa.dados).length > 0) {
            html += `
                <div style="background: #ffffff; border: 1px solid #C1E8FF; border-radius: 6px; padding: 0; margin-bottom: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(2, 16, 36, 0.08);">
                    <h4 style="background: linear-gradient(135deg, #052659 0%, #5483B3 100%); color: white; margin: 0; padding: 10px 14px; font-size: 0.95rem; font-weight: 600;">
                        ETAPA ${etapa.numero}: ${etapa.nome.toUpperCase()}
                    </h4>
                    <div style="padding: 14px;">
            `;

            // ETAPA 1 - Abertura do Chamado
            if (etapa.numero === 1) {
                html += `
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 12px; font-size: 0.9rem;">
                        ${etapa.dados.unidade ? `<div style="padding: 8px 12px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">🏢 Unidade:</strong><br>${etapa.dados.unidade}</div>` : ''}
                        ${etapa.dados.local ? `<div style="padding: 8px 12px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📍 Local:</strong><br>${etapa.dados.local}</div>` : ''}
                        ${etapa.dados.tipoManutencao ? `<div style="padding: 8px 12px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">🔧 Tipo de Manutenção:</strong><br>${etapa.dados.tipoManutencao.join(', ')}</div>` : ''}
                    </div>
                `;
            }

            // ETAPA 2 - Agendamento da Avaliação Física
            if (etapa.numero === 2) {
                html += `
                    <div style="display: grid; gap: 8px; font-size: 0.9rem;">
                        ${etapa.dados.dataAgendamento ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📅 Data Agendada:</strong> ${new Date(etapa.dados.dataAgendamento).toLocaleString('pt-BR')}</div>` : ''}
                        ${etapa.dados.responsavelVisita ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">👤 Responsável pela Visita:</strong> ${etapa.dados.responsavelVisita}</div>` : ''}
                    </div>
                `;
            }

            // ETAPA 3 - Descrição do Serviço
            if (etapa.numero === 3) {
                html += `
                    <div style="display: grid; gap: 8px; font-size: 0.9rem;">
                        ${etapa.dados.tipoServico ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">⚙️ Tipo de Serviço:</strong> ${etapa.dados.tipoServico === 'PROTOCOLO' ? 'Protocolo (Manutenção Normal)' : 'Projeto (Obra/Estrutural)'}</div>` : ''}
                        ${etapa.dados.servicosRealizados ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📝 Descrição dos Serviços:</strong> ${etapa.dados.servicosRealizados}</div>` : ''}
                    </div>
                `;

                // Mostrar produtos se existirem
                if (etapa.dados.produtos && etapa.dados.produtos.length > 0) {
                    html += `
                        <div style="margin-top: 12px;">
                            <strong style="color: #052659; font-size: 0.9rem;">📦 Produtos Necessários:</strong>
                            <table style="width: 100%; margin-top: 6px; border-collapse: collapse; font-size: 0.85rem;">
                                <thead>
                                    <tr style="background: linear-gradient(135deg, #C1E8FF 0%, #7DA0CA 100%);">
                                        <th style="padding: 6px 8px; border: 1px solid #7DA0CA; text-align: left; color: #021024; font-weight: 600;">Produto</th>
                                        <th style="padding: 6px 8px; border: 1px solid #7DA0CA; text-align: center; width: 100px; color: #021024; font-weight: 600;">Quantidade</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;

                    etapa.dados.produtos.forEach(produto => {
                        html += `
                            <tr style="background: #ffffff;">
                                <td style="padding: 6px 8px; border: 1px solid #C1E8FF;">${produto.nome}</td>
                                <td style="padding: 6px 8px; border: 1px solid #C1E8FF; text-align: center; font-weight: 500;">${produto.quantidade}</td>
                            </tr>
                        `;
                    });

                    html += `
                                </tbody>
                            </table>
                        </div>
                    `;
                }
            }

            // ETAPA 4 - Verificação de Estoque
            if (etapa.numero === 4) {
                html += `
                    <div style="display: grid; gap: 8px; font-size: 0.9rem;">
                        ${etapa.dados.temEstoque !== undefined ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📦 Tem em Estoque?</strong> ${etapa.dados.temEstoque ? '✅ Sim' : '❌ Não'}</div>` : ''}
                    </div>
                `;
            }

            // ETAPA 5 - Processo de Compras (subetapas)
            if (etapa.numero === 5) {
                html += `<div style="display: grid; gap: 8px; font-size: 0.9rem;">`;
                if (etapa.dados.cotacao) {
                    html += `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">💰 Cotação:</strong> ${etapa.dados.cotacao}</div>`;
                }
                if (etapa.dados.orcamento) {
                    html += `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📄 Orçamento:</strong> ${etapa.dados.orcamento}</div>`;
                }
                if (etapa.dados.aprovacao) {
                    html += `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">✅ Aprovação:</strong> ${etapa.dados.aprovacao}</div>`;
                }
                if (etapa.dados.observacoes) {
                    html += `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📋 Observações:</strong> ${etapa.dados.observacoes}</div>`;
                }
                html += `</div>`;
            }

            // ETAPA 6 - Programar Data de Manutenção
            if (etapa.numero === 6) {
                html += `
                    <div style="display: grid; gap: 8px; font-size: 0.9rem;">
                        ${etapa.dados.dataManutencao ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📅 Data da Manutenção:</strong> ${new Date(etapa.dados.dataManutencao).toLocaleString('pt-BR')}</div>` : ''}
                        ${etapa.dados.observacoes ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📋 Observações:</strong> ${etapa.dados.observacoes}</div>` : ''}
                    </div>
                `;
            }

            // ETAPA 7 - Realizar Manutenção
            if (etapa.numero === 7) {
                html += `
                    <div style="display: grid; gap: 8px; font-size: 0.9rem;">
                        ${etapa.dataConclusao ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">📅 Data da Realização:</strong> ${new Date(etapa.dataConclusao).toLocaleDateString('pt-BR')}</div>` : ''}
                    </div>
                `;
            }

            // ETAPA 8 - Finalizar Chamado
            if (etapa.numero === 8) {
                // Definir legenda da avaliação
                const legendasAvaliacao = {
                    1: 'Péssimo',
                    2: 'Ruim',
                    3: 'Regular',
                    4: 'Bom',
                    5: 'Perfeito'
                };

                const avaliacaoTexto = etapa.dados.avaliacao
                    ? `${'⭐'.repeat(etapa.dados.avaliacao)} ${legendasAvaliacao[etapa.dados.avaliacao]}`
                    : 'Não avaliado';

                html += `
                    <div style="display: grid; gap: 8px; font-size: 0.9rem;">
                        <div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;">
                            <strong style="color: #052659;">⭐ Avaliação do Atendimento:</strong> ${avaliacaoTexto}
                        </div>
                        ${etapa.dados.comentariosAvaliacao ? `<div style="padding: 6px 10px; background: #f8fafc; border-left: 3px solid #5483B3; border-radius: 3px;"><strong style="color: #052659;">💬 Comentários:</strong> ${etapa.dados.comentariosAvaliacao}</div>` : ''}
                    </div>
                `;
            }

            html += '</div></div>'; // Fecha o padding e o card da etapa
        }
    });

    // Se nenhuma etapa tem dados
    if (!chamado.etapas.some(e => e.dados && Object.keys(e.dados).length > 0)) {
        html += `
            <div style="text-align: center; padding: 40px; color: #7DA0CA;">
                📝 Nenhum dado foi preenchido ainda.
            </div>
        `;
    }

    html += '</div>';
    return html;
}

// ==================== RENDERIZAÇÃO DA ABA ANEXOS ====================

function renderAnexosDados(chamado) {
    let html = '<div style="padding: 20px;">';
    html += '<h3 style="color: #1e293b; margin-bottom: 20px; border-bottom: 2px solid #0ea5e9; padding-bottom: 12px;">📎 Anexos do Chamado</h3>';

    let temAnexos = false;

    // Anexos da Etapa 1 (abertura do chamado)
    if (chamado.anexos && chamado.anexos.length > 0) {
        temAnexos = true;
        html += `
            <div style="margin-bottom: 30px;">
                <h4 style="color: #052659; font-size: 1rem; margin-bottom: 12px; padding: 8px; background: linear-gradient(135deg, #C1E8FF 0%, #7DA0CA 100%); border-radius: 4px;">
                    📋 ETAPA 1: Abertura do Chamado
                </h4>
        `;

        chamado.anexos.forEach((anexo, index) => {
            html += `
                <div style="margin-bottom: 20px; margin-left: 20px; border: 2px solid #e2e8f0; border-radius: 8px; padding: 16px; background: #f8fafc;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div style="font-weight: 600; color: #1e293b;">
                            📎 ${anexo.nome}
                        </div>
                        <button onclick="baixarAnexo('${anexo.data}', '${anexo.nome}')" 
                                style="background: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; display: flex; align-items: center; gap: 6px;">
                            ⬇️ Baixar
                        </button>
                    </div>
                    <img src="${anexo.data}" alt="${anexo.nome}" 
                         style="max-width: 100%; max-height: 400px; object-fit: contain; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); cursor: pointer;"
                         onclick="window.open('${anexo.data}', '_blank')">
                    <div style="margin-top: 8px; font-size: 0.85rem; color: #64748b;">
                        Tamanho: ${(anexo.tamanho / 1024).toFixed(2)} KB
                    </div>
                </div>
            `;
        });

        html += '</div>';
    }

    // Anexos da Etapa 7 (fotos do serviço)
    const etapa7 = chamado.etapas.find(e => e.numero === 7);
    if (etapa7 && etapa7.dados && etapa7.dados.fotosServico && etapa7.dados.fotosServico.length > 0) {
        temAnexos = true;
        html += `
            <div style="margin-bottom: 30px;">
                <h4 style="color: #052659; font-size: 1rem; margin-bottom: 12px; padding: 8px; background: linear-gradient(135deg, #C1E8FF 0%, #7DA0CA 100%); border-radius: 4px;">
                    📸 ETAPA 7: Fotos do Serviço Realizado
                </h4>
        `;

        etapa7.dados.fotosServico.forEach((foto, index) => {
            html += `
                <div style="margin-bottom: 20px; margin-left: 20px; border: 2px solid #e2e8f0; border-radius: 8px; padding: 16px; background: #f8fafc;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div style="font-weight: 600; color: #1e293b;">
                            📸 ${foto.nome}
                        </div>
                        <button onclick="baixarAnexo('${foto.data}', '${foto.nome}')" 
                                style="background: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; display: flex; align-items: center; gap: 6px;">
                            ⬇️ Baixar
                        </button>
                    </div>
                    <img src="${foto.data}" alt="${foto.nome}" 
                         style="max-width: 100%; max-height: 400px; object-fit: contain; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); cursor: pointer;"
                         onclick="window.open('${foto.data}', '_blank')">
                    <div style="margin-top: 8px; font-size: 0.85rem; color: #64748b;">
                        Tamanho: ${(foto.tamanho / 1024).toFixed(2)} KB
                    </div>
                </div>
            `;
        });

        html += '</div>';
    }

    // Se não houver anexos
    if (!temAnexos) {
        html += `
            <div style="text-align: center; padding: 60px; color: #94a3b8;">
                📎 Nenhum anexo ou foto neste chamado.
            </div>
        `;
    }

    html += '</div>';
    return html;
}

// ==================== RENDERIZAÇÃO DA ABA FLUXO COMPLETO ====================

function renderFluxoCompleto(chamado) {
    const usuarios = Storage.getUsuarios();

    let html = `
        <div style="padding: 20px;">
            <h3 style="color: #1e293b; margin-bottom: 24px; border-bottom: 2px solid #0ea5e9; padding-bottom: 12px;">
                📊 Fluxo Completo das Etapas
            </h3>
            <div style="position: relative; padding-left: 40px;">
    `;

    ETAPAS_CONFIG.forEach((config, index) => {
        const etapaExistente = chamado.etapas.find(e => e.numero === config.numero);
        let statusClass = 'pending';
        let statusIcon = '⏳';
        let statusText = 'Pendente';
        let borderColor = '#cbd5e1';
        let bgColor = '#f1f5f9';
        let textColor = '#475569';

        // Informações do responsável
        let responsavelNome = config.responsavel;
        let slaInfo = '';
        let slaTexto = config.sla ? `${config.sla} minutos` : 'Sem prazo definido';

        if (etapaExistente) {
            // Buscar nome do responsável
            if (etapaExistente.responsavel) {
                const usuario = usuarios.find(u => u.usuario === etapaExistente.responsavel);
                responsavelNome = `${config.responsavel}: ${usuario ? usuario.nomeCompleto : etapaExistente.responsavel}`;
            }

            if (etapaExistente.status === 'CONCLUIDA') {
                statusClass = 'completed';
                statusIcon = '✅';
                statusText = 'Concluída';
                borderColor = '#10b981';
                bgColor = '#d1fae5';
                textColor = '#065f46';

                // Calcular tempo real de atendimento para etapas concluídas
                if (etapaExistente.dataInicio && etapaExistente.dataConclusao && config.sla) {
                    const tempoReal = calcularTempoDecorrido(etapaExistente.dataInicio, etapaExistente.dataConclusao);
                    slaTexto = formatarSLAComTempoReal(config.sla, etapaExistente.dataInicio, etapaExistente.dataConclusao);
                }
            } else if (etapaExistente.numero === chamado.etapaAtual) {
                statusClass = 'active';
                statusIcon = '🔄';
                borderColor = '#0ea5e9';
                bgColor = '#dbeafe';
                textColor = '#1e40af';

                // Calcular status do SLA
                if (etapaExistente.sla && etapaExistente.prazo) {
                    const prazo = new Date(etapaExistente.prazo);
                    const agora = new Date();
                    const diff = prazo - agora;
                    const totalMinutos = Math.floor(diff / 60000);
                    const horas = Math.floor(Math.abs(totalMinutos) / 60);
                    const minutos = Math.abs(totalMinutos) % 60;

                    if (diff < 0) {
                        slaInfo = `⚠️ <strong style="color: #dc2626;">Atrasado</strong> (${horas}h ${minutos}min)`;
                        statusText = `Em Andamento: ${etapaExistente.responsavel ? usuarios.find(u => u.usuario === etapaExistente.responsavel)?.nomeCompleto || etapaExistente.responsavel : 'Aguardando'}`;
                    } else if (totalMinutos < 10) {
                        slaInfo = `⚠️ <strong style="color: #f59e0b;">Crítico</strong> (${minutos} min restantes)`;
                        statusText = `Em Andamento: ${etapaExistente.responsavel ? usuarios.find(u => u.usuario === etapaExistente.responsavel)?.nomeCompleto || etapaExistente.responsavel : 'Aguardando'}`;
                    } else {
                        slaInfo = `✅ <strong style="color: #10b981;">No Prazo</strong> (${horas}h ${minutos}min restantes)`;
                        statusText = `Em Andamento: ${etapaExistente.responsavel ? usuarios.find(u => u.usuario === etapaExistente.responsavel)?.nomeCompleto || etapaExistente.responsavel : 'Aguardando'}`;
                    }
                } else {
                    statusText = `Em Andamento: ${etapaExistente.responsavel ? usuarios.find(u => u.usuario === etapaExistente.responsavel)?.nomeCompleto || etapaExistente.responsavel : 'Aguardando'}`;
                }
            }
        }

        // Linha vertical conectora (exceto no último)
        const linhaConectora = index < ETAPAS_CONFIG.length - 1 ? `
            <div style="position: absolute; left: 15px; top: 50px; width: 3px; height: calc(100% + 12px); background: ${borderColor};"></div>
        ` : '';

        html += `
            <div style="position: relative; margin-bottom: 24px;">
                ${linhaConectora}
                
                <!-- Círculo da etapa -->
                <div style="position: absolute; left: -40px; top: 8px; width: 32px; height: 32px; border-radius: 50%; background: ${borderColor}; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 0.9rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); z-index: 1;">
                    ${config.numero}
                </div>
                
                <!-- Card da etapa -->
                <div style="background: ${bgColor}; border-left: 4px solid ${borderColor}; padding: 16px 16px 16px 20px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <div style="margin-bottom: 10px;">
                        <div style="font-weight: 700; color: #1e293b; font-size: 1.05rem; margin-bottom: 8px;">
                            ${config.nome}
                        </div>
                        
                        <div style="display: grid; gap: 6px; font-size: 0.9rem;">
                            <div style="color: #475569;">
                                👤 <strong>Responsável:</strong> ${responsavelNome}
                            </div>
                            
                            <div style="color: #475569;">
                                ${slaTexto}${slaInfo ? ` - ${slaInfo}` : ''}
                            </div>
                            
                            <div style="margin-top: 4px; padding: 8px 12px; background: white; border-radius: 4px; font-weight: 600; color: ${textColor}; border: 1px solid ${borderColor};">
                                ${statusIcon} ${statusText}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    html += `
            </div>
        </div>
    `;
    return html;
}

function mostrarLoading() {
    const bar = document.getElementById('loadingBar');
    bar.classList.remove('hidden');
    setTimeout(() => bar.classList.add('active'), 50);
}

function esconderLoading() {
    const bar = document.getElementById('loadingBar');
    bar.classList.remove('active');
    setTimeout(() => bar.classList.add('hidden'), 400);
}