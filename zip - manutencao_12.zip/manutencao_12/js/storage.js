// ==================== GERENCIAMENTO DE STORAGE ====================

const Storage = {
    // Usuários
    getUsuarios() {
        const usuarios = localStorage.getItem('usuarios');
        return usuarios ? JSON.parse(usuarios) : [];
    },

    saveUsuarios(usuarios) {
        localStorage.setItem('usuarios', JSON.stringify(usuarios));
    },

    // Chamados
    getChamados() {
        const chamados = localStorage.getItem('chamados');
        return chamados ? JSON.parse(chamados) : [];
    },

    saveChamados(chamados) {
        localStorage.setItem('chamados', JSON.stringify(chamados));
    },

    // Usuário atual
    getCurrentUserLogin() {
        return localStorage.getItem('currentUser');
    },

    setCurrentUserLogin(username) {
        localStorage.setItem('currentUser', username);
    },

    removeCurrentUserLogin() {
        localStorage.removeItem('currentUser');
    },

    // Limpar dados
    limparChamados() {
        localStorage.removeItem('chamados');
    },

    limparTudo() {
        localStorage.clear();
    }
};

// Funções compatíveis com código legado
function getUsuarios() {
    return Storage.getUsuarios();
}

function saveUsuarios(usuarios) {
    Storage.saveUsuarios(usuarios);
}

function getChamados() {
    return Storage.getChamados();
}

function saveChamados(chamados) {
    Storage.saveChamados(chamados);
}