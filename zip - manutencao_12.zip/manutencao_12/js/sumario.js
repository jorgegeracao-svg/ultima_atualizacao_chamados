// ==================== SUMÁRIO DE ETAPAS (FORMATO PDF) ====================

/**
 * Renderiza o sumário das etapas em formato PDF
 * @param {object} chamado - Objeto do chamado
 * @returns {string} HTML do sumário
 */
function renderSumarioEtapas(chamado) {
    const solicitante = Storage.getUsuarios().find(u => u.usuario === chamado.solicitante);
    const dataAbertura = new Date(chamado.dataAbertura).toLocaleDateString('pt-BR');
    const horaAbertura = new Date(chamado.dataAbertura).toLocaleTimeString('pt-BR');
    
    // Calcular prazo total estimado
    const prazoTotal = calcularPrazoTotalEstimado(chamado);
    
    // Status do chamado
    let statusBadge = '';
    let statusIcon = '';
    
    switch(chamado.status) {
        case 'EM_ANDAMENTO':
            statusBadge = '<span class="pdf-badge pdf-badge-progress">🔄 Em Andamento</span>';
            statusIcon = '🔄';
            break;
        case 'CONCLUIDO':
            statusBadge = '<span class="pdf-badge pdf-badge-success">✅ Concluído</span>';
            statusIcon = '✅';
            break;
        case 'CANCELADO':
            statusBadge = '<span class="pdf-badge pdf-badge-danger">❌ Cancelado</span>';
            statusIcon = '❌';
            break;
    }
    
    // Tipo de manutenção
    const tipos = chamado.tipoManutencao.join(', ');
    
    return `
        <div class="pdf-container">
            <!-- Cabeçalho do Documento -->
            <div class="pdf-header">
                <div class="pdf-header-content">
                    <div class="pdf-logo">
                        <div class="pdf-logo-icon">🔧</div>
                        <div class="pdf-logo-text">
                            <h2>Sistema de Chamados</h2>
                            <p>Relatório de Etapas</p>
                        </div>
                    </div>
                    <div class="pdf-metadata">
                        <div class="pdf-meta-item">
                            <span class="pdf-meta-label">Gerado em:</span>
                            <span class="pdf-meta-value">${new Date().toLocaleString('pt-BR')}</span>
                        </div>
                        <div class="pdf-meta-item">
                            <span class="pdf-meta-label">Documento:</span>
                            <span class="pdf-meta-value">CHAMADO-${String(chamado.id).padStart(6, '0')}</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Informações do Chamado -->
            <div class="pdf-section">
                <div class="pdf-section-header">
                    <h3>📋 Informações do Chamado</h3>
                </div>
                <div class="pdf-section-body">
                    <div class="pdf-info-grid">
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Número do Chamado:</span>
                            <span class="pdf-info-value">#${chamado.id}</span>
                        </div>
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Status:</span>
                            <span class="pdf-info-value">${statusBadge}</span>
                        </div>
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Data de Abertura:</span>
                            <span class="pdf-info-value">${dataAbertura} às ${horaAbertura}</span>
                        </div>
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Solicitante:</span>
                            <span class="pdf-info-value">${solicitante?.nomeCompleto || chamado.solicitante}</span>
                        </div>
                        <div class="pdf-info-item pdf-info-item-full">
                            <span class="pdf-info-label">Título:</span>
                            <span class="pdf-info-value">${chamado.titulo}</span>
                        </div>
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Unidade:</span>
                            <span class="pdf-info-value">${chamado.unidade || '-'}</span>
                        </div>
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Local:</span>
                            <span class="pdf-info-value">${chamado.local || '-'}</span>
                        </div>
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Telefone:</span>
                            <span class="pdf-info-value">${chamado.telefone || '-'}</span>
                        </div>
                        <div class="pdf-info-item">
                            <span class="pdf-info-label">Tipo de Manutenção:</span>
                            <span class="pdf-info-value">${tipos}</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Resumo de Progresso -->
            <div class="pdf-section">
                <div class="pdf-section-header">
                    <h3>📊 Resumo de Progresso</h3>
                </div>
                <div class="pdf-section-body">
                    ${renderResumoProgresso(chamado)}
                </div>
            </div>
            
            <!-- Timeline de Etapas -->
            <div class="pdf-section">
                <div class="pdf-section-header">
                    <h3>🎯 Fluxo de Etapas</h3>
                </div>
                <div class="pdf-section-body">
                    ${renderTimelinePDF(chamado)}
                </div>
            </div>
            
            <!-- Rodapé do Documento -->
            <div class="pdf-footer">
                <p>Este documento foi gerado automaticamente pelo Sistema de Chamados</p>
                <p>Documento: CHAMADO-${String(chamado.id).padStart(6, '0')} | Página 1 de 1</p>
            </div>
        </div>
    `;
}

/**
 * Renderiza o resumo de progresso do chamado
 * @param {object} chamado - Objeto do chamado
 * @returns {string} HTML do resumo
 */
function renderResumoProgresso(chamado) {
    const totalEtapas = chamado.etapas.length;
    const etapasConcluidas = chamado.etapas.filter(e => e.status === 'CONCLUIDA').length;
    const etapaAtualNumero = chamado.etapaAtual;
    const percentualConcluido = Math.round((etapasConcluidas / totalEtapas) * 100);
    
    // Calcular tempo total decorrido
    const dataAbertura = new Date(chamado.dataAbertura);
    const agora = new Date();
    const tempoDecorrido = calcularTempoDecorrido(chamado.dataAbertura);
    
    return `
        <div class="pdf-progress-container">
            <div class="pdf-stats-grid">
                <div class="pdf-stat-card">
                    <div class="pdf-stat-icon">📊</div>
                    <div class="pdf-stat-content">
                        <div class="pdf-stat-value">${etapasConcluidas}/${totalEtapas}</div>
                        <div class="pdf-stat-label">Etapas Concluídas</div>
                    </div>
                </div>
                
                <div class="pdf-stat-card">
                    <div class="pdf-stat-icon">🎯</div>
                    <div class="pdf-stat-content">
                        <div class="pdf-stat-value">${etapaAtualNumero}</div>
                        <div class="pdf-stat-label">Etapa Atual</div>
                    </div>
                </div>
                
                <div class="pdf-stat-card">
                    <div class="pdf-stat-icon">⏱️</div>
                    <div class="pdf-stat-content">
                        <div class="pdf-stat-value">${tempoDecorrido}</div>
                        <div class="pdf-stat-label">Tempo Decorrido</div>
                    </div>
                </div>
                
                <div class="pdf-stat-card">
                    <div class="pdf-stat-icon">📈</div>
                    <div class="pdf-stat-content">
                        <div class="pdf-stat-value">${percentualConcluido}%</div>
                        <div class="pdf-stat-label">Progresso</div>
                    </div>
                </div>
            </div>
            
            <!-- Barra de Progresso -->
            <div class="pdf-progress-bar-container">
                <div class="pdf-progress-bar">
                    <div class="pdf-progress-fill" style="width: ${percentualConcluido}%">
                        <span class="pdf-progress-text">${percentualConcluido}%</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Renderiza a timeline das etapas em formato PDF
 * @param {object} chamado - Objeto do chamado
 * @returns {string} HTML da timeline
 */
function renderTimelinePDF(chamado) {
    let html = '<div class="pdf-timeline">';
    
    chamado.etapas.forEach((etapa, index) => {
        const config = ETAPAS_CONFIG[etapa.numero - 1];
        
        // Determinar ícone e classe de status
        let statusIcon = '';
        let statusClass = '';
        let statusText = '';
        
        if (etapa.status === 'CONCLUIDA') {
            statusIcon = '✅';
            statusClass = 'pdf-timeline-item-completed';
            statusText = 'Concluída';
        } else if (etapa.numero === chamado.etapaAtual) {
            statusIcon = '🔄';
            statusClass = 'pdf-timeline-item-active';
            statusText = 'Em Andamento';
        } else {
            statusIcon = '⏳';
            statusClass = 'pdf-timeline-item-pending';
            statusText = 'Aguardando';
        }
        
        // Informações de responsável
        const responsavel = etapa.responsavel 
            ? Storage.getUsuarios().find(u => u.usuario === etapa.responsavel)?.nomeCompleto || etapa.responsavel
            : config?.responsavel || 'Aguardando definição';
        
        // Informações de data
        let dataInfo = '';
        if (etapa.dataInicio) {
            const dataInicio = new Date(etapa.dataInicio).toLocaleString('pt-BR');
            dataInfo = `<div class="pdf-timeline-date">📅 Início: ${dataInicio}</div>`;
        }
        if (etapa.dataConclusao) {
            const dataConclusao = new Date(etapa.dataConclusao).toLocaleString('pt-BR');
            dataInfo += `<div class="pdf-timeline-date">✅ Conclusão: ${dataConclusao}</div>`;
        }
        
        // Informações de SLA
        let slaInfo = '';
        if (etapa.sla && etapa.prazo && etapa.status !== 'CONCLUIDA') {
            const statusSLA = calcularStatusSLA(etapa.prazo);
            const prazo = new Date(etapa.prazo);
            const agora = new Date();
            const diff = prazo - agora;
            const totalMinutos = Math.floor(diff / 60000);
            const horas = Math.floor(Math.abs(totalMinutos) / 60);
            const minutos = Math.abs(totalMinutos) % 60;
            
            let tempoTexto = '';
            if (diff < 0) {
                tempoTexto = `Atrasado ${horas}h ${minutos}min`;
            } else if (totalMinutos < 60) {
                tempoTexto = `${minutos} min restantes`;
            } else {
                tempoTexto = `${horas}h ${minutos}min restantes`;
            }
            
            slaInfo = `
                <div class="pdf-timeline-sla pdf-sla-${statusSLA.classe}">
                    ${statusSLA.icone} ${tempoTexto}
                </div>
            `;
        }
        
        // Informações de tempo de conclusão
        let tempoExecucao = '';
        if (etapa.status === 'CONCLUIDA' && etapa.dataInicio && etapa.dataConclusao) {
            const tempo = calcularTempoDecorrido(etapa.dataInicio, etapa.dataConclusao);
            tempoExecucao = `<div class="pdf-timeline-duration">⏱️ Tempo de execução: ${tempo}</div>`;
        }
        
        html += `
            <div class="pdf-timeline-item ${statusClass}">
                <div class="pdf-timeline-marker">
                    <div class="pdf-timeline-number">${etapa.numero}</div>
                    <div class="pdf-timeline-icon">${statusIcon}</div>
                </div>
                ${index < chamado.etapas.length - 1 ? '<div class="pdf-timeline-line"></div>' : ''}
                <div class="pdf-timeline-content">
                    <div class="pdf-timeline-header">
                        <h4 class="pdf-timeline-title">${etapa.numero}. ${etapa.nome}</h4>
                        <span class="pdf-timeline-status pdf-status-${statusClass}">${statusText}</span>
                    </div>
                    <div class="pdf-timeline-meta">
                        <div class="pdf-timeline-responsible">👤 ${responsavel}</div>
                        ${slaInfo}
                    </div>
                    ${dataInfo}
                    ${tempoExecucao}
                    ${renderDadosEtapaPDF(etapa, chamado)}
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    return html;
}

/**
 * Renderiza os dados específicos de cada etapa
 * @param {object} etapa - Objeto da etapa
 * @param {object} chamado - Objeto do chamado
 * @returns {string} HTML dos dados
 */
function renderDadosEtapaPDF(etapa, chamado) {
    if (!etapa.dados || Object.keys(etapa.dados).length === 0) {
        return '';
    }
    
    let html = '<div class="pdf-etapa-dados">';
    
    // Etapa 1: Descrição
    if (etapa.numero === 1 && etapa.dados.descricao) {
        html += `
            <div class="pdf-data-item">
                <strong>📝 Descrição do Problema:</strong>
                <p>${etapa.dados.descricao}</p>
            </div>
        `;
    }
    
    // Etapa 2: Agendamento
    if (etapa.numero === 2 && etapa.status === 'CONCLUIDA') {
        if (etapa.dados.dataAgendamento) {
            const dataAgendamento = new Date(etapa.dados.dataAgendamento).toLocaleString('pt-BR');
            html += `
                <div class="pdf-data-item">
                    <strong>📅 Data Agendada:</strong> ${dataAgendamento}
                </div>
            `;
        }
        if (etapa.dados.responsavelVisita) {
            html += `
                <div class="pdf-data-item">
                    <strong>👤 Responsável pela Visita:</strong> ${etapa.dados.responsavelVisita}
                </div>
            `;
        }
    }
    
    // Etapa 3: Descrição do Serviço
    if (etapa.numero === 3 && etapa.status === 'CONCLUIDA') {
        if (etapa.dados.tipoServico) {
            html += `<div class="pdf-data-item"><strong>🔧 Tipo de Serviço:</strong> ${etapa.dados.tipoServico}</div>`;
        }
        if (etapa.dados.servicosRealizados) {
            html += `<div class="pdf-data-item"><strong>✅ Serviços:</strong> ${etapa.dados.servicosRealizados}</div>`;
        }
        if (etapa.dados.produtosNecessarios) {
            html += `<div class="pdf-data-item"><strong>🛒 Produtos:</strong> ${etapa.dados.produtosNecessarios}</div>`;
        }
    }
    
    // Etapa 4: Verificação de Estoque
    if (etapa.numero === 4 && etapa.status === 'CONCLUIDA') {
        const temEstoque = etapa.dados.temEstoque === 'sim' ? '✅ Sim' : '❌ Não';
        html += `<div class="pdf-data-item"><strong>📦 Tem Estoque:</strong> ${temEstoque}</div>`;
    }
    
    // Etapa 8: Avaliação
    if (etapa.numero === 8 && etapa.status === 'CONCLUIDA') {
        const avaliacao = etapa.dados.avaliacao || 0;
        const estrelas = '⭐'.repeat(avaliacao);
        const avaliacaoTexto = {
            1: 'Péssimo',
            2: 'Ruim',
            3: 'Regular',
            4: 'Bom',
            5: 'Perfeito'
        }[avaliacao] || 'Não avaliado';
        
        html += `
            <div class="pdf-data-item">
                <strong>⭐ Avaliação:</strong> ${estrelas} ${avaliacaoTexto}
            </div>
        `;
        
        if (etapa.dados.comentariosAvaliacao) {
            html += `
                <div class="pdf-data-item">
                    <strong>💬 Comentário:</strong>
                    <p>${etapa.dados.comentariosAvaliacao}</p>
                </div>
            `;
        }
    }
    
    html += '</div>';
    return html;
}

/**
 * Calcula o prazo total estimado do chamado
 * @param {object} chamado - Objeto do chamado
 * @returns {string} Texto do prazo
 */
function calcularPrazoTotalEstimado(chamado) {
    let totalMinutos = 0;
    
    chamado.etapas.forEach(etapa => {
        if (etapa.sla) {
            totalMinutos += etapa.sla;
        }
    });
    
    const horas = Math.floor(totalMinutos / 60);
    const dias = Math.floor(horas / 24);
    
    if (dias > 0) {
        const horasRestantes = horas % 24;
        return dias === 1 
            ? `1 dia${horasRestantes > 0 ? ` e ${horasRestantes}h` : ''}` 
            : `${dias} dias${horasRestantes > 0 ? ` e ${horasRestantes}h` : ''}`;
    }
    
    if (horas > 0) {
        const minutosRestantes = totalMinutos % 60;
        return horas === 1 
            ? `1 hora${minutosRestantes > 0 ? ` e ${minutosRestantes}min` : ''}` 
            : `${horas} horas${minutosRestantes > 0 ? ` e ${minutosRestantes}min` : ''}`;
    }
    
    return `${totalMinutos} minutos`;
}

console.log('✅ Sumário de Etapas (Formato PDF) carregado!');