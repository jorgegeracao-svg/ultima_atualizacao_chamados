// ==================== GESTÃO DE USUÁRIOS ====================

function generateUserId() {
    const usuarios = Storage.getUsuarios();
    return usuarios.length > 0 ? Math.max(...usuarios.map(u => u.id)) + 1 : 1;
}

function loadUsuarios() {
    const usuarios = Storage.getUsuarios();
    renderUsuariosTable(usuarios);
}

function renderUsuariosTable(usuarios) {
    const tbody = document.getElementById('usuariosTableBody');
    
    if (usuarios.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 48px; color: #94a3b8;">
                    👥 Nenhum usuário cadastrado.
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = usuarios.map(u => {
        const statusClass = u.status === 'Ativo' ? 'status-ativo' : 'status-desligado';
        const perfilNome = {
            'SOLICITANTE': 'Solicitante',
            'TECNICO': 'Técnico',
            'ADMINISTRATIVO': 'Administrativo',
            'COMPRADOR': 'Comprador',
            'GESTOR': 'Gestor',
            'PROGRAMADOR': 'Programador'
        }[u.perfil] || u.perfil;
        
        return `
            <tr>
                <td><strong>${u.nomeCompleto}</strong></td>
                <td>${u.re}</td>
                <td>${u.cargo}</td>
                <td>${u.localTrabalho}</td>
                <td>${perfilNome}</td>
                <td><span class="status-badge ${statusClass}">${u.status}</span></td>
                <td>
                    <button class="btn-icon btn-edit" onclick="editarUsuario(${u.id})" title="Editar">✏️</button>
                    <button class="btn-icon btn-delete" onclick="confirmarExclusao(${u.id})" title="Excluir">🗑️</button>
                </td>
            </tr>
        `;
    }).join('');
}

function filtrarUsuarios() {
    const busca = document.getElementById('searchUsuarios').value.toLowerCase();
    const statusFiltro = document.getElementById('filterStatus').value;
    
    let usuarios = Storage.getUsuarios();
    
    if (busca) {
        usuarios = usuarios.filter(u => 
            u.nomeCompleto.toLowerCase().includes(busca) ||
            u.re.toLowerCase().includes(busca) ||
            u.cargo.toLowerCase().includes(busca) ||
            u.usuario.toLowerCase().includes(busca)
        );
    }
    
    if (statusFiltro) {
        usuarios = usuarios.filter(u => u.status === statusFiltro);
    }
    
    renderUsuariosTable(usuarios);
}

function abrirModalUsuario() {
    document.getElementById('modalUsuarioTitulo').textContent = 'Cadastrar Novo Usuário';
    document.getElementById('formUsuario').reset();
    document.getElementById('usuarioId').value = '';
    
    document.getElementById('campoUsuario').classList.remove('hidden');
    document.getElementById('campoSenha').classList.remove('hidden');
    document.getElementById('campoAlterarSenha').classList.add('hidden');
    
    document.getElementById('usuario').required = true;
    document.getElementById('senha').required = true;
    
    // Reset preview de foto
    const previewFoto = document.getElementById('previewFotoUsuario');
    if (previewFoto) {
        previewFoto.innerHTML = `
            <div class="foto-preview-placeholder">
                <span style="font-size: 3rem;">👤</span>
                <p>Nenhuma foto selecionada</p>
            </div>
        `;
    }
    
    document.getElementById('modalUsuario').classList.add('active');
}

function fecharModalUsuario() {
    document.getElementById('modalUsuario').classList.remove('active');
    document.getElementById('formUsuario').reset();
}

function toggleSenhaField() {
    const checkbox = document.getElementById('alterarSenha');
    const campoSenha = document.getElementById('campoSenha');
    const inputSenha = document.getElementById('senha');
    
    if (checkbox.checked) {
        campoSenha.classList.remove('hidden');
        inputSenha.required = true;
    } else {
        campoSenha.classList.add('hidden');
        inputSenha.required = false;
        inputSenha.value = '';
    }
}

document.getElementById('formUsuario').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const id = document.getElementById('usuarioId').value;
    const usuarios = Storage.getUsuarios();
    
    const usuario = {
        nomeCompleto: document.getElementById('nomeCompleto').value,
        re: document.getElementById('re').value,
        cargo: document.getElementById('cargo').value,
        localTrabalho: document.getElementById('localTrabalho').value,
        gestor: document.getElementById('gestor').value,
        gerente: document.getElementById('gerente').value,
        perfil: document.getElementById('perfil').value,
        status: document.querySelector('input[name="status"]:checked').value
    };
    
    // Processar foto se houver
    const fotoInput = document.getElementById('fotoUsuario');
    if (fotoInput && fotoInput.files[0]) {
        try {
            const fotoData = await processarImagemUpload(fotoInput.files[0], 2 * 1024 * 1024);
            usuario.foto = fotoData.data;
        } catch (error) {
            showAlert(error.message, 'error');
            return;
        }
    }
    
    if (id) {
        const index = usuarios.findIndex(u => u.id === parseInt(id));
        if (index !== -1) {
            usuarios[index] = { ...usuarios[index], ...usuario };
            
            if (document.getElementById('alterarSenha').checked) {
                usuarios[index].senha = document.getElementById('senha').value;
            }
            
            // Se não houver nova foto, manter a foto antiga
            if (!usuario.foto && usuarios[index].foto) {
                usuarios[index].foto = usuarios[index].foto;
            }
            
            showAlert('Usuário atualizado com sucesso!', 'success');
        }
    } else {
        const novoUsuario = {
            id: generateUserId(),
            ...usuario,
            usuario: document.getElementById('usuario').value,
            senha: document.getElementById('senha').value,
            foto: usuario.foto || null,
            dataCadastro: new Date().toISOString()
        };
        
        if (usuarios.find(u => u.usuario === novoUsuario.usuario)) {
            showAlert('Nome de usuário já existe!', 'error');
            return;
        }
        
        usuarios.push(novoUsuario);
        showAlert('Usuário cadastrado com sucesso!', 'success');
    }
    
    Storage.saveUsuarios(usuarios);
    fecharModalUsuario();
    loadUsuarios();
});

function editarUsuario(id) {
    const usuarios = Storage.getUsuarios();
    const usuario = usuarios.find(u => u.id === id);
    
    if (!usuario) return;
    
    document.getElementById('modalUsuarioTitulo').textContent = 'Editar Usuário';
    document.getElementById('usuarioId').value = usuario.id;
    document.getElementById('nomeCompleto').value = usuario.nomeCompleto;
    document.getElementById('re').value = usuario.re;
    document.getElementById('cargo').value = usuario.cargo;
    document.getElementById('localTrabalho').value = usuario.localTrabalho;
    document.getElementById('gestor').value = usuario.gestor || '';
    document.getElementById('gerente').value = usuario.gerente || '';
    document.getElementById('perfil').value = usuario.perfil;
    
    const radioStatus = document.querySelector(`input[name="status"][value="${usuario.status}"]`);
    if (radioStatus) radioStatus.checked = true;
    
    document.getElementById('campoUsuario').classList.add('hidden');
    document.getElementById('campoSenha').classList.add('hidden');
    document.getElementById('campoAlterarSenha').classList.remove('hidden');
    
    document.getElementById('usuario').required = false;
    document.getElementById('senha').required = false;
    document.getElementById('alterarSenha').checked = false;
    
    // Mostrar foto existente
    const previewFoto = document.getElementById('previewFotoUsuario');
    if (previewFoto && usuario.foto) {
        previewFoto.innerHTML = `
            <div class="foto-preview-container">
                <img src="${usuario.foto}" alt="Foto atual" class="foto-preview-img">
                <p class="foto-preview-nome">Foto atual</p>
            </div>
        `;
    } else if (previewFoto) {
        previewFoto.innerHTML = `
            <div class="foto-preview-placeholder">
                <span style="font-size: 3rem;">👤</span>
                <p>Nenhuma foto cadastrada</p>
            </div>
        `;
    }
    
    document.getElementById('modalUsuario').classList.add('active');
}

function confirmarExclusao(id) {
    const usuarios = Storage.getUsuarios();
    const usuario = usuarios.find(u => u.id === id);
    
    if (!usuario) return;
    
    if (confirm(`Tem certeza que deseja excluir o usuário "${usuario.nomeCompleto}"?`)) {
        excluirUsuario(id);
    }
}

function excluirUsuario(id) {
    let usuarios = Storage.getUsuarios();
    
    const currentUser = getCurrentUser();
    const usuario = usuarios.find(u => u.id === id);
    
    if (usuario.usuario === currentUser.usuario) {
        showAlert('Você não pode excluir seu próprio usuário!', 'error');
        return;
    }
    
    usuarios = usuarios.filter(u => u.id !== id);
    Storage.saveUsuarios(usuarios);
    showAlert('Usuário excluído com sucesso!', 'success');
    loadUsuarios();
}

// Setup do preview de foto ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    setupFotoUsuarioInput('fotoUsuario', 'previewFotoUsuario');
});