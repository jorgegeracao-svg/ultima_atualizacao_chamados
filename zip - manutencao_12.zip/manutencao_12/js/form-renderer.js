// ==================== RENDERIZADOR DE FORMULÁRIOS ====================

/**
 * Renderiza o formulário de uma etapa baseado na configuração
 * @param {object} chamado - Objeto do chamado
 * @param {object} etapa - Objeto da etapa
 * @param {object} currentUser - Usuário atual
 * @returns {string} HTML do formulário
 */
function renderFormularioEtapa(chamado, etapa, currentUser) {
    const config = ETAPAS_CONFIG[etapa.numero - 1];
    
    if (!config) return '<p>Configuração de etapa não encontrada.</p>';
    
    // Etapa 1: Abertura do Chamado
    if (etapa.numero === 1) {
        return renderFormularioEtapa1(chamado, etapa);
    }
    
    // Etapa 2: Agendamento da Avaliação Física
    if (etapa.numero === 2) {
        return renderFormularioEtapa2(chamado, etapa);
    }
    
    // Etapa 3: Descrição do Serviço
    if (etapa.numero === 3) {
        return renderFormularioEtapa3(chamado, etapa);
    }
    
    // Etapa 4: Verificação de Estoque
    if (etapa.numero === 4) {
        return renderFormularioEtapa4(chamado, etapa);
    }
    
    // Etapa 5: Processo de Compras (com subetapas)
    if (etapa.numero === 5) {
        return renderFormularioEtapa5(chamado, etapa);
    }
    
    // Etapa 6: Programar Data de Manutenção
    if (etapa.numero === 6) {
        return renderFormularioEtapa6(chamado, etapa);
    }
    
    // Etapa 7: Realizar Manutenção
    if (etapa.numero === 7) {
        return renderFormularioEtapa7(chamado, etapa);
    }
    
    // Etapa 8: Finalizar Chamado
    if (etapa.numero === 8) {
        return renderFormularioEtapa8(chamado, etapa);
    }
    
    return '<p>Formulário não implementado para esta etapa.</p>';
}

// ==================== FORMULÁRIOS ESPECÍFICOS POR ETAPA ====================

function renderFormularioEtapa1(chamado, etapa) {
    const tipos = chamado.tipoManutencao.join(', ');
    
    return `
        <div class="form-readonly">
            <div class="form-group-readonly">
                <label>📋 Título</label>
                <div class="form-value">${etapa.dados.titulo || chamado.titulo}</div>
            </div>
            
            <div class="form-group-readonly">
                <label>📞 Telefone</label>
                <div class="form-value">${etapa.dados.telefone || chamado.telefone}</div>
            </div>
            
            <div class="form-group-readonly">
                <label>🏢 Unidade</label>
                <div class="form-value">${etapa.dados.unidade || chamado.unidade}</div>
            </div>
            
            <div class="form-group-readonly">
                <label>🔧 Tipo de Manutenção</label>
                <div class="form-value">${tipos}</div>
            </div>
            
            <div class="form-group-readonly">
                <label>📍 Local</label>
                <div class="form-value">${etapa.dados.local || chamado.local}</div>
            </div>
            
            <div class="form-group-readonly">
                <label>📝 Descrição</label>
                <div class="form-value">${etapa.dados.descricao || chamado.descricao}</div>
            </div>
        </div>
    `;
}

function renderFormularioEtapa2(chamado, etapa) {
    if (etapa.status === 'CONCLUIDA') {
        const dataAgendamento = etapa.dados.dataAgendamento 
            ? new Date(etapa.dados.dataAgendamento).toLocaleString('pt-BR')
            : 'Não informada';
        
        return `
            <div class="form-readonly">
                <div class="form-group-readonly">
                    <label>📅 Data do Agendamento</label>
                    <div class="form-value">${dataAgendamento}</div>
                </div>
                
                <div class="form-group-readonly">
                    <label>👤 Responsável pela Visita</label>
                    <div class="form-value">${etapa.dados.responsavelVisita || 'Não informado'}</div>
                </div>
            </div>
        `;
    }
    
    return '<p class="etapa-aguardando">⏳ Aguardando preenchimento do agendamento...</p>';
}

function renderFormularioEtapa3(chamado, etapa) {
    if (etapa.status === 'CONCLUIDA') {
        return `
            <div class="form-readonly">
                <div class="form-group-readonly">
                    <label>🔧 Tipo de Serviço</label>
                    <div class="form-value">${etapa.dados.tipoServico || 'Não informado'}</div>
                </div>
                
                <div class="form-group-readonly">
                    <label>📝 Serviços Realizados</label>
                    <div class="form-value">${etapa.dados.servicosRealizados || 'Não informado'}</div>
                </div>
                
                <div class="form-group-readonly">
                    <label>🛒 Produtos Necessários</label>
                    <div class="form-value">${etapa.dados.produtosNecessarios || 'Não informado'}</div>
                </div>
            </div>
        `;
    }
    
    return '<p class="etapa-aguardando">⏳ Aguardando descrição do serviço...</p>';
}

function renderFormularioEtapa4(chamado, etapa) {
    if (etapa.status === 'CONCLUIDA') {
        const temEstoque = etapa.dados.temEstoque === 'sim' ? 'Sim ✅' : 'Não ❌';
        
        return `
            <div class="form-readonly">
                <div class="form-group-readonly">
                    <label>📦 Tem Estoque?</label>
                    <div class="form-value">${temEstoque}</div>
                </div>
            </div>
        `;
    }
    
    return '<p class="etapa-aguardando">⏳ Aguardando verificação de estoque...</p>';
}

function renderFormularioEtapa5(chamado, etapa) {
    if (etapa.status === 'CONCLUIDA') {
        let html = '<div class="form-readonly">';
        
        // Subetapas de compras
        if (etapa.dados.subetapas) {
            etapa.dados.subetapas.forEach((sub, index) => {
                html += `
                    <div class="subetapa-info">
                        <h4>Subetapa ${sub.numero}: ${sub.nome}</h4>
                        ${sub.observacoes ? `<p>${sub.observacoes}</p>` : ''}
                        ${sub.dataEnvio ? `<p>📅 ${new Date(sub.dataEnvio).toLocaleString('pt-BR')}</p>` : ''}
                    </div>
                `;
            });
        }
        
        html += '</div>';
        return html;
    }
    
    return '<p class="etapa-aguardando">⏳ Aguardando processo de compras...</p>';
}

function renderFormularioEtapa6(chamado, etapa) {
    if (etapa.status === 'CONCLUIDA') {
        const dataManutencao = etapa.dados.dataManutencao 
            ? new Date(etapa.dados.dataManutencao).toLocaleString('pt-BR')
            : 'Não informada';
        
        return `
            <div class="form-readonly">
                <div class="form-group-readonly">
                    <label>📅 Data da Manutenção Programada</label>
                    <div class="form-value">${dataManutencao}</div>
                </div>
            </div>
        `;
    }
    
    return '<p class="etapa-aguardando">⏳ Aguardando programação da data...</p>';
}

function renderFormularioEtapa7(chamado, etapa) {
    if (etapa.status === 'CONCLUIDA') {
        const dataRealizacao = etapa.dataConclusao 
            ? new Date(etapa.dataConclusao).toLocaleDateString('pt-BR')
            : 'Não informada';
        
        let fotosHTML = '';
        if (etapa.dados.fotosServico && etapa.dados.fotosServico.length > 0) {
            fotosHTML = `
                <div class="form-group-readonly">
                    <label>📸 Fotos do Serviço</label>
                    <div class="fotos-grid">
                        ${etapa.dados.fotosServico.map(foto => `
                            <img src="${foto.data}" alt="${foto.nome}" 
                                 style="max-width: 200px; border-radius: 8px; cursor: pointer;"
                                 onclick="window.open('${foto.data}', '_blank')">
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        return `
            <div class="form-readonly">
                <div class="form-group-readonly">
                    <label>📅 Data da Realização</label>
                    <div class="form-value">${dataRealizacao}</div>
                </div>
                ${fotosHTML}
            </div>
        `;
    }
    
    return '<p class="etapa-aguardando">⏳ Aguardando realização da manutenção...</p>';
}

function renderFormularioEtapa8(chamado, etapa) {
    if (etapa.status === 'CONCLUIDA') {
        const avaliacao = etapa.dados.avaliacao || 0;
        const estrelas = '⭐'.repeat(avaliacao);
        
        const avaliacaoTexto = {
            1: 'Péssimo',
            2: 'Ruim',
            3: 'Regular',
            4: 'Bom',
            5: 'Perfeito'
        }[avaliacao] || 'Não avaliado';
        
        return `
            <div class="form-readonly">
                <div class="form-group-readonly">
                    <label>⭐ Avaliação do Atendimento</label>
                    <div class="form-value">${estrelas} ${avaliacaoTexto}</div>
                </div>
                
                <div class="form-group-readonly">
                    <label>💬 Comentário</label>
                    <div class="form-value">${etapa.dados.comentariosAvaliacao || 'Sem comentários'}</div>
                </div>
            </div>
        `;
    }
    
    return '<p class="etapa-aguardando">⏳ Aguardando finalização do chamado...</p>';
}