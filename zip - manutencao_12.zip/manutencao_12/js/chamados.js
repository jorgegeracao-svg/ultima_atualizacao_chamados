// ==================== GESTÃO DE CHAMADOS ====================

function generateId() {
    const chamados = Storage.getChamados();
    const anoAtual = new Date().getFullYear();
    
    // Filtrar chamados do ano atual
    const chamadosAnoAtual = chamados.filter(c => {
        const idStr = c.id.toString();
        if (idStr.length >= 10) {
            const anoChamado = parseInt(idStr.substring(0, 4));
            return anoChamado === anoAtual;
        }
        return false;
    });
    
    // Encontrar o último número sequencial do ano
    let ultimoNumero = 0;
    if (chamadosAnoAtual.length > 0) {
        const numerosSequenciais = chamadosAnoAtual.map(c => {
            const idStr = c.id.toString();
            return parseInt(idStr.substring(4)); // Pega tudo após o ano
        });
        ultimoNumero = Math.max(...numerosSequenciais);
    }
    
    // Incrementar e formatar: ano + 6 dígitos zerados à esquerda
    const proximoNumero = ultimoNumero + 1;
    const numeroFormatado = proximoNumero.toString().padStart(6, '0');
    const novoId = parseInt(`${anoAtual}${numeroFormatado}`);
    
    return novoId;
}

// Flag para prevenir múltiplas submissões
let isSubmitting = false;

// Preview de anexo
document.getElementById('anexo').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const previewDiv = document.getElementById('previewAnexo');
    
    if (file) {
        if (file.size > 5 * 1024 * 1024) { // 5MB
            showAlert('Arquivo muito grande! Tamanho máximo: 5MB', 'error');
            this.value = '';
            previewDiv.innerHTML = '';
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(event) {
            previewDiv.innerHTML = `
                <div style="border: 2px solid #e2e8f0; border-radius: 8px; padding: 12px; display: inline-block;">
                    <img src="${event.target.result}" alt="Preview" style="max-width: 200px; max-height: 200px; border-radius: 6px;">
                    <div style="text-align: center; margin-top: 8px; font-size: 0.85rem; color: #64748b;">
                        ${file.name}
                    </div>
                </div>
            `;
        };
        reader.readAsDataURL(file);
    } else {
        previewDiv.innerHTML = '';
    }
});

// Criar novo chamado - COM PREVENÇÃO DE DUPLICIDADE
document.getElementById('novoChamadoForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Prevenir múltiplas submissões
    if (isSubmitting) {
        console.log('Já está processando um chamado...');
        return;
    }
    
    isSubmitting = true;
    
    // Desabilitar botão de submit
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Criando chamado...';
    
    try {
        const currentUser = getCurrentUser();
        
        // Coletar tipos de manutenção selecionados
        const tiposManutencao = Array.from(document.querySelectorAll('input[name="tipoManutencao"]:checked'))
            .map(cb => cb.value);
        
        if (tiposManutencao.length === 0) {
            showAlert('Selecione pelo menos um tipo de manutenção!', 'error');
            return;
        }
        
        // Processar anexo (se existir)
        const anexoFile = document.getElementById('anexo').files[0];
        let anexoData = null;
        
        if (anexoFile) {
            const reader = new FileReader();
            reader.onload = function(event) {
                anexoData = {
                    nome: anexoFile.name,
                    tipo: anexoFile.type,
                    tamanho: anexoFile.size,
                    data: event.target.result // Base64
                };
                
                // Criar chamado após processar anexo
                criarChamadoComAnexo(anexoData);
            };
            reader.readAsDataURL(anexoFile);
        } else {
            // Criar chamado sem anexo
            criarChamadoComAnexo(null);
        }
        
        function criarChamadoComAnexo(anexo) {
            const chamado = {
                id: generateId(),
                titulo: document.getElementById('titulo').value,
                telefone: document.getElementById('telefone').value,
                unidade: document.getElementById('unidade').value,
                local: document.getElementById('local').value,
                tipoManutencao: tiposManutencao,
                descricao: document.getElementById('descricao').value,
                anexos: anexo ? [anexo] : [],
                
                solicitante: currentUser.usuario,
                solicitanteNome: currentUser.nomeCompleto,
                status: "EM_ANDAMENTO",
                etapaAtual: 2,
                
                dataAbertura: new Date().toISOString(),
                dataConclusao: null,
                
                etapas: [
                    {
                        numero: 1,
                        nome: "Abertura do Chamado",
                        responsavel: currentUser.usuario,
                        dataInicio: new Date().toISOString(),
                        dataConclusao: new Date().toISOString(),
                        status: "CONCLUIDA",
                        dados: {
                            titulo: document.getElementById('titulo').value,
                            telefone: document.getElementById('telefone').value,
                            unidade: document.getElementById('unidade').value,
                            local: document.getElementById('local').value,
                            tipoManutencao: tiposManutencao,
                            descricao: document.getElementById('descricao').value
                        }
                    },
                    {
                        numero: 2,
                        nome: "Agendamento da Avaliação Física",
                        responsavel: null,
                        dataInicio: new Date().toISOString(),
                        dataConclusao: null,
                        sla: 20,
                        prazo: new Date(Date.now() + 20 * 60000).toISOString(),
                        status: "AGUARDANDO",
                        dados: {}
                    }
                ],
                
                historico: [
                    {
                        data: new Date().toISOString(),
                        usuario: currentUser.usuario,
                        usuarioNome: currentUser.nomeCompleto,
                        acao: "Abriu o chamado",
                        etapa: 1
                    }
                ]
            };
            
            const chamados = Storage.getChamados();
            chamados.push(chamado);
            Storage.saveChamados(chamados);
            
            showAlert('Chamado #' + chamado.id + ' criado com sucesso!', 'success');
            
            // Resetar formulário e estado
            document.getElementById('novoChamadoForm').reset();
            document.getElementById('previewAnexo').innerHTML = '';
            
            setTimeout(() => {
                showScreen('entrada');
                loadChamados();
            }, 1000);
        }
    } finally {
        // Sempre reabilitar o botão após processamento
        setTimeout(() => {
            isSubmitting = false;
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
        }, 1500);
    }
});

// Carregar chamados - USANDO SISTEMA DE ROTEAMENTO DINÂMICO
function loadChamados() {
    const chamados = Storage.getChamados();
    const currentUser = getCurrentUser();
    
    if (!currentUser) return;
    
    // 🔥 NOVA LÓGICA: Usar sistema de roteamento dinâmico
    const entrada = filtrarChamadosPorCaixa(chamados, currentUser, 'entrada');
    const log = filtrarChamadosPorCaixa(chamados, currentUser, 'log');
    const saida = filtrarChamadosPorCaixa(chamados, currentUser, 'saida');
    
    // Atualizar badges do menu
    const contadores = contarChamadosPorCaixa(chamados, currentUser);
    atualizarBadgesMenu(contadores);
    
    // Atualizar descrições das caixas baseado no perfil
    const entradaDesc = document.getElementById('entradaDescricao');
    const logDesc = document.getElementById('logDescricao');
    
    if (currentUser.perfil === 'SOLICITANTE') {
        entradaDesc.textContent = 'Chamados aguardando sua ação';
        logDesc.textContent = 'Chamados aguardando ação de outros setores';
        
    } else if (currentUser.perfil === 'TECNICO') {
        entradaDesc.textContent = 'Chamados aguardando sua ação';
        logDesc.textContent = 'Chamados em processo de compras';
        
    } else if (currentUser.perfil === 'ADMINISTRATIVO') {
        entradaDesc.textContent = 'Chamados aguardando agendamento ou programação';
        logDesc.textContent = 'Chamados em outras etapas';
        
    } else if (currentUser.perfil === 'COMPRADOR') {
        entradaDesc.textContent = 'Chamados aguardando processo de compras';
        logDesc.textContent = 'Compras já processadas';
        
    } else if (currentUser.perfil === 'GESTOR') {
        entradaDesc.textContent = 'Chamados aguardando aprovação';
        logDesc.textContent = 'Todos os chamados em andamento (visão geral)';
        
    } else {
        entradaDesc.textContent = 'Chamados aguardando sua ação';
        logDesc.textContent = 'Chamados em andamento';
    }
    
    popularDropdownEtapas('log', log);
    
    renderTable('entradaTableBody', entrada, false);
    renderTable('logTableBody', log, false);
    renderTable('saidaTableBody', saida, true);
}

// Popular dropdown de etapas com base nos chamados disponíveis
function popularDropdownEtapas(tela, chamados) {
    const selectId = `filter${tela.charAt(0).toUpperCase() + tela.slice(1)}Etapa`;
    const select = document.getElementById(selectId);
    
    if (!select) return;
    
    // Obter etapas únicas dos chamados
    const etapasUnicas = [...new Set(chamados.map(c => c.etapaAtual))].sort((a, b) => a - b);
    
    // Limpar e repopular
    select.innerHTML = '<option value="">Todas as etapas</option>';
    
    etapasUnicas.forEach(etapaNum => {
        const config = ETAPAS_CONFIG[etapaNum - 1];
        const nome = config ? config.nome : `Etapa ${etapaNum}`;
        select.innerHTML += `<option value="${etapaNum}">${etapaNum}. ${nome}</option>`;
    });
}

// Filtrar chamados
function filtrarChamados(tela) {
    // Obter chamados originais da memória
    const chamadosOriginais = tela === 'entrada' ? window.chamadosEntrada : 
                              tela === 'log' ? window.chamadosLog : 
                              window.chamadosSaida;
    
    if (!chamadosOriginais) {
        loadChamados();
        return;
    }
    
    let filtrados = [...chamadosOriginais];
    
    // Obter valores dos filtros
    const numero = document.getElementById(`filter${tela.charAt(0).toUpperCase() + tela.slice(1)}Numero`).value;
    const data = document.getElementById(`filter${tela.charAt(0).toUpperCase() + tela.slice(1)}Data`).value;
    const selectEtapa = document.getElementById(`filter${tela.charAt(0).toUpperCase() + tela.slice(1)}Etapa`);
    const etapa = selectEtapa ? selectEtapa.value : '';
    
    // Filtro por número
    if (numero) {
        filtrados = filtrados.filter(c => c.id.toString().includes(numero));
    }
    
    // Filtro por data de abertura
    if (data) {
        filtrados = filtrados.filter(c => {
            const dataAbertura = new Date(c.dataAbertura).toISOString().split('T')[0];
            return dataAbertura === data;
        });
    }
    
    // Filtro por etapa (apenas para entrada e log)
    if (etapa) {
        filtrados = filtrados.filter(c => c.etapaAtual === parseInt(etapa));
    }
    
    // Filtro por data de conclusão (apenas para saída)
    if (tela === 'saida') {
        const dataConclusao = document.getElementById('filterSaidaDataConclusao').value;
        if (dataConclusao) {
            filtrados = filtrados.filter(c => {
                if (!c.dataConclusao) return false;
                const dataConcl = new Date(c.dataConclusao).toISOString().split('T')[0];
                return dataConcl === dataConclusao;
            });
        }
    }
    
    // Renderizar tabela filtrada
    const tableBody = tela === 'entrada' ? 'entradaTableBody' : 
                      tela === 'log' ? 'logTableBody' : 'saidaTableBody';
    const mostrarDataConclusao = tela === 'saida';
    
    renderTable(tableBody, filtrados, mostrarDataConclusao);
}

// Limpar filtros
function limparFiltros(tela) {
    document.getElementById(`filter${tela.charAt(0).toUpperCase() + tela.slice(1)}Numero`).value = '';
    document.getElementById(`filter${tela.charAt(0).toUpperCase() + tela.slice(1)}Data`).value = '';
    
    const selectEtapa = document.getElementById(`filter${tela.charAt(0).toUpperCase() + tela.slice(1)}Etapa`);
    if (selectEtapa) {
        selectEtapa.value = '';
    }
    
    if (tela === 'saida') {
        document.getElementById('filterSaidaDataConclusao').value = '';
    }
    
    // Recarregar chamados sem filtros
    filtrarChamados(tela);
}

function renderTable(tableId, chamados, mostrarDataConclusao) {
    const container = document.getElementById(tableId);
    const currentUser = getCurrentUser();
    
    const mostrarSLA = currentUser.perfil === 'TECNICO' && tableId === 'entradaTableBody';
    
    if (chamados.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 48px; color: #94a3b8;">
                📭 Nenhum chamado encontrado.
            </div>
        `;
        return;
    }
    
    container.innerHTML = chamados.map(c => {
        const dataAbertura = new Date(c.dataAbertura);
        const dataAberturaFormatada = dataAbertura.toLocaleDateString('pt-BR');
        const horaAberturaFormatada = dataAbertura.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        
        const dataConclusao = c.dataConclusao ? new Date(c.dataConclusao) : null;
        const dataConclusaoFormatada = dataConclusao ? dataConclusao.toLocaleDateString('pt-BR') : null;
        const horaConclusaoFormatada = dataConclusao ? dataConclusao.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : null;
        
        const etapaConfig = ETAPAS_CONFIG[c.etapaAtual - 1];
        const etapaAtual = etapaConfig?.nome || `Etapa ${c.etapaAtual}`;
        
        // Determinar responsável atual
        let responsavelAtual = 'Aguardando atribuição';

        // ✅ CORREÇÃO: garantir que c.etapas seja sempre um array antes de usar .find()
        const etapas = Array.isArray(c.etapas) ? c.etapas : [];
        const etapaAtiva = etapas.find(e => e.numero === c.etapaAtual);
        
        if (etapaAtiva && etapaAtiva.responsavel) {
            const usuarios = Storage.getUsuarios();
            const resp = usuarios.find(u => u.usuario === etapaAtiva.responsavel);
            responsavelAtual = resp ? resp.nomeCompleto : etapaAtiva.responsavel;
        } else if (etapaConfig) {
            if (etapaConfig.responsavel === 'SOLICITANTE') {
                responsavelAtual = c.solicitanteNome;
            } else {
                responsavelAtual = `Aguardando ${etapaConfig.responsavel}`;
            }
        }
        
        // Calcular SLA
        let slaHTML = '';
        let cardClass = '';
        
        if (mostrarSLA && etapaAtiva && etapaAtiva.prazo) {
            const prazo = new Date(etapaAtiva.prazo);
            const agora = new Date();
            const diff = prazo - agora;
            const totalMinutos = Math.floor(diff / 60000);
            const horas = Math.floor(Math.abs(totalMinutos) / 60);
            const minutos = Math.abs(totalMinutos) % 60;
            
            let slaClass = 'sla-ok';
            let slaIcon = '✅';
            let slaText = '';
            
            if (diff < 0) {
                slaClass = 'sla-danger';
                cardClass = 'urgente';
                slaIcon = '🔴';
                slaText = `<div style="font-size: 0.7rem; opacity: 0.9;">SLA</div><div style="font-size: 0.95rem; font-weight: 800;">ATRASADO</div><div style="font-size: 0.75rem;">${horas}h ${minutos}min</div>`;
            } else if (totalMinutos < 10) {
                slaClass = 'sla-danger';
                cardClass = 'urgente';
                slaIcon = '⚠️';
                slaText = `<div style="font-size: 0.7rem; opacity: 0.9;">SLA</div><div style="font-size: 0.95rem; font-weight: 800;">${minutos} MIN</div><div style="font-size: 0.75rem;">restantes</div>`;
            } else if (totalMinutos < 60) {
                slaClass = 'sla-warning';
                cardClass = 'atencao';
                slaIcon = '⚠️';
                slaText = `<div style="font-size: 0.7rem; opacity: 0.9;">SLA</div><div style="font-size: 0.95rem; font-weight: 800;">${minutos} MIN</div><div style="font-size: 0.75rem;">restantes</div>`;
            } else if (totalMinutos < 120) {
                slaClass = 'sla-warning';
                cardClass = 'atencao';
                slaIcon = '⏰';
                slaText = `<div style="font-size: 0.7rem; opacity: 0.9;">SLA</div><div style="font-size: 0.95rem; font-weight: 800;">${horas}h ${minutos}min</div><div style="font-size: 0.75rem;">restantes</div>`;
            } else {
                slaIcon = '⏰';
                slaText = `<div style="font-size: 0.7rem; opacity: 0.9;">SLA</div><div style="font-size: 0.95rem; font-weight: 800;">${horas}h ${minutos}min</div><div style="font-size: 0.75rem;">restantes</div>`;
            }
            
            slaHTML = `
                <div class="card-top-info">
                    <div class="card-sla ${slaClass}">${slaText}</div>
                    <div class="card-numero">#${c.id}</div>
                </div>
            `;
        } else {
            slaHTML = `
                <div class="card-top-info">
                    <div class="card-numero-only">#${c.id}</div>
                </div>
            `;
        }
        
        // ✅ CORREÇÃO PRINCIPAL (linha 453): garantir que tipoManutencao seja sempre um array
        const tiposHTML = (Array.isArray(c.tipoManutencao) ? c.tipoManutencao : []).slice(0, 3).map(tipo => {
            const tipoConfig = TIPOS_PROCESSOS.MANUTENCAO.opcoes.find(t => t.valor === tipo);
            const icone = tipoConfig ? tipoConfig.icone : '🔧';
            return `<span class="tipo-badge">${icone} ${tipo}</span>`;
        }).join('');
        
        
        return `
            <div class="chamado-card ${cardClass}" onclick="showDetalhes(${c.id})">
                ${slaHTML}
                
                <div class="card-header">
                    <div class="card-titulo">
                        <h3>${c.titulo || 'Sem título'}</h3>
                        <div class="card-tipos">${tiposHTML}</div>
                    </div>
                </div>
                
                <div class="card-etapa">
                    <div class="etapa-nome">
                        🎯 Etapa ${c.etapaAtual}: ${etapaAtual}
                    </div>
                    <div class="etapa-responsavel">
                        👤 ${responsavelAtual}
                    </div>
                </div>
                
                <div class="card-info">
                    <div class="info-item">
                        <span class="info-label">📅 Abertura</span>
                        <span class="info-value">${dataAberturaFormatada}</span>
                        <span class="info-value-small">${horaAberturaFormatada}</span>
                    </div>
                    ${mostrarDataConclusao && dataConclusaoFormatada ? `
                    <div class="info-item">
                        <span class="info-label">✅ Conclusão</span>
                        <span class="info-value">${dataConclusaoFormatada}</span>
                        <span class="info-value-small">${horaConclusaoFormatada}</span>
                    </div>
                    ` : ''}
                </div>
            </div>
        `;
    }).join('');
}