// ==================== CONFIGURAÇÃO DE SLA POR TIPO DE CHAMADO ====================

/**
 * Carrega configurações de SLA do localStorage
 * Se não existir, retorna configuração padrão
 */
function getSLAConfig() {
    const config = localStorage.getItem('slaConfig');
    if (config) {
        return JSON.parse(config);
    }

    // Configuração padrão (baseada em ETAPAS_CONFIG)
    return {
        MANUTENCAO: [
            {
                numero: 1,
                nome: "Abertura do Chamado",
                responsavel: "SOLICITANTE",
                slaAtivo: false,
                slaMinutos: null,
                slaVariavel: false,
                origemSLA: null
            },
            {
                numero: 2,
                nome: "Agendamento da Avaliação Física",
                responsavel: "ADMINISTRATIVO",
                slaAtivo: true,
                slaMinutos: 20,
                slaVariavel: false,
                origemSLA: null
            },
            {
                numero: 3,
                nome: "Descrição do Serviço",
                responsavel: "TECNICO",
                slaAtivo: true,
                slaMinutos: 1440,
                slaVariavel: false,
                origemSLA: null
            },
            {
                numero: 4,
                nome: "Verificação de Estoque",
                responsavel: "TECNICO",
                slaAtivo: true,
                slaMinutos: 1440,
                slaVariavel: false,
                origemSLA: null
            },
            {
                numero: 5,
                nome: "Processo de Compras",
                responsavel: "COMPRADOR",
                slaAtivo: true,
                slaMinutos: 120,
                slaVariavel: false,
                origemSLA: null,
                subetapas: [
                    { numero: 5.1, nome: "Cotação", slaMinutos: 120, responsavel: "COMPRADOR" },
                    { numero: 5.2, nome: "Envio do Orçamento", slaMinutos: null, responsavel: "COMPRADOR" },
                    { numero: 5.3, nome: "Aprovação do Orçamento", slaMinutos: 120, responsavel: "GESTOR" },
                    { numero: 5.4, nome: "Recebimento das Mercadorias", slaMinutos: null, responsavel: "TECNICO" }
                ]
            },
            {
                numero: 6,
                nome: "Programar Data de Manutenção",
                responsavel: "ADMINISTRATIVO",
                slaAtivo: true,
                slaMinutos: 120,
                slaVariavel: false,
                origemSLA: null
            },
            {
                numero: 7,
                nome: "Realizar Manutenção",
                responsavel: "TECNICO",
                slaAtivo: true,
                slaMinutos: null,
                slaVariavel: true,
                origemSLA: 6
            },
            {
                numero: 8,
                nome: "Finalizar Chamado",
                responsavel: "SOLICITANTE",
                slaAtivo: true,
                slaMinutos: 120,
                slaVariavel: false,
                origemSLA: null
            }
        ]
    };
}

/**
 * Salva configurações de SLA no localStorage
 */
function saveSLAConfig(config) {
    localStorage.setItem('slaConfig', JSON.stringify(config));
}

/**
 * Carrega a tela de configuração de SLA
 */
function loadSLAConfigScreen() {
    const currentUser = getCurrentUser();

    // Verificar permissão
    if (!currentUser || currentUser.perfil !== 'PROGRAMADOR') {
        showAlert('Acesso negado! Apenas programadores podem configurar SLA.', 'error');
        showScreen('entrada');
        return;
    }

    // Renderizar select de processos
    renderProcessSelect();

    // Carregar configuração do primeiro tipo ativo
    const processoAtivo = getProcessoAtivo();
    if (processoAtivo) {
        const select = document.getElementById('slaConfigTipoProcesso');
        if (select) {
            select.value = processoAtivo.id;
            carregarTabelaSLA(processoAtivo.id);
        }
    }
}

/**
 * Renderiza o select de tipo de processo
 */
function renderProcessSelect() {
    const select = document.getElementById('slaConfigTipoProcesso');
    
    if (!select) {
        console.error('Select de tipo de processo não encontrado');
        return;
    }

    const processos = Object.values(TIPOS_PROCESSOS);
    
    // Limpar e adicionar opções
    select.innerHTML = '<option value="">📋 Selecione o tipo de chamado...</option>';
    
    processos.forEach(p => {
        const option = document.createElement('option');
        option.value = p.id;
        option.textContent = `${p.icone} ${p.nome}`;
        if (p.ativo) {
            option.textContent += ' (Ativo)';
        }
        select.appendChild(option);
    });
}

/**
 * Carrega tabela de configuração de SLA para um tipo de processo
 */
function carregarTabelaSLA(tipoProcesso) {
    if (!tipoProcesso) {
        const tbody = document.getElementById('slaConfigTableBody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; padding: 48px; color: #94a3b8;">
                        📋 Selecione um tipo de chamado acima para configurar as etapas
                    </td>
                </tr>
            `;
        }
        return;
    }

    const config = getSLAConfig();
    const etapas = config[tipoProcesso] || [];

    const tbody = document.getElementById('slaConfigTableBody');

    if (!tbody) {
        console.error('Elemento slaConfigTableBody não encontrado');
        return;
    }

    if (etapas.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 48px; color: #94a3b8;">
                    ⚙️ Nenhuma etapa configurada para este tipo de processo
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = etapas.map(etapa => {
        const perfilNome = obterNomePerfilResponsavel(etapa.responsavel);
        const slaAtivo = etapa.slaAtivo;

        let slaTexto = '—';
        if (etapa.slaAtivo && !etapa.slaVariavel && etapa.slaMinutos) {
            slaTexto = formatarMinutos(etapa.slaMinutos);
        } else if (etapa.slaVariavel) {
            slaTexto = 'Variável';
        }

        let tipoTexto = '—';
        if (etapa.slaVariavel && etapa.origemSLA) {
            const etapaOrigem = etapas.find(e => e.numero === etapa.origemSLA);
            tipoTexto = etapaOrigem ? `Da etapa ${etapaOrigem.numero}` : 'Variável';
        } else if (!etapa.slaVariavel && etapa.slaAtivo) {
            tipoTexto = '⏰ Fixo';
        }

        return `
            <tr>
                <td style="text-align: center;"><strong>${etapa.numero}</strong></td>
                <td><strong>${etapa.nome}</strong></td>
                <td>${perfilNome}</td>
                <td style="text-align: center;">
                    <span class="status-badge ${slaAtivo ? 'status-ativo' : 'status-desligado'}">
                        ${slaAtivo ? '✅ Ativo' : '❌ Inativo'}
                    </span>
                </td>
                <td style="text-align: center;">${slaTexto}</td>
                <td style="text-align: center;">${tipoTexto}</td>
                <td style="text-align: center;">
                    <button class="btn-icon btn-edit" 
                            onclick="abrirModalEditarSLA('${tipoProcesso}', ${etapa.numero})" 
                            title="Editar Configuração">
                        ⚙️
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

/**
 * Formata minutos em texto legível
 */
function formatarMinutos(minutos) {
    if (!minutos) return '—';
    
    const dias = Math.floor(minutos / 1440);
    const horas = Math.floor((minutos % 1440) / 60);
    const mins = minutos % 60;
    
    let texto = '';
    if (dias > 0) texto += `${dias}d `;
    if (horas > 0) texto += `${horas}h `;
    if (mins > 0) texto += `${mins}min`;
    
    return texto.trim() || `${minutos} min`;
}

/**
 * Obtém nome amigável do perfil responsável
 */
function obterNomePerfilResponsavel(perfil) {
    const nomes = {
        'SOLICITANTE': 'Solicitante',
        'TECNICO': 'Técnico da Manutenção',
        'ADMINISTRATIVO': 'Administração da Manutenção',
        'COMPRADOR': 'Comprador',
        'GESTOR': 'Gestor',
        'PROGRAMADOR': 'Programador'
    };
    return nomes[perfil] || perfil;
}

/**
 * Abre modal para editar configuração de SLA de uma etapa
 */
function abrirModalEditarSLA(tipoProcesso, numeroEtapa) {
    const config = getSLAConfig();
    const etapas = config[tipoProcesso] || [];
    const etapa = etapas.find(e => e.numero === numeroEtapa);

    if (!etapa) {
        showAlert('Etapa não encontrada!', 'error', 'alertSLAConfigContainer');
        return;
    }

    // Preencher dados no modal
    document.getElementById('slaEditTipoProcesso').value = tipoProcesso;
    document.getElementById('slaEditNumeroEtapa').value = numeroEtapa;
    document.getElementById('slaEditNomeEtapa').textContent = `${etapa.numero}. ${etapa.nome}`;

    // Responsável
    document.getElementById('slaEditResponsavel').value = etapa.responsavel;

    // SLA Ativo
    document.querySelector(`input[name="slaEditAtivo"][value="${etapa.slaAtivo}"]`).checked = true;

    // Tipo de SLA
    const tipoSLA = etapa.slaVariavel ? 'variavel' : 'fixo';
    document.querySelector(`input[name="slaEditTipo"][value="${tipoSLA}"]`).checked = true;

    // SLA Minutos
    document.getElementById('slaEditMinutos').value = etapa.slaMinutos || '';

    // Origem SLA (para variável)
    const selectOrigem = document.getElementById('slaEditOrigemSLA');
    selectOrigem.innerHTML = '<option value="">Selecione a etapa...</option>';

    etapas.forEach(e => {
        if (e.numero !== numeroEtapa) {
            selectOrigem.innerHTML += `<option value="${e.numero}">${e.numero}. ${e.nome}</option>`;
        }
    });

    if (etapa.origemSLA) {
        selectOrigem.value = etapa.origemSLA;
    }

    // Mostrar/ocultar campos baseado no tipo
    toggleCamposSLATipo();
    toggleCamposSLAAtivo();

    document.getElementById('modalEditarSLA').classList.add('active');
}

/**
 * Fecha modal de edição de SLA
 */
function fecharModalEditarSLA() {
    document.getElementById('modalEditarSLA').classList.remove('active');
    document.getElementById('formEditarSLA').reset();
}

/**
 * Alterna visibilidade dos campos baseado no tipo de SLA
 */
function toggleCamposSLATipo() {
    const tipoRadio = document.querySelector('input[name="slaEditTipo"]:checked');
    if (!tipoRadio) return;

    const tipoSelecionado = tipoRadio.value;

    const campoMinutos = document.getElementById('campoSLAMinutos');
    const campoOrigem = document.getElementById('campoSLAOrigem');

    if (tipoSelecionado === 'fixo') {
        campoMinutos.classList.remove('hidden');
        campoOrigem.classList.add('hidden');
        document.getElementById('slaEditMinutos').required = true;
        document.getElementById('slaEditOrigemSLA').required = false;
    } else {
        campoMinutos.classList.add('hidden');
        campoOrigem.classList.remove('hidden');
        document.getElementById('slaEditMinutos').required = false;
        document.getElementById('slaEditOrigemSLA').required = true;
    }
}

/**
 * Alterna visibilidade dos campos baseado se SLA está ativo
 */
function toggleCamposSLAAtivo() {
    const ativoRadio = document.querySelector('input[name="slaEditAtivo"]:checked');
    if (!ativoRadio) return;

    const slaAtivo = ativoRadio.value === 'true';

    const campoTipo = document.getElementById('campoSLATipo');
    const campoMinutos = document.getElementById('campoSLAMinutos');
    const campoOrigem = document.getElementById('campoSLAOrigem');

    if (slaAtivo) {
        campoTipo.classList.remove('hidden');
        toggleCamposSLATipo(); // Mostrar campos corretos baseado no tipo
    } else {
        campoTipo.classList.add('hidden');
        campoMinutos.classList.add('hidden');
        campoOrigem.classList.add('hidden');
    }
}

/**
 * Salva alterações de configuração de SLA
 */
function salvarConfiguracaoSLA(e) {
    e.preventDefault();

    const tipoProcesso = document.getElementById('slaEditTipoProcesso').value;
    const numeroEtapa = parseInt(document.getElementById('slaEditNumeroEtapa').value);

    const config = getSLAConfig();
    const etapas = config[tipoProcesso] || [];
    const etapa = etapas.find(e => e.numero === numeroEtapa);

    if (!etapa) {
        showAlert('Erro ao salvar configuração!', 'error', 'alertSLAConfigContainer');
        return;
    }

    // Atualizar dados da etapa
    etapa.responsavel = document.getElementById('slaEditResponsavel').value;
    etapa.slaAtivo = document.querySelector('input[name="slaEditAtivo"]:checked').value === 'true';

    if (etapa.slaAtivo) {
        const tipoSLA = document.querySelector('input[name="slaEditTipo"]:checked').value;
        etapa.slaVariavel = (tipoSLA === 'variavel');

        if (tipoSLA === 'fixo') {
            etapa.slaMinutos = parseInt(document.getElementById('slaEditMinutos').value);
            etapa.origemSLA = null;
        } else {
            etapa.slaMinutos = null;
            etapa.origemSLA = parseInt(document.getElementById('slaEditOrigemSLA').value);
        }
    } else {
        etapa.slaMinutos = null;
        etapa.slaVariavel = false;
        etapa.origemSLA = null;
    }

    // Salvar configuração
    saveSLAConfig(config);

    // Atualizar ETAPAS_CONFIG global (para novos chamados)
    atualizarETAPAS_CONFIG(tipoProcesso, config);

    showAlert('✅ Configuração de SLA atualizada com sucesso!', 'success', 'alertSLAConfigContainer');
    fecharModalEditarSLA();
    carregarTabelaSLA(tipoProcesso);
}

/**
 * Atualiza a configuração global ETAPAS_CONFIG
 * (Afeta apenas novos chamados)
 */
function atualizarETAPAS_CONFIG(tipoProcesso, config) {
    const etapas = config[tipoProcesso];

    if (!etapas) return;

    etapas.forEach((etapa, index) => {
        if (ETAPAS_CONFIG[index]) {
            ETAPAS_CONFIG[index].responsavel = etapa.responsavel;
            ETAPAS_CONFIG[index].sla = etapa.slaAtivo ? etapa.slaMinutos : null;

            // Subetapas (Etapa 5)
            if (etapa.subetapas && ETAPAS_CONFIG[index].subetapas) {
                etapa.subetapas.forEach((sub, subIndex) => {
                    if (ETAPAS_CONFIG[index].subetapas[subIndex]) {
                        ETAPAS_CONFIG[index].subetapas[subIndex].responsavel = sub.responsavel;
                        ETAPAS_CONFIG[index].subetapas[subIndex].sla = sub.slaMinutos;
                    }
                });
            }
        }
    });
}

/**
 * Resetar configurações de SLA para o padrão
 */
function resetarSLAConfig() {
    if (!confirm('⚠️ ATENÇÃO: Isso irá resetar TODAS as configurações de SLA para os valores padrão.\n\nTem certeza?')) {
        return;
    }

    localStorage.removeItem('slaConfig');
    showAlert('✅ Configurações de SLA resetadas com sucesso!', 'success', 'alertSLAConfigContainer');

    // Recarregar a tela
    const select = document.getElementById('slaConfigTipoProcesso');
    const tipoSelecionado = select ? select.value : '';
    
    if (tipoSelecionado) {
        carregarTabelaSLA(tipoSelecionado);
    } else {
        // Recarregar o processo ativo
        const processoAtivo = getProcessoAtivo();
        if (processoAtivo) {
            select.value = processoAtivo.id;
            carregarTabelaSLA(processoAtivo.id);
        }
    }
}

// Inicializar event listener quando a página carregar
document.addEventListener('DOMContentLoaded', function () {
    const formEditarSLA = document.getElementById('formEditarSLA');
    if (formEditarSLA) {
        formEditarSLA.addEventListener('submit', salvarConfiguracaoSLA);
    }
});

console.log('✅ SLA Config System carregado!');