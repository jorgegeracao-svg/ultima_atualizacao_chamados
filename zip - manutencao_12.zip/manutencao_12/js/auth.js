// ==================== SISTEMA DE AUTENTICAÇÃO ====================

function initUsuarios() {
    let usuarios = Storage.getUsuarios();
    if (usuarios.length === 0) {
        usuarios = [
            {
                id: 1,
                nomeCompleto: "Programador Sistema",
                re: "00000",
                cargo: "Programador",
                localTrabalho: "Administrativo",
                gestor: "",
                gerente: "",
                perfil: "PROGRAMADOR",
                status: "Ativo",
                usuario: "admin",
                senha: "admin",
                foto: null,
                dataCadastro: new Date().toISOString()
            },
            {
                id: 2,
                nomeCompleto: "Felipe Jorge",
                re: "12345",
                cargo: "Solicitante",
                localTrabalho: "Canteiro A",
                gestor: "Caian Silva",
                gerente: "Pedro Costa",
                perfil: "SOLICITANTE",
                status: "Ativo",
                usuario: "felipe.jorge",
                senha: "123456",
                foto: null,
                dataCadastro: new Date().toISOString()
            },
            {
                id: 3,
                nomeCompleto: "Thiago Santos",
                re: "12346",
                cargo: "Técnico de Manutenção",
                localTrabalho: "Manutenção",
                gestor: "João Santos",
                gerente: "Ana Lima",
                perfil: "TECNICO",
                status: "Ativo",
                usuario: "thiago.santos",
                senha: "123456",
                foto: null,
                dataCadastro: new Date().toISOString()
            },
            {
                id: 4,
                nomeCompleto: "Carlos Eduardo",
                re: "12347",
                cargo: "Administrativo da Manutenção",
                localTrabalho: "Manutenção",
                gestor: "João Santos",
                gerente: "Ana Lima",
                perfil: "ADMINISTRATIVO",
                status: "Ativo",
                usuario: "carlos.eduardo",
                senha: "123456",
                foto: null,
                dataCadastro: new Date().toISOString()
            },
            {
                id: 5,
                nomeCompleto: "Robert Silva",
                re: "12348",
                cargo: "Comprador",
                localTrabalho: "Compras",
                gestor: "Maria Oliveira",
                gerente: "Carlos Souza",
                perfil: "COMPRADOR",
                status: "Ativo",
                usuario: "robert.silva",
                senha: "123456",
                foto: null,
                dataCadastro: new Date().toISOString()
            },
            {
                id: 6,
                nomeCompleto: "Caian Silva",
                re: "12349",
                cargo: "Gestor",
                localTrabalho: "Escritório Central",
                gestor: "",
                gerente: "Pedro Costa",
                perfil: "GESTOR",
                status: "Ativo",
                usuario: "caian.silva",
                senha: "123456",
                foto: null,
                dataCadastro: new Date().toISOString()
            }
        ];
        Storage.saveUsuarios(usuarios);
    }
}

function getCurrentUser() {
    const userLogin = Storage.getCurrentUserLogin();
    if (!userLogin) return null;

    const usuarios = Storage.getUsuarios();
    return usuarios.find(u => u.usuario === userLogin);
}

function checkAuth() {
    const user = getCurrentUser();
    if (!user) {
        document.getElementById('loginScreen').classList.remove('hidden');
        document.getElementById('appContainer').classList.add('hidden');
        return false;
    }

    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('appContainer').classList.remove('hidden');
    document.getElementById('currentUser').textContent = user.nomeCompleto;

    // Adicionar perfil do usuário
    const perfilNome = {
        'SOLICITANTE': 'Solicitante',
        'TECNICO': 'Técnico',
        'ADMINISTRATIVO': 'Administrativo',
        'COMPRADOR': 'Comprador',
        'GESTOR': 'Gestor',
        'PROGRAMADOR': 'Programador'
    }[user.perfil] || user.perfil;
    document.getElementById('currentUserProfile').textContent = perfilNome;

    if (user.perfil === 'PROGRAMADOR') {
        document.getElementById('menuProgramador').classList.remove('hidden');
        document.getElementById("menuEditar").classList.remove("hidden");
        document.getElementById("menuSLAConfig").classList.remove("hidden");
        document.getElementById("menuAdmin").classList.remove("hidden");
    }

    return true;
}

function logout() {
    Storage.removeCurrentUserLogin();
    document.getElementById('menuProgramador').classList.add('hidden');
    document.getElementById("menuEditar").classList.add("hidden");
    document.getElementById("menuSLAConfig").classList.add("hidden");
    document.getElementById("menuAdmin").classList.add("hidden");
    checkAuth();
}

// Event Listener para login
document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const usuarios = Storage.getUsuarios();

    console.log('Tentando login com:', username);
    console.log('Total de usuários:', usuarios.length);

    const user = usuarios.find(u => u.usuario === username && u.senha === password);

    if (user) {
        if (user.status === 'Desligado') {
            showAlert('Usuário desligado. Entre em contato com o administrador.', 'error', 'loginAlert');
            return;
        }

        Storage.setCurrentUserLogin(user.usuario);
        showAlert('Login realizado com sucesso!', 'success', 'loginAlert');
        setTimeout(() => {
            checkAuth();
            // Sempre redirecionar para caixa de entrada
            showScreen('entrada');
            loadChamados();
        }, 500);
    } else {
        showAlert('Usuário ou senha incorretos!', 'error', 'loginAlert');
    }
});