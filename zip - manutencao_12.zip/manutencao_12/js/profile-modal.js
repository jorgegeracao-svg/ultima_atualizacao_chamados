// ==================== MODAL DE PERFIL DO COLABORADOR ====================

function abrirPerfilColaborador(usuarioLogin) {
    const usuarios = Storage.getUsuarios();
    const usuario = usuarios.find(u => u.usuario === usuarioLogin);
    
    if (!usuario) {
        showAlert('Usuário não encontrado!', 'error');
        return;
    }
    
    const perfilNome = {
        'SOLICITANTE': 'Solicitante',
        'TECNICO': 'Técnico',
        'ADMINISTRATIVO': 'Administrativo',
        'COMPRADOR': 'Comprador',
        'GESTOR': 'Gestor',
        'PROGRAMADOR': 'Programador'
    }[usuario.perfil] || usuario.perfil;
    
    // Foto padrão se não houver
    const fotoUrl = usuario.foto || 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="200"%3E%3Crect fill="%23052659" width="200" height="200"/%3E%3Ctext fill="%23ffffff" font-size="80" font-family="Arial" x="50%25" y="50%25" text-anchor="middle" dy=".3em"%3E' + (usuario.nomeCompleto.charAt(0).toUpperCase()) + '%3C/text%3E%3C/svg%3E';
    
    document.getElementById('perfilColaboradorContent').innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; gap: 24px;">
            <!-- Foto do Colaborador -->
            <div style="width: 150px; height: 150px; border-radius: 50%; overflow: hidden; border: 4px solid #052659; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
                <img src="${fotoUrl}" alt="${usuario.nomeCompleto}" 
                     style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            
            <!-- Dados do Colaborador -->
            <div style="width: 100%; background: #f8fafc; padding: 20px; border-radius: 12px;">
                <div style="display: grid; gap: 16px;">
                    <div class="perfil-info-item">
                        <span class="perfil-label">👤 Nome Completo</span>
                        <span class="perfil-value">${usuario.nomeCompleto}</span>
                    </div>
                    
                    <div class="perfil-info-item">
                        <span class="perfil-label">🆔 RE</span>
                        <span class="perfil-value">${usuario.re}</span>
                    </div>
                    
                    <div class="perfil-info-item">
                        <span class="perfil-label">💼 Cargo</span>
                        <span class="perfil-value">${usuario.cargo}</span>
                    </div>
                    
                    <div class="perfil-info-item">
                        <span class="perfil-label">🏢 Local de Trabalho</span>
                        <span class="perfil-value">${usuario.localTrabalho}</span>
                    </div>
                    
                    <div class="perfil-info-item">
                        <span class="perfil-label">🎯 Perfil</span>
                        <span class="perfil-value">${perfilNome}</span>
                    </div>
                    
                    ${usuario.gestor ? `
                    <div class="perfil-info-item">
                        <span class="perfil-label">👔 Gestor</span>
                        <span class="perfil-value">${usuario.gestor}</span>
                    </div>
                    ` : ''}
                    
                    ${usuario.gerente ? `
                    <div class="perfil-info-item">
                        <span class="perfil-label">👨‍💼 Gerente</span>
                        <span class="perfil-value">${usuario.gerente}</span>
                    </div>
                    ` : ''}
                    
                    <div class="perfil-info-item">
                        <span class="perfil-label">📊 Status</span>
                        <span class="perfil-value">
                            <span class="status-badge ${usuario.status === 'Ativo' ? 'status-ativo' : 'status-desligado'}">
                                ${usuario.status}
                            </span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('modalPerfilColaborador').classList.add('active');
}

function fecharPerfilColaborador() {
    document.getElementById('modalPerfilColaborador').classList.remove('active');
}