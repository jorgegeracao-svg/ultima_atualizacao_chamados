// ==================== EDIÇÃO E EXCLUSÃO DE CHAMADOS ====================

let chamadoParaExcluir = null;

function loadChamadosEditar() {
    const chamados = Storage.getChamados();
    renderChamadosEditar(chamados);
}

function renderChamadosEditar(chamados) {
    const tbody = document.getElementById('editarTableBody');
    
    if (chamados.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; padding: 48px; color: #7DA0CA;">
                    📋 Nenhum chamado cadastrado no sistema.
                </td>
            </tr>
        `;
        return;
    }
    
    // Ordenar por ID decrescente (mais recentes primeiro)
    chamados.sort((a, b) => b.id - a.id);
    
    tbody.innerHTML = chamados.map(c => {
        const etapaAtual = ETAPAS_CONFIG.find(e => e.numero === c.etapaAtual);
        const solicitante = Storage.getUsuarios().find(u => u.usuario === c.solicitante);
        
        let statusClass = '';
        let statusIcon = '';
        let statusText = '';
        
        switch(c.status) {
            case 'EM_ANDAMENTO':
                statusClass = 'status-em-andamento';
                statusIcon = '🔄';
                statusText = 'Em Andamento';
                break;
            case 'CONCLUIDO':
                statusClass = 'status-concluido';
                statusIcon = '✅';
                statusText = 'Concluído';
                break;
            case 'CANCELADO':
                statusClass = 'status-cancelado';
                statusIcon = '❌';
                statusText = 'Cancelado';
                break;
        }
        
        return `
            <tr>
                <td><strong>#${c.id}</strong></td>
                <td>${c.titulo}</td>
                <td style="font-size: 0.85rem;">${c.unidade || '-'}</td>
                <td>${solicitante?.nomeCompleto || c.solicitante}</td>
                <td>${new Date(c.dataAbertura).toLocaleDateString('pt-BR')}</td>
                <td style="font-size: 0.85rem;">
                    ${etapaAtual ? `${etapaAtual.numero}. ${etapaAtual.nome}` : '-'}
                </td>
                <td>
                    <span class="status-badge ${statusClass}">
                        ${statusIcon} ${statusText}
                    </span>
                </td>
                <td>
                    <button class="btn-icon btn-edit" onclick="showDetalhes(${c.id})" title="Ver Detalhes">
                        👁️
                    </button>
                    <button class="btn-icon btn-delete" onclick="abrirModalExcluirChamado(${c.id})" title="Excluir">
                        🗑️
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function filtrarChamadosEditar() {
    const numero = document.getElementById('filterEditarNumero').value.toLowerCase();
    const data = document.getElementById('filterEditarData').value;
    const status = document.getElementById('filterEditarStatus').value;
    
    let chamados = Storage.getChamados();
    
    if (numero) {
        chamados = chamados.filter(c => 
            c.id.toString().includes(numero) ||
            c.titulo.toLowerCase().includes(numero)
        );
    }
    
    if (data) {
        chamados = chamados.filter(c => {
            const dataAbertura = new Date(c.dataAbertura).toISOString().split('T')[0];
            return dataAbertura === data;
        });
    }
    
    if (status) {
        chamados = chamados.filter(c => c.status === status);
    }
    
    renderChamadosEditar(chamados);
}

function limparFiltrosEditar() {
    document.getElementById('filterEditarNumero').value = '';
    document.getElementById('filterEditarData').value = '';
    document.getElementById('filterEditarStatus').value = '';
    loadChamadosEditar();
}

// ==================== EXCLUSÃO DE CHAMADOS ====================

function abrirModalExcluirChamado(chamadoId) {
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error', 'alertEditarContainer');
        return;
    }
    
    chamadoParaExcluir = chamadoId;
    
    const solicitante = Storage.getUsuarios().find(u => u.usuario === chamado.solicitante);
    const etapaAtual = ETAPAS_CONFIG.find(e => e.numero === chamado.etapaAtual);
    
    document.getElementById('dadosChamadoExcluir').innerHTML = `
        <div style="display: grid; gap: 8px; font-size: 0.9rem;">
            <div><strong style="color: #052659;">Nº:</strong> #${chamado.id}</div>
            <div><strong style="color: #052659;">Título:</strong> ${chamado.titulo}</div>
            <div><strong style="color: #052659;">Solicitante:</strong> ${solicitante?.nomeCompleto || chamado.solicitante}</div>
            <div><strong style="color: #052659;">Data Abertura:</strong> ${new Date(chamado.dataAbertura).toLocaleString('pt-BR')}</div>
            <div><strong style="color: #052659;">Etapa Atual:</strong> ${etapaAtual ? `${etapaAtual.numero}. ${etapaAtual.nome}` : '-'}</div>
            <div><strong style="color: #052659;">Unidade:</strong> ${chamado.unidade || '-'}</div>
        </div>
    `;
    
    document.getElementById('modalExcluirChamado').classList.add('active');
}

function fecharModalExcluirChamado() {
    chamadoParaExcluir = null;
    document.getElementById('modalExcluirChamado').classList.remove('active');
}

function confirmarExclusaoChamado() {
    if (!chamadoParaExcluir) {
        showAlert('Nenhum chamado selecionado para exclusão!', 'error', 'alertEditarContainer');
        return;
    }
    
    let chamados = Storage.getChamados();
    const chamadoIndex = chamados.findIndex(c => c.id === chamadoParaExcluir);
    
    if (chamadoIndex === -1) {
        showAlert('Chamado não encontrado!', 'error', 'alertEditarContainer');
        fecharModalExcluirChamado();
        return;
    }
    
    const chamadoExcluido = chamados[chamadoIndex];
    chamados.splice(chamadoIndex, 1);
    Storage.saveChamados(chamados);
    
    showAlert(`Chamado #${chamadoExcluido.id} excluído com sucesso!`, 'success', 'alertEditarContainer');
    fecharModalExcluirChamado();
    loadChamadosEditar();
    
    // Atualizar outras telas se estiverem carregadas
    if (typeof loadChamados === 'function') {
        loadChamados();
    }
}

// ==================== FUNÇÕES DE EDIÇÃO (FUTURAS) ====================

function editarChamado(chamadoId) {
    // Função para editar chamados - pode ser implementada futuramente
    showAlert('Função de edição em desenvolvimento!', 'error', 'alertEditarContainer');
}