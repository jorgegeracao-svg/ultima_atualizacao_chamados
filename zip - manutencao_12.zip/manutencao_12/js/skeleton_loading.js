// ==================== SKELETON LOADING SYSTEM ====================

/**
 * Mostra o overlay de loading com mensagem personalizada
 * @param {string} mensagem - Mensagem a ser exibida (opcional)
 */
function showLoading(mensagem = 'Carregando') {
    const overlay = document.getElementById('loadingOverlay');
    const loadingText = document.getElementById('loadingText');
    
    if (loadingText) {
        loadingText.innerHTML = `<span class="loading-dots">${mensagem}</span>`;
    }
    
    if (overlay) {
        overlay.classList.add('active');
    }
}

/**
 * Esconde o overlay de loading
 * @param {number} delay - Delay em milissegundos antes de esconder (opcional)
 */
function hideLoading(delay = 0) {
    const overlay = document.getElementById('loadingOverlay');
    
    if (!overlay) return;
    
    setTimeout(() => {
        overlay.classList.add('fade-out');
        
        setTimeout(() => {
            overlay.classList.remove('active', 'fade-out');
        }, 400);
    }, delay);
}

/**
 * Executa uma função com loading automático
 * @param {Function} funcao - Função assíncrona a ser executada
 * @param {string} mensagem - Mensagem de loading
 * @returns {Promise} Resultado da função
 */
async function executarComLoading(funcao, mensagem = 'Processando') {
    showLoading(mensagem);
    
    try {
        const resultado = await funcao();
        hideLoading(200);
        return resultado;
    } catch (erro) {
        hideLoading(200);
        throw erro;
    }
}

/**
 * Simula um loading por tempo determinado (útil para testes)
 * @param {number} tempo - Tempo em milissegundos
 * @param {string} mensagem - Mensagem de loading
 */
function simularLoading(tempo = 2000, mensagem = 'Processando') {
    showLoading(mensagem);
    
    setTimeout(() => {
        hideLoading();
    }, tempo);
}

// Exportar funções para uso global
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.executarComLoading = executarComLoading;
window.simularLoading = simularLoading;

console.log('✅ Skeleton Loading System inicializado!');