// ==================== CONFIGURAÇÃO DE ETAPAS ====================

const ETAPAS_CONFIG = [
    {
        numero: 1,
        nome: "Abertura do Chamado",
        responsavel: "SOLICITANTE",
        sla: null,
        campos: ["titulo", "telefone", "unidade", "tipoManutencao", "local", "descricao", "anexos"]
    },
    {
        numero: 2,
        nome: "Agendamento da Avaliação Física",
        responsavel: "ADMINISTRATIVO",
        sla: 20,
        campos: ["dataAgendamento", "responsavelVisita", "observacoes"]
    },
    {
        numero: 3,
        nome: "Descrição do Serviço",
        responsavel: "TECNICO",
        sla: 1440,
        campos: ["tipoServico", "servicosRealizados", "produtosNecessarios"]
    },
    {
        numero: 4,
        nome: "Verificação de Estoque",
        responsavel: "TECNICO",
        sla: 1440,
        campos: ["temEstoque", "observacoes"]
    },
    {
        numero: 5,
        nome: "Processo de Compras",
        responsavel: "COMPRADOR",
        subetapas: [
            { numero: 5.1, nome: "Cotação", sla: 120, responsavel: "COMPRADOR" },
            { numero: 5.2, nome: "Envio do Orçamento", sla: null, responsavel: "COMPRADOR" },
            { numero: 5.3, nome: "Aprovação do Orçamento", sla: 120, responsavel: "GESTOR" },
            { numero: 5.4, nome: "Recebimento das Mercadorias", sla: null, responsavel: "TECNICO" }
        ]
    },
    {
        numero: 6,
        nome: "Programar Data de Manutenção",
        responsavel: "ADMINISTRATIVO",
        sla: 120,
        campos: ["dataManutencao", "observacoes"]
    },
    {
        numero: 7,
        nome: "Realizar Manutenção",
        responsavel: "TECNICO",
        sla: null,
        campos: ["fotosServico", "observacoes"]
    },
    {
        numero: 8,
        nome: "Finalizar Chamado",
        responsavel: "SOLICITANTE",
        sla: 120,
        campos: ["avaliacao", "comentarios"]
    }
];

// ==================== PERFIS DE USUÁRIO ====================

const PERFIS = {
    SOLICITANTE: 'SOLICITANTE',
    TECNICO: 'TECNICO',
    ADMINISTRATIVO: 'ADMINISTRATIVO',
    COMPRADOR: 'COMPRADOR',
    GESTOR: 'GESTOR',
    PROGRAMADOR: 'PROGRAMADOR'
};

// ==================== STATUS ====================

const STATUS = {
    EM_ANDAMENTO: 'EM_ANDAMENTO',
    CONCLUIDO: 'CONCLUIDO',
    CANCELADO: 'CANCELADO'
};

const STATUS_ETAPA = {
    AGUARDANDO: 'AGUARDANDO',
    CONCLUIDA: 'CONCLUIDA',
    ATRASADA: 'ATRASADA'
};

// ==================== TIPOS DE PROCESSOS ====================

const TIPOS_PROCESSOS = {
    MANUTENCAO: {
        id: 'MANUTENCAO',
        nome: 'Manutenção de Canteiro',
        icone: '🔧',
        ativo: true,
        opcoes: [
            { valor: 'Elétrica', icone: '⚡', descricao: 'Instalações e reparos elétricos' },
            { valor: 'Hidráulica', icone: '💧', descricao: 'Sistemas de água e esgoto' },
            { valor: 'Civil', icone: '🏗️', descricao: 'Construção e reformas estruturais' },
            { valor: 'Pintura', icone: '🎨', descricao: 'Pintura e acabamento' },
            { valor: 'Ar Condicionado', icone: '❄️', descricao: 'Climatização e refrigeração' },
            { valor: 'Jardinagem', icone: '🌿', descricao: 'Paisagismo e manutenção de áreas verdes' },
            { valor: 'Carpintaria', icone: '🪚', descricao: 'Trabalhos em madeira' },
            { valor: 'Serralheria', icone: '⚒️', descricao: 'Estruturas metálicas e portões' },
            { valor: 'Limpeza', icone: '🧹', descricao: 'Limpeza e conservação' },
            { valor: 'Outros', icone: '🔧', descricao: 'Outros tipos de manutenção' }
        ]
    },
    LANCAMENTO_NF: {
        id: 'LANCAMENTO_NF',
        nome: 'Lançamento de Nota Fiscal',
        icone: '📄',
        ativo: false,
        opcoes: [
            { valor: 'NF Entrada', icone: '📥', descricao: 'Nota fiscal de entrada de mercadorias' },
            { valor: 'NF Serviço', icone: '🛠️', descricao: 'Nota fiscal de prestação de serviços' },
            { valor: 'NF Devolução', icone: '↩️', descricao: 'Nota fiscal de devolução' },
            { valor: 'NF Transferência', icone: '🔄', descricao: 'Nota fiscal de transferência entre unidades' }
        ]
    },
    PEDIDOS: {
        id: 'PEDIDOS',
        nome: 'Pedidos e Solicitações',
        icone: '🛒',
        ativo: false,
        opcoes: [
            { valor: 'Material Escritório', icone: '📎', descricao: 'Papelaria e materiais de escritório' },
            { valor: 'Equipamentos TI', icone: '💻', descricao: 'Computadores, impressoras, etc' },
            { valor: 'Ferramentas', icone: '🔨', descricao: 'Ferramentas e equipamentos' },
            { valor: 'EPI', icone: '🦺', descricao: 'Equipamentos de proteção individual' },
            { valor: 'Uniformes', icone: '👔', descricao: 'Uniformes e vestimentas' }
        ]
    }
};

function getProcessoAtivo() {
    return Object.values(TIPOS_PROCESSOS).find(p => p.ativo);
}

function getOpcoesProcessoAtivo() {
    const processo = getProcessoAtivo();
    return processo ? processo.opcoes : [];
}

const TIPOS_MANUTENCAO = TIPOS_PROCESSOS.MANUTENCAO.opcoes;

// ==================== UNIDADES ====================

const UNIDADES = [
    'ILUMINACAO PAULISTANA SPE S/A.',
    'DEMERVAL LUZ SPE LTDA',
    'FORQUILHA LUZ ILUMINACAO PUBLICA SPE S.A',
    'CAIEIRAS LUZ SERV. ILUM.PUBLICA SPE S.A.',
    'MANAUS LUZ SERV. ILUM. PUBLICA SPE LTDA',
    'SJR ILUMINACAO DO FUTURO SPE S/A',
    'FM RODRIGUES',
    'CONSTRUTAMI',
    '888 ENGENHARIA LTDA',
    'SALFENA',
    'TERESINA LUZ S.A.',
    'FORTALEZA LUZ'
];