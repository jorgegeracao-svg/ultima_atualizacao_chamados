// ==================== PATCH PARA DETALHES.JS ====================
// 
// INSTRUÇÕES: Substituir a função showDetalhes() no arquivo detalhes.js
// pelas linhas 100-146 atualizadas abaixo:

/*

LINHA 100-146 ATUALIZADA:

                <!-- Botões de Navegação -->
                <div class="detalhes-tabs" style="display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap;">
                    <button class="tab-button active" onclick="trocarAbaDetalhes(${chamado.id}, 'etapas')" id="tabEtapas">
                        🎯 Etapas
                    </button>
                    <button class="tab-button" onclick="trocarAbaDetalhes(${chamado.id}, 'sumario')" id="tabSumario">
                        📄 Sumário
                    </button>
                    <button class="tab-button" onclick="trocarAbaDetalhes(${chamado.id}, 'formularios')" id="tabFormularios">
                        📝 Formulários
                    </button>
                    <button class="tab-button" onclick="trocarAbaDetalhes(${chamado.id}, 'anexos')" id="tabAnexos">
                        📎 Anexos
                    </button>
                    <button class="tab-button" onclick="trocarAbaDetalhes(${chamado.id}, 'fluxo')" id="tabFluxo">
                        📊 Fluxo Completo
                    </button>
                </div>
            </div>
            
            <div class="card-body">
                <!-- Conteúdo da Aba Etapas -->
                <div id="abaEtapas" class="aba-conteudo active">
                    ${timelineHTML}

                    <!-- 🔥 BOTÕES DE VOLTAR ETAPA -->
                     ${renderBotoesVoltarEtapa(chamado, currentUser)}
                </div>

                <!-- Conteúdo da Aba Sumário -->
                <div id="abaSumario" class="aba-conteudo" style="display: none;">
                    ${renderSumarioEtapas(chamado)}
                </div>
                
                <!-- Conteúdo da Aba Formulários -->
                <div id="abaFormularios" class="aba-conteudo" style="display: none;">
                    ${renderFormulariosDados(chamado)}
                </div>
                
                <!-- Conteúdo da Aba Anexos -->
                <div id="abaAnexos" class="aba-conteudo" style="display: none;">
                    ${renderAnexosDados(chamado)}
                </div>
                
                <!-- Conteúdo da Aba Fluxo -->
                <div id="abaFluxo" class="aba-conteudo" style="display: none;">
                    ${renderFluxoCompleto(chamado)}
                </div>
            </div>

*/

// ==================== ATUALIZAR FUNÇÃO trocarAbaDetalhes ====================
//
// Localizar a função trocarAbaDetalhes() no arquivo detalhes.js
// e adicionar o caso 'sumario' no switch:

function trocarAbaDetalhes(chamadoId, aba) {
    // Remover active de todos os botões
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Esconder todas as abas
    document.querySelectorAll('.aba-conteudo').forEach(content => {
        content.style.display = 'none';
        content.classList.remove('active');
    });
    
    // Ativar aba selecionada
    switch(aba) {
        case 'etapas':
            document.getElementById('tabEtapas').classList.add('active');
            document.getElementById('abaEtapas').style.display = 'block';
            document.getElementById('abaEtapas').classList.add('active');
            break;
            
        case 'sumario':
            document.getElementById('tabSumario').classList.add('active');
            document.getElementById('abaSumario').style.display = 'block';
            document.getElementById('abaSumario').classList.add('active');
            break;
            
        case 'formularios':
            document.getElementById('tabFormularios').classList.add('active');
            document.getElementById('abaFormularios').style.display = 'block';
            document.getElementById('abaFormularios').classList.add('active');
            break;
            
        case 'anexos':
            document.getElementById('tabAnexos').classList.add('active');
            document.getElementById('abaAnexos').style.display = 'block';
            document.getElementById('abaAnexos').classList.add('active');
            break;
            
        case 'fluxo':
            document.getElementById('tabFluxo').classList.add('active');
            document.getElementById('abaFluxo').style.display = 'block';
            document.getElementById('abaFluxo').classList.add('active');
            break;
    }
}