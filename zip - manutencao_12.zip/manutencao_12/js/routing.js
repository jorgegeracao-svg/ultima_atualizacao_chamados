// ==================== GERENCIAMENTO DE ROTEAMENTO DE CHAMADOS ====================

/**
 * Determina em qual caixa o chamado deve aparecer para o usuário atual
 * @param {object} chamado - Objeto do chamado
 * @param {object} currentUser - Usuário atual
 * @returns {string} 'entrada', 'log' ou 'saida'
 */
function determinarCaixaChamado(chamado, currentUser) {
    // Chamados concluídos ou cancelados vão para saída
    if (chamado.status === 'CONCLUIDO' || chamado.status === 'CANCELADO') {
        // Verifica se o usuário participou do chamado
        const participou = verificarParticipacao(chamado, currentUser);
        
        if (participou) {
            return 'saida';
        }
        
        // Se não participou, não aparece em lugar nenhum
        return null;
    }
    
    // Chamados em andamento
    if (chamado.status === 'EM_ANDAMENTO') {
        const etapaAtual = chamado.etapas.find(e => e.numero === chamado.etapaAtual);
        const etapaConfig = ETAPAS_CONFIG[chamado.etapaAtual - 1];
        
        // Verifica se é responsável pela etapa atual
        if (etapaAtual) {
            // Responsável específico atribuído
            if (etapaAtual.responsavel === currentUser.usuario) {
                return 'entrada';
            }
            
            // Responsável por perfil (quando responsavel está null ou não definido)
            if (!etapaAtual.responsavel && etapaConfig) {
                if (verificarResponsabilidadePorPerfil(etapaConfig, currentUser, chamado)) {
                    return 'entrada';
                }
            }
        }
        
        // Verifica se já passou pelo usuário mas ainda pode voltar
        const podeVoltar = verificarSePodeVoltar(chamado, currentUser);
        
        if (podeVoltar) {
            return 'log';
        }
        
        // Se participou mas não vai mais passar por ele
        const participou = verificarParticipacao(chamado, currentUser);
        
        if (participou) {
            return 'saida';
        }
    }
    
    return null;
}

/**
 * Verifica se o usuário já participou do chamado
 * @param {object} chamado - Objeto do chamado
 * @param {object} usuario - Usuário
 * @returns {boolean}
 */
function verificarParticipacao(chamado, usuario) {
    // Verifica no histórico
    const participouHistorico = chamado.historico.some(h => h.usuario === usuario.usuario);
    
    // Verifica nas etapas
    const participouEtapas = chamado.etapas.some(e => e.responsavel === usuario.usuario);
    
    // Verifica se é o solicitante
    const ehSolicitante = chamado.solicitante === usuario.usuario;
    
    return participouHistorico || participouEtapas || ehSolicitante;
}

/**
 * Verifica se o chamado pode voltar para o usuário no futuro
 * @param {object} chamado - Objeto do chamado
 * @param {object} usuario - Usuário
 * @returns {boolean}
 */
function verificarSePodeVoltar(chamado, usuario) {
    const etapaAtualIndex = chamado.etapaAtual - 1;
    
    // Verifica etapas futuras
    for (let i = etapaAtualIndex + 1; i < ETAPAS_CONFIG.length; i++) {
        const etapaConfig = ETAPAS_CONFIG[i];
        
        // Etapa 5 tem subetapas
        if (etapaConfig.numero === 5 && etapaConfig.subetapas) {
            for (const subetapa of etapaConfig.subetapas) {
                if (verificarResponsabilidadePorPerfilConfig(subetapa.responsavel, usuario, chamado)) {
                    return true;
                }
            }
        } else {
            if (verificarResponsabilidadePorPerfilConfig(etapaConfig.responsavel, usuario, chamado)) {
                return true;
            }
        }
    }
    
    return false;
}

/**
 * Verifica responsabilidade por perfil da configuração
 * @param {string} perfilConfig - Perfil da configuração
 * @param {object} usuario - Usuário
 * @param {object} chamado - Chamado
 * @returns {boolean}
 */
function verificarResponsabilidadePorPerfilConfig(perfilConfig, usuario, chamado) {
    if (perfilConfig === 'SOLICITANTE') {
        return chamado.solicitante === usuario.usuario;
    }
    
    return usuario.perfil === perfilConfig;
}

/**
 * Verifica responsabilidade por perfil
 * @param {object} etapaConfig - Configuração da etapa
 * @param {object} usuario - Usuário
 * @param {object} chamado - Chamado
 * @returns {boolean}
 */
function verificarResponsabilidadePorPerfil(etapaConfig, usuario, chamado) {
    if (!etapaConfig) {
        return false;
    }
    
    if (etapaConfig.responsavel === 'SOLICITANTE') {
        return chamado.solicitante === usuario.usuario;
    }
    
    return usuario.perfil === etapaConfig.responsavel;
}

/**
 * Filtra chamados por caixa para o usuário atual
 * @param {Array} chamados - Array de chamados
 * @param {object} currentUser - Usuário atual
 * @param {string} caixa - 'entrada', 'log' ou 'saida'
 * @returns {Array} Array de chamados filtrados
 */
function filtrarChamadosPorCaixa(chamados, currentUser, caixa) {
    return chamados.filter(chamado => {
        const caixaDeterminada = determinarCaixaChamado(chamado, currentUser);
        return caixaDeterminada === caixa;
    });
}

/**
 * Conta chamados por caixa
 * @param {Array} chamados - Array de chamados
 * @param {object} currentUser - Usuário atual
 * @returns {object} Objeto com contadores {entrada, log, saida}
 */
function contarChamadosPorCaixa(chamados, currentUser) {
    const contadores = {
        entrada: 0,
        log: 0,
        saida: 0
    };
    
    chamados.forEach(chamado => {
        const caixa = determinarCaixaChamado(chamado, currentUser);
        if (caixa) {
            contadores[caixa]++;
        }
    });
    
    return contadores;
}

/**
 * Atualiza badges de contador nas abas do menu
 * @param {object} contadores - Objeto com contadores
 */
function atualizarBadgesMenu(contadores) {
    // Atualizar badge da caixa de entrada
    const badgeEntrada = document.querySelector('#menuEntrada .menu-badge');
    if (badgeEntrada) {
        if (contadores.entrada > 0) {
            badgeEntrada.textContent = contadores.entrada;
            badgeEntrada.style.display = 'flex';
        } else {
            badgeEntrada.style.display = 'none';
        }
    }
    
    // Atualizar badge do log
    const badgeLog = document.querySelector('#menuLog .menu-badge');
    if (badgeLog) {
        if (contadores.log > 0) {
            badgeLog.textContent = contadores.log;
            badgeLog.style.display = 'flex';
        } else {
            badgeLog.style.display = 'none';
        }
    }
    
    // Atualizar badge da caixa de saída
    const badgeSaida = document.querySelector('#menuSaida .menu-badge');
    if (badgeSaida) {
        if (contadores.saida > 0) {
            badgeSaida.textContent = contadores.saida;
            badgeSaida.style.display = 'flex';
        } else {
            badgeSaida.style.display = 'none';
        }
    }
}