// ==================== CONCLUSÃO DE ETAPAS ====================

// ========== ETAPA 1: Reedição da Abertura do Chamado ==========
async function concluirEtapa1Edicao(chamadoId) {
    // Validar campos obrigatórios
    const titulo = document.getElementById('tituloEdicao').value.trim();
    const telefone = document.getElementById('telefoneEdicao').value.trim();
    const unidade = document.getElementById('unidadeEdicao').value;
    const local = document.getElementById('localEdicao').value.trim();
    const descricao = document.getElementById('descricaoEdicao').value.trim();
    
    if (!titulo || !telefone || !unidade || !local || !descricao) {
        showAlert('Preencha todos os campos obrigatórios!', 'error');
        return;
    }
    
    // Coletar tipos de manutenção selecionados
    const tiposManutencao = Array.from(document.querySelectorAll('input[name="tipoManutencaoEdicao"]:checked'))
        .map(cb => cb.value);
    
    if (tiposManutencao.length === 0) {
        showAlert('Selecione pelo menos um tipo de manutenção!', 'error');
        return;
    }
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    
    // Processar novos anexos (se houver)
    const anexoInput = document.getElementById('anexoEdicao');
    let novosAnexos = [];
    
    if (anexoInput && anexoInput.files.length > 0) {
        try {
            novosAnexos = await processarMultiplasImagens(anexoInput.files, 5);
        } catch (error) {
            showAlert(error.message, 'error');
            return;
        }
    }
    
    // Atualizar dados do chamado principal
    chamado.titulo = titulo;
    chamado.telefone = telefone;
    chamado.unidade = unidade;
    chamado.local = local;
    chamado.tipoManutencao = tiposManutencao;
    chamado.descricao = descricao;
    
    // Adicionar novos anexos aos existentes
    if (novosAnexos.length > 0) {
        chamado.anexos = [...(chamado.anexos || []), ...novosAnexos];
    }
    
    // Atualizar etapa 1
    const etapa1 = chamado.etapas.find(e => e.numero === 1);
    etapa1.status = 'CONCLUIDA';
    etapa1.dataConclusao = new Date().toISOString();
    etapa1.responsavel = currentUser.usuario;
    etapa1.dados = {
        titulo,
        telefone,
        unidade,
        local,
        tipoManutencao: tiposManutencao,
        descricao
    };
    
    // Verificar se etapa 2 já existe
    let etapa2 = chamado.etapas.find(e => e.numero === 2);
    
    if (!etapa2) {
        // Criar etapa 2 pela primeira vez
        chamado.etapas.push({
            numero: 2,
            nome: "Agendamento da Avaliação Física",
            responsavel: null,
            dataInicio: new Date().toISOString(),
            dataConclusao: null,
            sla: 20,
            prazo: new Date(Date.now() + 20 * 60000).toISOString(),
            status: "AGUARDANDO",
            dados: {}
        });
    } else {
        // Reabrir etapa 2 se já existia
        etapa2.status = 'AGUARDANDO';
        etapa2.dataInicio = new Date().toISOString();
        etapa2.dataConclusao = null;
        etapa2.prazo = new Date(Date.now() + 20 * 60000).toISOString();
    }
    
    chamado.etapaAtual = 2;
    
    // Adicionar ao histórico
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: 'Reeditou as informações do chamado (Etapa 1)',
        etapa: 1
    });
    
    Storage.saveChamados(chamados);
    showAlert('Chamado atualizado com sucesso!', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 2: Agendamento da Avaliação ==========
function concluirEtapa2(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const dataAgendamento = document.getElementById('dataAgendamento').value;
    const responsavelVisita = document.getElementById('responsavelVisita').value;
    const observacoes = document.getElementById('observacoes').value;
    
    // CAMPO OBSERVAÇÃO OBRIGATÓRIO
    if (!dataAgendamento || !responsavelVisita || !observacoes || !observacoes.trim()) {
        showAlert('Preencha todos os campos obrigatórios, incluindo observações!', 'error');
        return;
    }
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    
    // Atualizar etapa 2
    const etapa2 = chamado.etapas.find(e => e.numero === 2);
    etapa2.status = 'CONCLUIDA';
    etapa2.dataConclusao = new Date().toISOString();
    etapa2.responsavel = currentUser.usuario;
    etapa2.dados = {
        dataAgendamento: dataAgendamento,
        responsavelVisita: responsavelVisita,
        observacoes: observacoes
    };
    
    // Criar etapa 3 com SLA de 2 HORAS (alterado de 24 horas)
    chamado.etapas.push({
        numero: 3,
        nome: "Descrição do Serviço",
        responsavel: null,
        dataInicio: new Date().toISOString(),
        dataConclusao: null,
        sla: 120, // 2 HORAS (alterado de 1440)
        prazo: new Date(Date.now() + 120 * 60000).toISOString(),
        status: "AGUARDANDO",
        dados: {}
    });
    
    chamado.etapaAtual = 3;
    
    // Adicionar ao histórico
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Agendou avaliação para ${new Date(dataAgendamento).toLocaleString('pt-BR')}`,
        etapa: 2
    });
    
    Storage.saveChamados(chamados);
    showAlert('Avaliação agendada com sucesso!', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 3: Descrição do Serviço ==========
function concluirEtapa3(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const tipoServico = document.querySelector('input[name="tipoServico"]:checked').value;
    const servicosRealizados = document.getElementById('servicosRealizados').value;
    const observacoesEtapa3 = document.getElementById('observacoesEtapa3').value;
    
    if (!servicosRealizados) {
        showAlert('Preencha a descrição dos serviços!', 'error');
        return;
    }
    
    // Coletar produtos
    const produtos = [];
    const produtosContainer = document.getElementById('produtosContainer');
    const produtoItems = produtosContainer.querySelectorAll('.produto-item');
    
    produtoItems.forEach((item, index) => {
        const nomeProduto = document.getElementById(`produto_${index}`);
        const qtdProduto = document.getElementById(`qtd_${index}`);
        
        if (nomeProduto && qtdProduto && nomeProduto.value.trim() && qtdProduto.value) {
            produtos.push({
                nome: nomeProduto.value.trim(),
                quantidade: parseInt(qtdProduto.value)
            });
        }
    });
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    
    // Atualizar etapa 3 - REMOVIDO dataProximaEtapa
    const etapa3 = chamado.etapas.find(e => e.numero === 3);
    etapa3.status = 'CONCLUIDA';
    etapa3.dataConclusao = new Date().toISOString();
    etapa3.responsavel = currentUser.usuario;
    etapa3.dados = {
        tipoServico: tipoServico,
        servicosRealizados: servicosRealizados,
        produtos: produtos,
        observacoes: observacoesEtapa3
    };
    
    // Criar etapa 4
    chamado.etapas.push({
        numero: 4,
        nome: "Verificação de Estoque",
        responsavel: null,
        dataInicio: new Date().toISOString(),
        dataConclusao: null,
        sla: 1440, // 24 horas
        prazo: new Date(Date.now() + 1440 * 60000).toISOString(),
        status: "AGUARDANDO",
        dados: {}
    });
    
    chamado.etapaAtual = 4;
    
    // Adicionar ao histórico
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Descreveu o serviço (${tipoServico}) - ${produtos.length} produto(s) necessário(s)`,
        etapa: 3
    });
    
    Storage.saveChamados(chamados);
    showAlert('Descrição do serviço registrada com sucesso!', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 4: Verificação de Estoque ==========
function concluirEtapa4(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const temEstoque = document.querySelector('input[name="temEstoque"]:checked').value;
    const observacoesEtapa4 = document.getElementById('observacoesEtapa4').value;
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    
    // Atualizar etapa 4
    const etapa4 = chamado.etapas.find(e => e.numero === 4);
    etapa4.status = 'CONCLUIDA';
    etapa4.dataConclusao = new Date().toISOString();
    etapa4.responsavel = currentUser.usuario;
    etapa4.dados = {
        temEstoque: temEstoque,
        observacoes: observacoesEtapa4
    };
    
    if (temEstoque === 'SIM') {
        // TEM estoque - ir direto para Etapa 6
        chamado.etapas.push({
            numero: 6,
            nome: "Programar Data de Manutenção",
            responsavel: null,
            dataInicio: new Date().toISOString(),
            dataConclusao: null,
            sla: 120, // 2 horas
            prazo: new Date(Date.now() + 120 * 60000).toISOString(),
            status: "AGUARDANDO",
            dados: {}
        });
        
        chamado.etapaAtual = 6;
        
        chamado.historico.push({
            data: new Date().toISOString(),
            usuario: currentUser.usuario,
            usuarioNome: currentUser.nomeCompleto,
            acao: 'Verificou estoque: Produtos disponíveis - Pulando para programação',
            etapa: 4
        });
    } else {
        // NÃO TEM estoque - ir para Etapa 5 (Compras)
        chamado.etapas.push({
            numero: 5,
            nome: "Processo de Compras",
            subetapa: 5.1,
            responsavel: null,
            dataInicio: new Date().toISOString(),
            dataConclusao: null,
            sla: 120, // 2 horas para cotação
            prazo: new Date(Date.now() + 120 * 60000).toISOString(),
            status: "AGUARDANDO",
            dados: {}
        });
        
        chamado.etapaAtual = 5;
        
        chamado.historico.push({
            data: new Date().toISOString(),
            usuario: currentUser.usuario,
            usuarioNome: currentUser.nomeCompleto,
            acao: 'Verificou estoque: Produtos indisponíveis - Iniciando compras',
            etapa: 4
        });
    }
    
    Storage.saveChamados(chamados);
    showAlert('Verificação de estoque concluída!', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 5.1: Cotação ==========
function concluirEtapa5_1(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const dataEnvioOrcamento = document.getElementById('dataEnvioOrcamento').value;
    const fornecedores = document.getElementById('fornecedores').value;
    const observacoesCotacao = document.getElementById('observacoesCotacao').value;
    
    if (!dataEnvioOrcamento) {
        showAlert('Preencha a data de envio do orçamento!', 'error');
        return;
    }
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    const etapa5 = chamado.etapas.find(e => e.numero === 5);
    
    // Atualizar dados da subetapa 5.1
    etapa5.dados.dataEnvioOrcamento = dataEnvioOrcamento;
    etapa5.dados.fornecedores = fornecedores;
    etapa5.dados.observacoesCotacao = observacoesCotacao;
    etapa5.responsavel = currentUser.usuario;
    
    // Avançar para subetapa 5.2
    etapa5.subetapa = 5.2;
    etapa5.prazo = null; // Sem SLA para envio
    
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Programou cotação para ${new Date(dataEnvioOrcamento).toLocaleDateString('pt-BR')}`,
        etapa: 5
    });
    
    Storage.saveChamados(chamados);
    showAlert('Cotação programada com sucesso!', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 5.2: Envio do Orçamento ==========
function concluirEtapa5_2(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const valorOrcamento = document.getElementById('valorOrcamento').value;
    const fornecedorSelecionado = document.getElementById('fornecedorSelecionado').value;
    const detalhesOrcamento = document.getElementById('detalhesOrcamento').value;
    
    if (!valorOrcamento || !fornecedorSelecionado) {
        showAlert('Preencha todos os campos obrigatórios!', 'error');
        return;
    }
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    const etapa5 = chamado.etapas.find(e => e.numero === 5);
    
    // Atualizar dados da subetapa 5.2
    etapa5.dados.valorOrcamento = valorOrcamento;
    etapa5.dados.fornecedorSelecionado = fornecedorSelecionado;
    etapa5.dados.detalhesOrcamento = detalhesOrcamento;
    
    // Avançar para subetapa 5.3 (Aprovação do Gestor)
    etapa5.subetapa = 5.3;
    etapa5.sla = 120; // 2 horas para aprovação
    etapa5.prazo = new Date(Date.now() + 120 * 60000).toISOString();
    
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Enviou orçamento de R$ ${valorOrcamento} para aprovação`,
        etapa: 5
    });
    
    Storage.saveChamados(chamados);
    showAlert('Orçamento enviado para aprovação do gestor!', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 5.3: Aprovação do Gestor ==========
function concluirEtapa5_3(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const decisaoGestor = document.querySelector('input[name="decisaoGestor"]:checked').value;
    const justificativaGestor = document.getElementById('justificativaGestor').value;
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    const etapa5 = chamado.etapas.find(e => e.numero === 5);
    
    // Atualizar dados da subetapa 5.3
    etapa5.dados.decisaoGestor = decisaoGestor;
    etapa5.dados.justificativaGestor = justificativaGestor;
    
    if (decisaoGestor === 'APROVADO') {
        // Aprovado - ir para subetapa 5.4 (Recebimento)
        etapa5.subetapa = 5.4;
        etapa5.prazo = null; // Sem SLA para recebimento
        
        chamado.historico.push({
            data: new Date().toISOString(),
            usuario: currentUser.usuario,
            usuarioNome: currentUser.nomeCompleto,
            acao: `Aprovou orçamento de R$ ${etapa5.dados.valorOrcamento}`,
            etapa: 5
        });
        
        showAlert('Orçamento aprovado! Aguardando recebimento das mercadorias.', 'success');
    } else {
        // Reprovado - voltar para subetapa 5.1 (Nova Cotação)
        etapa5.subetapa = 5.1;
        etapa5.sla = 120;
        etapa5.prazo = new Date(Date.now() + 120 * 60000).toISOString();
        
        chamado.historico.push({
            data: new Date().toISOString(),
            usuario: currentUser.usuario,
            usuarioNome: currentUser.nomeCompleto,
            acao: `Reprovou orçamento de R$ ${etapa5.dados.valorOrcamento}`,
            etapa: 5
        });
        
        showAlert('Orçamento reprovado. Nova cotação necessária.', 'success');
    }
    
    Storage.saveChamados(chamados);
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 5.4: Recebimento das Mercadorias ==========
function concluirEtapa5_4(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const dataRecebimento = document.getElementById('dataRecebimento').value;
    const numeroNF = document.getElementById('numeroNF').value;
    const conferenciaRecebimento = document.getElementById('conferenciaRecebimento').value;
    
    if (!dataRecebimento) {
        showAlert('Preencha a data de recebimento!', 'error');
        return;
    }
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    const etapa5 = chamado.etapas.find(e => e.numero === 5);
    
    // Atualizar e concluir etapa 5
    etapa5.status = 'CONCLUIDA';
    etapa5.dataConclusao = new Date().toISOString();
    etapa5.responsavel = currentUser.usuario;
    etapa5.dados.dataRecebimento = dataRecebimento;
    etapa5.dados.numeroNF = numeroNF;
    etapa5.dados.conferenciaRecebimento = conferenciaRecebimento;
    etapa5.subetapa = null;
    
    // Criar etapa 6
    chamado.etapas.push({
        numero: 6,
        nome: "Programar Data de Manutenção",
        responsavel: null,
        dataInicio: new Date().toISOString(),
        dataConclusao: null,
        sla: 120, // 2 horas
        prazo: new Date(Date.now() + 120 * 60000).toISOString(),
        status: "AGUARDANDO",
        dados: {}
    });
    
    chamado.etapaAtual = 6;
    
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Confirmou recebimento das mercadorias (NF: ${numeroNF || 'N/A'})`,
        etapa: 5
    });
    
    Storage.saveChamados(chamados);
    showAlert('Recebimento confirmado! Processo de compras concluído.', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 6: Programar Manutenção ==========
function concluirEtapa6(chamadoId) {
    if (!validarFormularioEtapa()) return;
    
    const dataManutencao = document.getElementById('dataManutencao').value;
    const observacoesEtapa6 = document.getElementById('observacoesEtapa6').value;
    
    if (!dataManutencao) {
        showAlert('Preencha a data da manutenção!', 'error');
        return;
    }
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    
    // Atualizar etapa 6
    const etapa6 = chamado.etapas.find(e => e.numero === 6);
    etapa6.status = 'CONCLUIDA';
    etapa6.dataConclusao = new Date().toISOString();
    etapa6.responsavel = currentUser.usuario;
    etapa6.dados = {
        dataManutencao: dataManutencao,
        observacoes: observacoesEtapa6
    };
    
    // Criar etapa 7
    chamado.etapas.push({
        numero: 7,
        nome: "Realizar Manutenção",
        responsavel: null,
        dataInicio: new Date().toISOString(),
        dataConclusao: null,
        sla: null, // Sem prazo definido
        prazo: null,
        status: "AGUARDANDO",
        dados: {}
    });
    
    chamado.etapaAtual = 7;
    
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Programou manutenção para ${new Date(dataManutencao).toLocaleString('pt-BR')}`,
        etapa: 6
    });
    
    Storage.saveChamados(chamados);
    showAlert('Manutenção programada com sucesso!', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 7: Realizar Manutenção ==========
async function concluirEtapa7(chamadoId) {
    const observacoesEtapa7 = document.getElementById('observacoesEtapa7').value;
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    
    // 🔥 PROCESSAR UPLOAD DE FOTOS
    const fotosInput = document.getElementById('fotosServico');
    let fotosServico = [];
    
    if (fotosInput && fotosInput.files.length > 0) {
        try {
            showLoading('Processando fotos');
            fotosServico = await processarMultiplasImagens(fotosInput.files, 10); // Máximo 10 fotos
            hideLoading();
        } catch (error) {
            hideLoading();
            showAlert(error.message, 'error');
            return;
        }
    }
    
    // Atualizar etapa 7
    const etapa7 = chamado.etapas.find(e => e.numero === 7);
    etapa7.status = 'CONCLUIDA';
    etapa7.dataConclusao = new Date().toISOString();
    etapa7.responsavel = currentUser.usuario;
    etapa7.dados = {
        fotosServico: fotosServico,
        observacoes: observacoesEtapa7
    };
    
    // Criar etapa 8
    chamado.etapas.push({
        numero: 8,
        nome: "Finalizar Chamado",
        responsavel: null,
        dataInicio: new Date().toISOString(),
        dataConclusao: null,
        sla: 120, // 2 horas
        prazo: new Date(Date.now() + 120 * 60000).toISOString(),
        status: "AGUARDANDO",
        dados: {}
    });
    
    chamado.etapaAtual = 8;
    
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: 'Finalizou a execução da manutenção',
        etapa: 7
    });
    
    Storage.saveChamados(chamados);
    showAlert('Manutenção concluída! Aguardando avaliação do solicitante.', 'success');
    
    setTimeout(() => {
        showDetalhes(chamadoId);
    }, 1000);
}

// ========== ETAPA 8: Finalizar Chamado ==========
function concluirEtapa8(chamadoId) {
    // Buscar avaliação do campo hidden
    const avaliacaoHidden = document.getElementById('avaliacaoHidden');
    
    if (!avaliacaoHidden || !avaliacaoHidden.value) {
        showAlert('Por favor, selecione uma avaliação de 1 a 5 estrelas!', 'error');
        return;
    }
    
    const avaliacao = parseInt(avaliacaoHidden.value);
    const comentariosAvaliacao = document.getElementById('comentariosAvaliacao').value;
    
    const chamados = Storage.getChamados();
    const chamado = chamados.find(c => c.id === chamadoId);
    
    if (!chamado) {
        showAlert('Chamado não encontrado!', 'error');
        return;
    }
    
    const currentUser = getCurrentUser();
    
    // Atualizar etapa 8
    const etapa8 = chamado.etapas.find(e => e.numero === 8);
    etapa8.status = 'CONCLUIDA';
    etapa8.dataConclusao = new Date().toISOString();
    etapa8.responsavel = currentUser.usuario;
    etapa8.dados = {
        avaliacao: avaliacao,
        comentariosAvaliacao: comentariosAvaliacao  // ✅ CORRIGIDO: Nome consistente com o ID do campo HTML
    };
    
    // Finalizar chamado
    chamado.status = 'CONCLUIDO';
    chamado.dataConclusao = new Date().toISOString();
    chamado.etapaAtual = null;
    
    chamado.historico.push({
        data: new Date().toISOString(),
        usuario: currentUser.usuario,
        usuarioNome: currentUser.nomeCompleto,
        acao: `Finalizou chamado com avaliação de ${avaliacao} estrela(s)`,
        etapa: 8
    });
    
    Storage.saveChamados(chamados);
    showAlert('✅ Chamado finalizado com sucesso!', 'success');
    
    setTimeout(() => {
        showScreen('entrada');
        loadChamados();
    }, 2000);
}

// ========== FUNÇÕES AUXILIARES ==========

// Adicionar novo produto à lista
function adicionarProduto() {
    const container = document.getElementById('produtosContainer');
    if (!container) return;
    
    const index = container.children.length;
    const novoProduto = document.createElement('div');
    novoProduto.className = 'produto-item';
    novoProduto.style.cssText = 'display: grid; grid-template-columns: 2fr 1fr 80px; gap: 8px; margin-bottom: 8px;';
    novoProduto.innerHTML = `
        <input type="text" class="form-control" placeholder="Nome do produto" id="produto_${index}">
        <input type="number" class="form-control" placeholder="Qtd" id="qtd_${index}" min="1">
        <button type="button" onclick="removerProduto(${index})" class="btn-action btn-secondary" style="padding: 8px;">🗑️</button>
    `;
    container.appendChild(novoProduto);
}

// Remover produto da lista
function removerProduto(index) {
    const container = document.getElementById('produtosContainer');
    if (!container) return;
    
    const items = container.querySelectorAll('.produto-item');
    if (items.length > 1 && items[index]) {
        items[index].remove();
    } else {
        alert('Deve haver pelo menos um produto na lista.');
    }
}

// Selecionar estrelas para avaliação
function selecionarEstrela(rating) {
    for (let i = 1; i <= 5; i++) {
        const estrela = document.getElementById(`estrela${i}`);
        if (estrela) {
            estrela.style.color = i <= rating ? '#fbbf24' : '#cbd5e1';
        }
    }
    
    const radioButton = document.querySelector(`input[name="avaliacao"][value="${rating}"]`);
    if (radioButton) {
        radioButton.checked = true;
    }
}

// Validar campos obrigatórios do formulário
function validarFormularioEtapa() {
    const requiredFields = document.querySelectorAll('.etapa-form [required]');
    
    for (const field of requiredFields) {
        if (!field.value || !field.value.trim()) {
            const label = field.previousElementSibling;
            const fieldName = label ? label.textContent.replace(' *', '') : 'campo obrigatório';
            alert(`Por favor, preencha o campo: ${fieldName}`);
            field.focus();
            return false;
        }
    }
    
    return true;
}